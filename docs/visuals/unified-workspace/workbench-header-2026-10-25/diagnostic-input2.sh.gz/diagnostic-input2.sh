#!/bin/sh
set -eu
cd /mnt/d/Physim
export ASAN_OPTIONS=detect_leaks=0
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_RUNTIME_DIR="$(mktemp -d /tmp/physim-header-diag-XXXXXX)"
openbox --sm-disable >/tmp/physim-header-diag-wm.log 2>&1 &
task_wm_pid=$!
trap 'kill "$task_wm_pid" 2>/dev/null || true; rmdir "$XDG_RUNTIME_DIR" 2>/dev/null || true' EXIT
python3 tools/wait-window-manager.py
gdb -batch -x build/native/workbench-header-input.gdb --args build/native/Design-analysis-linux/bin/physim --workspace-state-test /tmp/physim-header-diag-source2b file-tabs-design

