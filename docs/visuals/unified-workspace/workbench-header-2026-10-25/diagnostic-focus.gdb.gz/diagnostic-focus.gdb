set pagination off
set confirm off
break tab_design_frame if *stage==45 && tab_design.settle==4
commands
silent
printf "HEADER DIAG search=%d keyboard=%d focus=%d icon_pending=%d active=%s ROM=%u\n",a->show_search,a->search_keyboard,a->search_focus,a->search_icon_focus,a->ui->active->name_string,a->ui->active->flags
set $sdl=(struct nk_sdl*)a->ui->userdata.ptr
set $model=$sdl->accessibility
printf "MODEL focus=%llu pending=%llu count=%zu\n",$model->focused_id,$model->pending_focus,$model->count
set $n=0
while $n<$model->count
set $node=&$model->nodes[$n]
if $node->bounds[1]<158 && $node->bounds[0]>1000
printf "NODE id=%llu label=%s enabled=%d focused=%d focusable=%d bounds=%g,%g,%g,%g\n",$node->id,$node->label,$node->enabled,$node->focused,$node->focusable,$node->bounds[0],$node->bounds[1],$node->bounds[2],$node->bounds[3]
end
set $n=$n+1
end
quit
end
run
