set pagination off
set confirm off
python
import gdb
class ObserveClick(gdb.Breakpoint):
    last=-1
    def stop(self):
        stage=int(gdb.parse_and_eval('*stage'))
        if stage not in [77,78,79] or self.last==stage:return False
        self.last=stage
        print('CLICK OBSERVATION',stage)
        for expr in ['a->analysis_tabs[1]','a->show_report','a->analysis_tab_pointer','a->ui->input.mouse.pos','a->ui->input.mouse.scroll_delta','a->ui->input.mouse.buttons[0]']:
            print(expr,gdb.parse_and_eval(expr))
        w=gdb.parse_and_eval('a->ui->begin')
        while int(w):
            if w['name_string'].string()=='workspace':print('WORKSPACE scroll=',w['scrollbar'],'flags=',w['flags'])
            w=w['next']
        return stage==79
ObserveClick('analysis_workspace_test_frame')
end
run
