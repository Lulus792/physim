from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path.cwd(); linux=sys.platform=='linux'; platform='linux' if linux else 'windows'
stage=sys.argv[1]
root=Path('/tmp')/('physim-analysis-sides-'+stage) if linux else Path('F:/Physim/validation/analysis-sides-2026-10-25')/(stage+'-windows')
root.mkdir(exist_ok=True)
sdk=r/('build/native/Design-analysis-linux' if linux else 'build/native/Release')
program=sdk/'bin'/('physim' if linux else 'physim.exe')
expected=json.loads((r/'build/native/analysis-sides-after10-source.json').read_text())['inputs']
def guard():
    bad=[p for p,h in expected.items() if hashlib.sha256((r/p).read_bytes()).hexdigest()!=h]
    if bad:raise RuntimeError('Inputs changed: '+repr(bad))
guard(); digest=hashlib.sha256(program.read_bytes()).hexdigest()
env=dict(os.environ,PYTHONUTF8='1')
if not linux:
    sys.path.insert(0,str(r/'tools'));from build import compiler_environment
    env=compiler_environment();env.update(PYTHONUTF8='1',SDL_FORCE_RAISEWINDOW='1')
cases=['analysis_layout_dark','analysis_layout_light','analysis_layout_contrast','analysis_layout_dark_large_narrow','analysis_layout_light_large_narrow','analysis_units_dark','analysis_units_light_large_narrow','workbench_workflow','docking_workflow']
rows=[]
for name in cases:
    work=root/name;work.mkdir()
    cmd=[sys.executable,'tests/check_display_workflow.py',name,'--app',str(program),'--work',str(work),'--root',str(r)]
    print('BEGIN',name,flush=True); start=time.monotonic()
    with (work/'checker.log').open('w',encoding='utf-8') as log:
        done=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    guard();assert hashlib.sha256(program.read_bytes()).hexdigest()==digest
    row=dict(name=name,exit_code=done.returncode,seconds=time.monotonic()-start)
    rows.append(row);print('END',row,flush=True)
    (root/'results.json').write_text(json.dumps(dict(platform=platform,binary=str(program),sha256=digest,source_snapshot='analysis-sides-after10-source.json',cases=rows),indent=2)+'\n',encoding='utf-8')
    if done.returncode:sys.exit(done.returncode)
