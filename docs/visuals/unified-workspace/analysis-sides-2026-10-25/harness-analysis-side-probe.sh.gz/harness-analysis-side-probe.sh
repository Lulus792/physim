#!/bin/sh
set -eu
cd /mnt/d/Physim
export ASAN_OPTIONS=detect_leaks=0
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_RUNTIME_DIR="$(mktemp -d /tmp/physim-analysis-sides-runtime-XXXXXX)"
openbox --sm-disable > "build/native/analysis-sides-$1-wm.log" 2>&1 &
task_wm_pid=$!
trap 'kill "$task_wm_pid" 2>/dev/null || true; rmdir "$XDG_RUNTIME_DIR" 2>/dev/null || true' EXIT
python3 tools/wait-window-manager.py
python3 tools/build.py --compiler gcc --sanitizers --sdl build/native/F1-linux/sdl-install --build-dir build/native/Design-analysis-linux
mkdir -p "/tmp/physim-analysis-sides-$1/analysis_layout_dark"
python3 tests/check_display_workflow.py analysis_layout_dark --app /mnt/d/Physim/build/native/Design-analysis-linux/bin/physim --work "/tmp/physim-analysis-sides-$1/analysis_layout_dark" --root /mnt/d/Physim
if [ "$1" = after10 ]; then python3 build/native/analysis-sides-matrix.py final10; fi
