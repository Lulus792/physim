#include "physim/math.h"
#include "autosave.h"
#include "batch.h"
#include "documentation.h"
#include "code_preview.h"
#include "library.h"
#include "run_import.h"
#include "run_details.h"
#include "physim/analysis.h"
#include "physim/report.h"
#include "platform.h"
#include "profiling.h"
#include "plot_view.h"
#include "parameter_catalog.h"
#include "number_input.h"
#include "project_file.h"
#include "compiler_diagnostic.h"
#include "physim/detail/run_identity.h"
#include "completion.h"
#include "editor_search.h"
#include "source_outline.h"
#include "model_values.h"
#include "report_image.h"
#include "graphic_raster.h"
#include "analysis_comparison.h"
#include "graphic_output.h"
#include "png.h"
#include "scene_view.h"
#include "preferences.h"
#include "layout_catalog.h"
#include "channel_units.h"
#include "workspace_state.h"
#include "workspace_catalog.h"
#include "workspace_tree.h"
#include "text_document.h"
#include "protocol.h"
#include "pacing.h"
#include "step_breakpoints.h"
#include "timeline.h"
#include "ui.h"
#include "design_tokens.h"
static const ps_ui_palette *ui_palette = &PS_UI_DARK;
#define UI_COLOR(field) (ui_palette->field)
#include "language/lexer.h"
#include <ctype.h>
#include <errno.h>
#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifndef _WIN32
#include <sys/stat.h>
#include <unistd.h>
#endif
/* Preserve the surrounding disabled state for nested control groups. */
static bool disabled_stack[16];
static int disabled_depth;
static void nk_begin_disabled(struct nk_context *ctx, bool disabled) {
    disabled_stack[disabled_depth++] = ctx->current->widgets_disabled;
    if (disabled)
        nk_widget_disable_begin(ctx);
}
static void nk_end_disabled(struct nk_context *ctx) {
    bool previous = disabled_stack[--disabled_depth];
    if (previous)
        nk_widget_disable_begin(ctx);
    else
        nk_widget_disable_end(ctx);
}
#ifdef _WIN32
#define MODULE_EXT ".dll"
#define EXE_EXT ".exe"
#else
#define MODULE_EXT ".so"
#define EXE_EXT ""
#endif
#define PREVIEW 2048
#define WORKSPACE_DOCUMENTS PS_WORKSPACE_DOCUMENTS
#define FILE_TABS (WORKSPACE_DOCUMENTS + 2)
#define DOCK_HEADER_HEIGHT 32
enum { PS_PANEL_MEASURE=PS_DOCK_PANELS, PS_PANEL_TIMELINE, PS_PANEL_COUNT };
typedef struct {
    SDL_Window *window;
    ps_graphics *graphics;
    struct nk_context *ui;
    int tab;
    bool detached, restore_scroll, restore_editor_focus;
    nk_uint scroll_x,scroll_y;
    struct nk_rect action, home;
    struct nk_rect splitters[3];
    struct nk_rect measure_bounds;
    float measure_width;
    int resize;
    float resize_original;
    bool resize_cancelled;
    char capture[4096]; /* Native regression capture; empty during normal use. */
} ps_panel_window;
typedef struct {
    ps_text_document file;
    char path[4096]; /* User-facing path; file.path resolves symbolic links for saving. */
    struct nk_text_edit edit;
    bool dirty;
    char error[192];
    ps_autosave *recovery;
    bool recovery_conflict, draft_blocked, draft_present;
    char *draft_text;
    size_t draft_length;
    double draft_due;
    char draft_error[192];
} workspace_document;
typedef struct {
    char path[4096];
    SDL_AtomicInt done;
    SDL_Thread *thread;
    ps_result result;
    ps_channel channels[PS_MAX_CHANNELS];
    uint32_t channel_count;
    uint64_t total;
    double time[PREVIEW], values[PS_MAX_CHANNELS][PREVIEW];
    int count;
    ps_statistics stats[PS_MAX_CHANNELS];
    char metadata[8192];
    ps_timeline timeline;
    ps_result timeline_result;
    bool recorded_scenes;
} dataset;
typedef struct {
    int line, column;
    bool analysis;
    char text[2048],source[4096];
    ps_result code;
    bool foreign,structured;
} diagnostic;
typedef struct {
    /* Native metadata stays first for the existing baseline/glyph helpers. */
    struct nk_font native;
    const struct nk_user_font *base;
    const ps_ui_font_pairs *pairs;
    float spacing,reference_height;
} documentation_spaced_font;
typedef struct {
    struct nk_context *ui;
    const struct nk_user_font *font_ui, *font_code, *font_title;
    struct nk_user_font workbench_fonts[12]; /* UI 0–6, API 7–10, outline code 11. */
    struct nk_user_font workbench_marker_font,workbench_tab_dot_font;
    const struct nk_user_font *workbench_marker_source;
    struct nk_user_font laboratory_title_font;
    struct nk_user_font laboratory_measurement_font;
    struct nk_rect laboratory_metric_cards[2],laboratory_metric_labels[2],laboratory_metric_numbers[2],laboratory_metric_units[2],laboratory_metric_lines[2];
    struct nk_rect laboratory_measure_title,laboratory_measure_time;
    char laboratory_metric_number_text[2][96],laboratory_metric_unit_text[2][96];
    struct nk_rect laboratory_curve_areas[2];
    struct nk_rect laboratory_channel_fields[2],laboratory_channel_visible[2],laboratory_channel_names[2],laboratory_channel_units[2];
    int laboratory_curve_channel[2];
    struct nk_rect laboratory_curve_frames[2],laboratory_curve_notes[2],laboratory_curve_messages[2];
    char laboratory_channel_name_text[2][48],laboratory_channel_unit_text[2][64],laboratory_curve_message_text[2][160];
    struct nk_user_font laboratory_timeline_font;
    struct nk_user_font laboratory_section_font,laboratory_caption_font,laboratory_model_font,laboratory_control_font;
    struct nk_user_font laboratory_coordinate_font,laboratory_inspector_value_font;
    struct nk_user_font laboratory_scene_font;
    int laboratory_scene_host_width;
    SDL_WindowID laboratory_scene_owner;
    struct nk_rect laboratory_scene_frame,laboratory_scene_footer,laboratory_scene_label,laboratory_scene_status;
    struct nk_rect laboratory_scene_select,laboratory_scene_choices[4],laboratory_scene_view,laboratory_scene_hint,laboratory_scene_reset;
    bool laboratory_scene_menu,laboratory_scene_return;
    char laboratory_scene_view_text[80];
    struct nk_rect laboratory_section_bounds[9],laboratory_footer_bounds;
    struct nk_rect laboratory_object_heading_bounds,laboratory_object_title_bounds,laboratory_object_avatar_bounds;
    struct nk_rect laboratory_property_bounds[7],laboratory_property_value_bounds[7];
    unsigned laboratory_property_count;
    struct nk_rect laboratory_tree_rows[PS_MAX_OBJECTS],laboratory_tree_titles[PS_MAX_OBJECTS];
    struct nk_rect laboratory_tree_body,laboratory_tree_footer,laboratory_tree_options,laboratory_tree_filters[3];
    struct nk_rect laboratory_tree_camera_mode;
    bool laboratory_tree_reveal;
    struct nk_user_font workspace_status_font;
    struct nk_user_font analysis_title_font, analysis_chart_font;
    unsigned workbench_sidebar_focus;
    struct nk_rect workbench_environment_bounds;
    float workbench_regular_em,workbench_bold_em,workbench_code_em;
    float workbench_marker_em;
    struct nk_rect diagnostic_view_bounds;
    uint16_t workbench_tree_order[PS_WORKSPACE_TREE_LIMIT];
    const struct nk_user_font *ui_fonts[4], *title_fonts[4];
    const struct nk_user_font *code_fonts[6];
    ps_preferences preferences, settings_draft;
    char preferences_path[4096], preferences_error[192];
    bool preferences_writable, show_grid;
    int settings_previous_tab, panel_drag;
    bool settings_from_analysis,settings_defaults;
    int settings_focus;
    struct nk_rect settings_focus_bounds[14];
    bool settings_keyboard, settings_focus_scroll;
    struct nk_rect dock_rects[PS_DOCK_NODES], dock_panels[PS_DOCK_PANELS];
    struct nk_rect dock_headers[PS_DOCK_PANELS], dock_closes[PS_DOCK_PANELS], dock_splitters[PS_DOCK_NODES], dock_float_grips[PS_DOCK_PANELS];
    struct nk_rect dock_targets[5], dock_preview;
    bool dock_visible[PS_DOCK_PANELS], dock_dragging, dock_started;
    unsigned dock_front;
    int dock_resize, dock_float_resize, dock_drag, dock_last_tab, dock_resize_last_click;
    struct nk_vec2 dock_origin, dock_grab, dock_resize_mouse;
    ps_dock_float dock_resize_start;
    ps_preferences dock_resize_original;
    float dock_resize_initial_value;
    bool dock_resize_transaction,dock_resize_moved;
    ps_panel_window panels[PS_PANEL_COUNT];
    int panel_render; /* zero: main window, otherwise panel + 1 */
    unsigned panel_open_request, panel_return_request;
    unsigned panel_pull;
    bool panel_pull_dragging;
    struct nk_vec2 panel_pull_origin;
    int panel_drop_x,panel_drop_y;
    unsigned panel_drop_mask;
    unsigned panel_pull_file_order[FILE_TABS];
    /* Simulieren owns session-only geometry; the user's common layout is kept. */
    bool laboratory_initialized, laboratory_active, laboratory_curves;
    ps_layout_state laboratory_layout, laboratory_previous;
    bool analysis_layout_initialized, analysis_layout_active;
    ps_layout_state analysis_layout, analysis_previous;
    unsigned analysis_focus_return;
    float analysis_plot_height,analysis_plot_content,analysis_plot_original,analysis_plot_auto_height;
    bool analysis_plot_manual,analysis_plot_resizing,analysis_plot_was_manual,analysis_plot_cancelled,analysis_plot_hover,analysis_plot_moved;
    struct nk_rect analysis_plot_splitter,analysis_plot_separator_bounds,analysis_plot_viewport;
    struct nk_vec2 analysis_plot_grab;
    enum nk_collapse_states analysis_source_disclosure;
    char analysis_query[128];
    struct nk_rect analysis_side_buttons[2], analysis_tabs[2], analysis_run_bounds[8];
    unsigned analysis_tab_pointer;
    struct nk_vec2 analysis_tab_pointer_origin;
    struct nk_rect analysis_unit_custom;
    bool analysis_unit_focus_return;
    float laboratory_measure_height,laboratory_closed_height,laboratory_timeline_height,laboratory_curve_ratio;
    float laboratory_resize_original;
    bool laboratory_resize_cancelled;
    int laboratory_channels[2], laboratory_resize;
    struct nk_rect laboratory_switch, laboratory_sides[2], laboratory_splitters[3], laboratory_plots[2];
    struct nk_rect laboratory_transport_status,laboratory_speed_chevron;
    bool laboratory_speed_focus_return;
    struct nk_rect laboratory_measure_bounds;
    float laboratory_measure_width;
    nk_uint laboratory_measure_scroll_x,laboratory_measure_scroll_y;
    struct nk_rect laboratory_inspector_body;
    enum nk_collapse_states laboratory_groups[5];
    unsigned laboratory_scroll_x, laboratory_scroll_y, laboratory_focus_return;
    struct nk_user_font laboratory_value_font;
    struct nk_user_font laboratory_card_fonts[8];
    unsigned laboratory_card_font_count;
    SDL_Cursor *laboratory_cursors[2];
    ps_model_edit model_edit;
    enum nk_collapse_states model_disclosure;
    struct nk_rect model_input_bounds[PS_MODEL_VALUES_MAX],model_build_bounds,model_discard_bounds;
    struct nk_rect model_card_bounds[PS_MODEL_VALUES_MAX];
    struct nk_rect dock_menu_bounds[5];
    ps_layout_catalog layouts;
    char layouts_path[4096], layouts_error[192], layout_name[PS_LAYOUT_NAME_BYTES];
    bool layouts_writable, layout_manager;
    int layout_selected;
    struct nk_rect layout_bounds[6], layout_entries[PS_LAYOUT_MAX];
    ps_channel_units channel_units;
    char channel_units_path[4096], channel_units_error[192], channel_unit_scale[64];
    bool channel_units_writable, channel_unit_manager;
    ps_channel unit_channel, live_channels[PS_MAX_CHANNELS], reset_channels[PS_MAX_CHANNELS];
    ps_display_unit unit_draft;
    struct nk_rect channel_unit_buttons[2], channel_unit_bounds[7];
    struct nk_rect inspector_channel_cards[2],inspector_channel_labels[2],inspector_channel_fields[2];
    struct nk_rect inspector_channel_value,inspector_channel_hint,inspector_channel_custom;
    bool inspector_channel_return[2];
    uint32_t dock_target, dock_side;
    struct nk_rect settings_bounds[6], theme_bounds[PS_THEME_COUNT], panel_bounds[2];
    struct nk_rect ui_size_bounds[4];
    SDL_Window *window,*primary_window;
    ps_graphics *graphics;
    ps_vec3 camera_target;
    bool camera_2d;
    unsigned camera_plane; /* 0=XY, 1=YZ, 2=XZ. */
    enum nk_collapse_states camera_disclosure;
    struct nk_rect camera_mode_bounds, camera_projection_bounds, camera_preset_bounds[4];
    struct nk_rect camera_view_bounds,camera_plane_bounds;
    struct nk_rect laboratory_camera_fields[2][2],laboratory_camera_choices[2][2][4];
    struct nk_rect laboratory_camera_sliders[2][3],laboratory_camera_outputs[2][3];
    bool laboratory_camera_open[2][2],laboratory_camera_return[2][2];
    unsigned laboratory_camera_side;
    struct nk_text_edit experiment, analysis;
    char root[4096], bin[4096], project[4096], project_input[4096], last_run[4096], report[4096];
    char build_directory[4096];
    ps_project_build_info build_info;
    bool build_info_valid;
    char workspace[4096], workspace_preview_path[4096];
    workspace_document documents[WORKSPACE_DOCUMENTS];
    unsigned document_count, document_active;
    unsigned file_tab_order[FILE_TABS];
    unsigned file_tab_drag_order[FILE_TABS];
    unsigned file_tab_last_active;
    bool file_tabs_initialized, source_tab_closed[2], file_tab_dragging;
    int file_tab_drag;
    float file_tab_scroll;
    struct nk_vec2 file_tab_origin;
    struct nk_rect file_tab_bounds[FILE_TABS], file_tab_closes[FILE_TABS], file_tab_strip;
    struct nk_rect editor_caret;
    struct nk_text_edit *caret_edit;
    int caret_cursor;
    double caret_activity;
    bool completion_typed;
    char document_drafts_directory[4096];
    uint64_t source_revision, build_revision;
    int document_pending; /* 1: close, 2: reload; discard requires an explicit choice. */
    struct nk_rect document_bounds[10], document_list_bounds[WORKSPACE_DOCUMENTS];
    char manager_parent[4096], manager_name[256],manager_error[256];
    bool manager_error_reveal;
    int manager_template, manager_experiment_language;
    int manager_focus;
    bool manager_keyboard,manager_focus_known,manager_focus_reveal;
    struct nk_rect manager_focus_bounds[9];
    char workspace_additions[32][4096];
    unsigned workspace_addition_count;
    ps_workspace_tree workspace_tree;
    char workspace_tree_error[192];
    char workspace_tree_test_path[4096];
    struct nk_rect workspace_tree_test_bounds;
    struct {
        char text[4096];uint16_t offsets[4096];unsigned lines,scroll,sequence;
        struct nk_context *owner;struct nk_rect bounds;
        const struct nk_user_font *font;nk_handle font_user;
        float font_height,space,line_height,content_height,padding_x,padding_y;
        int viewport_width,viewport_height;struct nk_mouse mouse;
        bool visible,scrollable,input_held,dismissed;
    } workspace_tip;
    bool workspace_open, project_manager, dialog_pending;
    ps_workspace_state last_workspace;
    char workspace_state_path[4096], workspace_state_error[192];
    bool workspace_state_writable;
    struct nk_rect workspace_restore_bounds;
    ps_workspace_catalog *workspaces;
    char workspaces_path[4096], workspaces_error[192], workspace_name[PS_WORKSPACE_NAME_BYTES];
    bool workspaces_writable, workspace_manager;
    int workspace_selected;
    struct nk_rect workspace_catalog_bounds[6], workspace_catalog_entries[PS_WORKSPACE_MAX], workspace_menu_bounds;
    enum nk_collapse_states workspace_disclosure;
    char log[65536], status[256], find[128], replace[128];
    int tab, analysis_tab, example, profile, plot_channel;
    char step_breakpoints[PS_STEP_BREAKPOINT_TEXT];
    enum nk_collapse_states breakpoint_disclosure;
    struct nk_rect breakpoint_bounds;
    bool breakpoint_input_active;
    bool loaded, built, dirty, analysis_dirty, paused, hello, show_vectors, orthographic, quitting;
    bool analysis_only, manager_analysis_only;
    bool language_experiment;
    bool language_analysis;
    int template_analysis_language;
    bool show_paths, show_points, show_labels;
    bool show_log, show_search, diagnostic_raw;
    bool search_focus, search_keyboard, search_replace_open, search_icon_focus;
    int search_field;
    struct nk_rect search_replace_field_bounds;
    struct nk_rect search_island_bounds, search_query_bounds, search_previous_bounds, search_expand_bounds, search_close_bounds;
    struct nk_text_edit *search_edit;
    ps_ui_backdrop search_material;
    struct nk_rect workbench_tools_bounds,workbench_search_bounds,workbench_save_bounds,workbench_context_bounds,workbench_sidebar_bounds;
    char *saved_source[2];
    ps_autosave *recovery;
    bool recovery_conflict, autosave_blocked, autosave_current;
    double autosave_due;
    uint32_t autosave_hash[2], autosave_length[2];
    char autosave_error[192];
    struct nk_rect recovery_bounds[2];
    struct nk_rect navigation_bounds[3];
    struct nk_rect toolbar_bounds[6], toolbar_item_bounds[6];
    struct nk_rect toolbar_theme_bounds,toolbar_settings_bounds;
    struct nk_rect workbench_api_text_bounds[3]; /* Empty text, hint and action. */
    unsigned theme_request;
    int toolbar_menu; /* 0: closed, 1: File, 2: View. One popup supports direct switching. */
    bool toolbar_keyboard;
    int toolbar_keyboard_top, toolbar_keyboard_item;
    bool toolbar_pointer_consumed;
    int toolbar_popup_menu; /* Previous drawn popup, including keyboard close. */
    struct nk_rect toolbar_popup_bounds;
    struct nk_rect window_control_bounds[3], window_drag_bounds;
    enum nk_collapse_states view_disclosure;
    ps_document *documentation;
    ps_document *api_reference;
    ps_source_outline outline;
    char *outline_source;
    size_t outline_bytes;
    int outline_language;
    struct nk_text_edit *outline_editor;
    bool outline_cached,outline_reset_scroll,outline_keyboard;
    struct nk_rect outline_bounds[PS_OUTLINE_LIMIT];
    size_t api_reference_first,api_reference_end;
    ps_doc_api_preview api_reference_preview;
    const ps_completion_symbol *api_reference_symbol; /* Static completion catalogue. */
    bool api_example_pending;
    struct nk_text_edit *api_example_edit;
    struct nk_rect api_card_bounds,api_card_action_bounds;
    struct nk_rect api_card_arguments_bounds;
    float api_card_natural_height,api_card_measured_body_height;
    float workbench_context_expected_height,workbench_context_measured_height;
    bool workbench_context_scrollbar;
    char api_reference_name[128],api_reference_path[256];
    nk_uint api_reference_scroll_x,api_reference_scroll_y;
    struct nk_rect api_reference_bounds,api_reference_close_bounds,api_reference_handbook_bounds,api_reference_button_bounds,completion_reference_bounds;
    SDL_Window *doc_window;
    ps_graphics *doc_graphics;
    struct nk_context *doc_ui;
    struct documentation_math_cache *doc_math;
    bool doc_detail_test_requested,doc_detail_test_ok,doc_context_caption_test;
    unsigned doc_detail_test_case;
    struct nk_rect doc_detail_test_bounds;
    struct nk_rect doc_context_caption_bounds;
    char doc_detail_test_text[192];
    bool doc_math_test_requested,doc_math_test_ok;
    unsigned doc_math_test_case;
    size_t doc_math_test_block;
    bool doc_inline_math_test_requested,doc_inline_math_test_ok;
    unsigned doc_inline_math_test_case;
    size_t doc_inline_math_test_block;
    struct nk_rect doc_inline_math_test_link;
    const struct nk_user_font *doc_font_ui, *doc_font_title, *doc_font_code, *doc_code_fonts[9];
    const struct nk_user_font *doc_ui_fonts[9], *doc_title_fonts[9];
    const struct nk_user_font *doc_figure_fonts[4];
    struct nk_user_font doc_type_fonts[32];
    struct nk_user_font doc_figure_draw_font,doc_figure_caption_draw_font;
    float doc_type_em[32],doc_font_em[6][11];
    documentation_spaced_font doc_spaced_fonts[4];
    ps_ui_font_pairs *doc_font_pairs[2];
    const ps_document *doc_type_document;
    uint64_t doc_type_version;
    size_t doc_lead_text;
    const struct nk_user_font *doc_bold_fonts[11];
    const struct nk_user_font *doc_chrome_fonts[4];
    int doc_inline_clicked;
    unsigned doc_zoom_size;
    uint64_t doc_reading_version;
    bool doc_visible;
    float doc_raster_density,doc_failed_density;
    float doc_test_density; /* diagnostic raster-density override; zero in normal operation */
    bool doc_full_font_inventory; /* Actual all-size coverage probe, not normal startup. */
    struct nk_allocator *doc_test_font_allocator; /* Fault probe; null in normal operation. */
    int doc_topic, doc_loaded_track, doc_match, doc_jump_block,doc_anchor_heading;
    nk_uint doc_scroll_x, doc_scroll_y,doc_scroll_limit;
    float doc_scroll_adjustment;
    char doc_query[128], doc_last_query[128], doc_error[160];
    bool doc_search_focus, doc_search_active, doc_move_match, doc_reset_sidebar,doc_scroll_pending,doc_scroll_to_end;
    bool doc_find_open,doc_actions_open,doc_actions_return_keyboard,doc_actions_wait_release;
    int doc_actions_return_focus,doc_action_pending;
    struct nk_vec2 doc_actions_position;
    struct nk_rect doc_actions_bounds,doc_actions_trigger_bounds,doc_find_bounds;
    bool doc_keyboard,doc_focus_reveal,doc_filter_focus,doc_navigation_hidden;
    bool doc_context_hidden,doc_context_example;
    nk_uint doc_context_scroll_x[2],doc_context_scroll_y[2];
    nk_uint doc_navigation_scroll_x,doc_navigation_scroll_y;
    struct nk_rect doc_active_topic_bounds,doc_first_section_bounds;
    struct nk_rect doc_nav_group_bounds[2];
    struct nk_rect doc_section_caption_bounds;
    struct nk_rect doc_left_slot,doc_article_slot,doc_right_slot,doc_context_toggle_bounds;
    char *doc_context_source;
    ps_code_preview *doc_context_code_layout;
    const void *doc_context_code_font;
    float doc_context_code_width,doc_context_code_font_height,doc_context_code_density;
    struct nk_rect doc_context_code_bounds,doc_context_code_bar;
    float doc_context_code_x[2],doc_context_code_max,doc_context_code_step;
    ps_ui_scrollbar_drag doc_context_code_drag;
    int doc_context_source_topic,doc_context_source_track;
    int doc_focus;
    struct nk_rect doc_focus_bounds,doc_anchor_bounds,doc_body_bounds,doc_navigation_bounds;
    struct nk_rect doc_crumb_bounds,doc_article_column_bounds;
    struct nk_rect doc_context_content_bounds,doc_context_title_bounds,doc_context_figure_bounds;
    struct nk_rect doc_context_table_bounds,doc_context_table_caption_bounds,doc_context_notice_bounds,doc_context_source_bounds;
    struct nk_rect doc_context_head_bounds,doc_context_copy_bounds,doc_context_head_label_bounds;
    float doc_context_table_column;
    unsigned doc_context_table_rows;
    struct nk_rect doc_filter_bounds,doc_search_bounds,doc_first_result_bounds;
    char doc_filter[128], doc_last_filter[128];
    bool doc_filter_active, doc_contents;
    int doc_group, doc_track;
    ps_doc_history doc_history;
    bool doc_history_navigation;
    unsigned doc_history_restore;
    struct nk_rect doc_track_bounds[2],doc_home_bounds;
    float doc_theta,doc_length,doc_omega,doc_yaw,doc_pitch,doc_zoom;
    bool doc_model_initialized,doc_orthographic;
    struct nk_rect doc_visual_bounds[11];
    float doc_grid_probe[6]; /* actual draw origin, width, cell advance, source span and clip */
    bool doc_sidebar_test_requested,doc_sidebar_test_ok;unsigned doc_sidebar_test_lines;
    ps_scene doc_visual_scene;
    struct nk_rect doc_diagram_bounds;
    struct nk_rect documentation_bounds;
    ps_report *analysis_report, *pending_report;
    SDL_Thread *report_thread;
    SDL_AtomicInt report_done;
    ps_result report_result;
    int result_view;
    bool show_report;
    char result_path[4096], loaded_report_path[4096], result_error[192], result_export[4096];
    struct nk_rect result_export_bounds[3], raw_export_bounds;
    char *report_details_text, *report_details_display;
    size_t report_details_length, report_details_display_length;
    char report_details_path[4096], report_details_error[192];
    int report_details_tab, report_details_loaded;
    bool report_details_ready, report_details_active;
    struct nk_rect report_details_bounds, report_details_tabs[4], report_details_copy_bounds,
        report_details_text_bounds;
    int png_scale;
    struct graphic_dialog *graphic_export;
    struct nk_context *graphic_return_ui;unsigned graphic_return_frames;
    char graphic_export_test_path[4096];
    struct nk_rect png_region_bounds;
    struct nk_rect svg_region_bounds;
    struct nk_rect png_size_bounds, png_size_choices[4];
    ps_plot_view report_views[PS_REPORT_MAX_PLOTS], data_views[PS_MAX_CHANNELS];
    ps_comparison *comparison;uint64_t comparison_revision;
    struct nk_rect comparison_retry_bounds;
    char comparison_pending_active[4096];
    ps_channel plot_channel_identity;bool plot_channel_identity_valid;
    ps_plot_view *plot_drag, *active_plot_view;
    struct nk_vec2 plot_drag_position;
    struct nk_rect plot_area, plot_buttons[3];
    char plot_data_path[4096];
    ps_library *library, *pending_library;
    SDL_Thread *library_thread;
    SDL_Thread *import_thread;SDL_AtomicInt import_done;ps_result import_result;
    char import_source[4096],import_destination[4096];
    struct nk_rect import_bounds, project_kind_bounds, project_kind_choices[2], project_create_bounds;
    char import_test_path[4096];
    SDL_AtomicInt library_done;
    ps_result library_result;
    char library_directory[4096], library_error[192], library_query[128];
    char selected_runs[PS_ANALYSIS_MAX_INPUTS][4096];
    unsigned selected_count;
    int library_kind;
    bool library_again, library_search_focus, library_search_active;
    struct nk_rect library_open_bounds[8], library_select_bounds[8], library_reference_bounds[8],
        library_clear_bounds, library_analyze_bounds, analysis_start_bounds;
    size_t library_visible_indices[8];
    unsigned library_visible_count;
    ps_process job, runner;
    ps_parameter_catalog parameters;
    ps_log_record live_events[8],live_warning;
    unsigned live_event_count;
    uint64_t live_event_omitted;
    bool live_warning_valid;
    nk_uint live_event_scroll_x,live_event_scroll_y;
    struct nk_rect live_measurement_bounds,live_event_bounds,live_warning_bounds;
    enum nk_collapse_states parameter_disclosure;
    struct nk_rect parameter_header_bounds,parameter_input_bounds[PS_MAX_PARAMETERS],parameter_default_bounds[PS_MAX_PARAMETERS];
    struct nk_rect parameter_card_bounds[PS_MAX_PARAMETERS],parameter_label_bounds[PS_MAX_PARAMETERS],parameter_hint_bounds[PS_MAX_PARAMETERS];
    struct nk_rect run_field_cards[5],run_field_labels[5],run_field_inputs[5];
    ps_app_profile *profiler;
    bool profile_job_recorded, profile_runner_recorded;
    double profile_started_at;
    ps_app_profile_frame profile_frame;
    bool project_settings_dirty,project_definitions_dirty;
    uint32_t project_format_version;
    char project_id[33],experiment_id[33];
    ps_text_document project_manifest_snapshot;
    SDL_Thread *display_save_thread;
    SDL_AtomicInt display_save_done;
    ps_project_display display_save_value;
    ps_text_document display_save_document;
    ps_document_result display_save_result;
    struct nk_rect display_save_bounds,display_vector_bounds;
    struct nk_rect display_path_bounds,display_points_bounds,display_labels_bounds,display_all_bounds;
    enum nk_collapse_states project_build_disclosure;
    struct nk_rect migration_bounds,identity_assignment_bounds;
    struct nk_rect project_profile_bounds,project_profile_choices[2],editor_build_bounds;
    char parameter_output[8192];
    size_t parameter_output_used;
    bool parameter_output_overflow;
    int runner_memory_mib;
    double runner_wall_seconds, batch_timeout;
    enum nk_collapse_states limits_disclosure;
    struct nk_rect limit_bounds[2];
    char runner_limit_text[2][64];double runner_limit_shown[2];bool runner_limit_ready[2],runner_limit_invalid[2];
    struct nk_rect laboratory_limit_cards[2],laboratory_limit_labels[2];
    struct nk_rect laboratory_event_cards[8],laboratory_event_headings[8],laboratory_event_messages[8],laboratory_log_button;
    struct nk_rect laboratory_recording_bounds,laboratory_recording_name,laboratory_recording_meta,laboratory_recording_dot;
    SDL_Thread *batch_thread;
    SDL_AtomicInt batch_done, batch_cancel, batch_completed, batch_active;
    ps_batch_options batch_options;
    ps_batch_result batch_result;
    char *batch_source;
    ps_result batch_code;
    int batch_runs, batch_steps, batch_workers;
    double batch_dt;
    bool batch_target,batch_adaptive;
    double batch_end_time,batch_minimum_dt,batch_maximum_dt;
    char batch_timing_text[4][64];
    double batch_timing_displayed[4];
    struct nk_rect batch_target_bounds,batch_adaptive_bounds,batch_timing_bounds[4];
    char batch_seed[32], batch_channel[48], batch_last_report[4096];
    bool batch_sweep;
    bool batch_sweep_ready;
    int batch_sweep_parameter;
    char batch_sweep_start[64], batch_sweep_end[64];
    struct nk_rect batch_start_bounds, batch_cancel_bounds, batch_navigation_bounds, batch_resume_bounds, batch_analyze_bounds;
    char batch_resume_test_path[4096];
    struct nk_rect batch_sweep_bounds;
    struct nk_rect batch_sweep_value_bounds[2];
    struct nk_rect batch_workers_bounds;
    int job_kind;
    diagnostic diagnostics[64];
    int diagnostic_count;
    char diagnostic_line[8192];
    struct nk_rect diagnostic_bounds[64];
    struct nk_rect diagnostic_mode_bounds;
    struct nk_rect search_bounds,replace_bounds,source_editor_bounds;
    struct nk_rect source_editor_frame;
    struct nk_text_edit *completion_edit,*completion_focus_edit,*file_tab_keyboard_edit;
    ps_completion_query completion_query;
    size_t *completion_indices,completion_count,completion_selected;
    bool completion_active,completion_accept_pending;
    struct nk_rect completion_button_bounds,completion_list_bounds,completion_choice_bounds[4];
    size_t diagnostic_used;
    ps_wire_buffer wire;
    uint32_t command_seq;
    bool reset_pending, start_paused, reset_starting;
    char reset_previous_run[4096], reset_channel_names[PS_MAX_CHANNELS][96];
    uint32_t reset_channel_count;
    struct nk_rect run_control_bounds[6];
    struct nk_rect speed_bounds, speed_choices[8];
    double simulation_speed;
    bool adaptive_steps;
    double minimum_dt,maximum_dt;
    struct nk_rect adaptive_bounds;
    struct nk_rect adaptive_limit_bounds[3];
    char adaptive_limit_text[3][64];
    double adaptive_limit_displayed[3];
    double heartbeat, stop_at, simulation_time, dt;
    char seed[32];
    double values[PS_MAX_CHANNELS];
    uint32_t channel_count;
    char channel_names[PS_MAX_CHANNELS][96];
    int channel_status[PS_MAX_CHANNELS];
    ps_scene scene;
    ps_scene_view scene_view;
    bool scene_selected;
    struct nk_rect scene_expand_bounds[PS_MAX_OBJECTS];
    uint32_t scene_selected_id, scene_selected_slot;
    struct nk_rect scene_viewport_bounds;
    struct nk_rect scene_label_bounds[PS_MAX_OBJECTS];
    struct nk_rect scene_hide_selection_bounds;
    enum nk_collapse_states scene_disclosure;
    enum nk_collapse_states steps_disclosure;
    struct nk_rect scene_visibility_bounds[PS_MAX_OBJECTS];
    double history_t[PREVIEW], history_v[PS_MAX_CHANNELS][PREVIEW];
    int history_count;
    uint64_t history_seen, history_stride;
    float yaw, pitch, zoom;
    ps_timeline timeline;
    ps_snapshot timeline_view;
    bool timeline_browsing, timeline_playing, timeline_scenes;
    double timeline_target, timeline_wall;
    char timeline_error[160];
    struct nk_rect timeline_bounds[5];
    struct nk_rect timeline_heading_bounds,timeline_readout_bounds,timeline_track_bounds,timeline_tick_bounds[7];
    unsigned timeline_tick_count;
    bool timeline_dragging,timeline_drag_browsing,timeline_drag_playing,timeline_play_focus_return,timeline_pointer_focus;
    double timeline_tick_values[7];
    bool timeline_design_active;
    SDL_WindowID timeline_drag_window,timeline_control_window;
    ps_snapshot timeline_drag_view;
    double timeline_drag_target;

    bool run_details_manager,run_details_active;
    int run_details_tab;
    char run_details_path[4096],run_details_metadata[8192];
    char run_details_overview[PS_RUN_DETAILS_TEXT_CAPACITY],run_details_display[PS_RUN_DETAILS_TEXT_CAPACITY];
    struct nk_rect run_details_button,run_details_tabs[2],run_details_copy_bounds,run_details_close_bounds,run_details_text_bounds;
    dataset data;
} app;
static const ps_scene *display_scene(const app *a) {
    return a->timeline_browsing ? &a->timeline_view.scene : &a->scene;
}
static double display_time(const app *a) {
    return a->timeline_browsing ? a->timeline_view.time : a->simulation_time;
}
static const double *display_values(const app *a) {
    return a->timeline_browsing ? a->timeline_view.values : a->values;
}
static void timeline_release_drag(app *a) {
    bool captured=a->timeline_dragging;a->timeline_dragging=false;a->timeline_drag_window=0;
    if(captured)SDL_CaptureMouse(false);
}
static void timeline_live(app *a) {
    timeline_release_drag(a);a->timeline_play_focus_return=false;
    a->timeline_browsing = a->timeline_playing = false;
    ps_scene_view_sync(&a->scene_view, &a->scene);
}
static void timeline_clear(app *a) {
    timeline_release_drag(a);a->timeline_play_focus_return=a->timeline_pointer_focus=false;
    ps_timeline_clear(&a->timeline);
    a->timeline_browsing = a->timeline_playing = a->timeline_scenes = false;
    a->timeline_error[0] = 0;
}
static void timeline_select(app *a, uint32_t index) {
    const ps_snapshot *snapshot = ps_timeline_get(&a->timeline, index);
    if (!snapshot) return;
    a->timeline_view = *snapshot;
    a->timeline_browsing = true;
    ps_scene_view_sync(&a->scene_view, &a->timeline_view.scene);
}
static void timeline_tick(app *a) {
    if (!a->timeline_playing) return;
    uint32_t count = ps_timeline_count(&a->timeline);
    if (!count) { a->timeline_playing = false; return; }
    double now = ps_clock();
    a->timeline_target += fmin(.25, fmax(0, now - a->timeline_wall));
    a->timeline_wall = now;
    uint32_t index = ps_timeline_nearest(&a->timeline, a->timeline_target);
    /* Playback presents recorded states without stepping the experiment. */
    timeline_select(a, index);
    if (a->timeline_target >= a->timeline.latest.time) a->timeline_playing = false;
}
static void timeline_toggle_play(app *a) {
    if (a->reset_pending || a->reset_starting || ps_timeline_count(&a->timeline) < 2) return;
    timeline_release_drag(a);
    if (a->timeline_playing) { a->timeline_playing = false; return; }
    if (!a->timeline_browsing || a->timeline_view.time >= a->timeline.latest.time)
        timeline_select(a, 0);
    a->timeline_target = a->timeline_view.time;
    a->timeline_wall = ps_clock();
    a->timeline_playing = true;
}
static void refresh_library(app *a);
static void open_library(app *a);
static void completion_close(app *a);
static bool api_reference_open(app *a,const ps_completion_symbol *symbol);
static void api_reference_from_editor(app *a,struct nk_text_edit *edit);
static float documentation_height(const struct nk_user_font *font,const char *text,size_t n,float width);
static void dock_show(app *a,unsigned panel);
static bool laboratory_resize_key(app *a,const SDL_KeyboardEvent *key);
static bool laboratory_visible(const app *a);
static struct nk_rect laboratory_scene_prepare(app *a,struct nk_rect frame);
static void laboratory_scene_chrome(app *a);
static float laboratory_scene_minimum(app *a,float width);
static void laboratory_context(app *a);
static void workspace_context(app *a);
static void dock_resize_abort(app *a);
static void analysis_plot_resize_abort(app *a);
static bool analysis_plot_resize_key(app *a,const SDL_KeyboardEvent *key);
static void model_edit_clear(app *a);
static bool graphic_export_comparison(app *a);
static void analysis_text(app *a,struct nk_rect r,const char *text,const struct nk_user_font *font,struct nk_color color);
static void model_edit_finish(app *a,bool success);
static void model_edit_tick(app *a);
static void model_edit_submitted(app *a);
static void scene_camera_plane(app *a,unsigned plane);
static bool open_run_path(app *a,const char *path);
static bool action_button(struct nk_context *ui, const char *label, bool primary);
static void open_settings(app *a);
enum { PS_DIALOG_OPEN_FOLDER = 1, PS_DIALOG_ADD_FILE, PS_DIALOG_ADD_FOLDER,
       PS_DIALOG_MANAGER_PARENT, PS_DIALOG_IMPORT_RUN, PS_DIALOG_RESUME_BATCH };
static void choose_workspace_path(app *a, int mode);
static void import_run(app *a,const char *path);
static void resume_batch(app *a,const char *path);
static void analyze(app *a,bool csv);
static void create_managed_project(app *a);
static bool open_workspace_path(app *a, const char *path);
static void restore_workspace(app *a);
static void workspace_catalog_start(app *a);
static void workspace_catalog_store(app *a);
static void workspace_catalog_open(app *a);
static void workspace_catalog_delete(app *a);
static void workspace_catalog_reset(app *a);
static void forget_workspace(app *a);
static const char *experiment_source(const app *a) {
    return a->language_experiment ? "main.phys" : "main.c";
}
static const char *analysis_source(const app *a) {
    return a->language_analysis ? "analysis.phys" : "analysis.c";
}
static float editor_row_padding(const app *a) {
    return !a->project_manager && (a->tab==0 || a->tab==8)?11.f:a->ui->style.edit.row_padding;
}
static void preview_workspace_path(app *a,const char *path);
static void join(char *out, size_t n, const char *base, const char *leaf);
static const char *diagnostic_basename(const char *path) {
    const char *base=path;for(const char *p=path;*p;p++)if(*p=='/' || *p=='\\')base=p+1;return base;
}
static bool diagnostic_same_source(const app *a,const char *left,const char *right) {
    char paths[2][4096];const char *sources[]={left,right};
    for(unsigned i=0;i<2;i++) {
        int length;
        if(sources[i][0]=='/' || sources[i][0]=='\\' || (sources[i][0] && sources[i][1]==':'))
            length=snprintf(paths[i],sizeof paths[i],"%s",sources[i]);
        else length=snprintf(paths[i],sizeof paths[i],"%s/%s",a->project,sources[i]);
        if(length<0 || (size_t)length>=sizeof paths[i])return false;
    }
    return !strcmp(paths[0],paths[1]) || ps_text_document_same_file(paths[0],paths[1]);
}
static void structured_diagnostic(app *a,const ps_diagnostic *record,bool analysis) {
    if(!ps_diagnostic_valid(record) || record->code==PS_OK || a->diagnostic_count>=64)return;
    /* Prefer a typed record over a legacy line already received from stderr. */
    for(int i=0;i<a->diagnostic_count;i++)if(a->diagnostics[i].analysis==analysis &&
        diagnostic_same_source(a,a->diagnostics[i].source,record->source) &&
        (a->diagnostics[i].line==(int)record->line || (!a->diagnostics[i].structured && strstr(a->diagnostics[i].text,"runtime error")))) {
        memmove(a->diagnostics+i,a->diagnostics+i+1,(size_t)(a->diagnostic_count-i-1)*sizeof a->diagnostics[0]);a->diagnostic_count--;break;
    }
    diagnostic *d=&a->diagnostics[a->diagnostic_count++];memset(d,0,sizeof *d);
    d->analysis=analysis;d->structured=true;d->code=record->code;d->line=record->line<=INT_MAX?(int)record->line:0;
    d->column=record->column<=INT_MAX?(int)record->column:1;
    snprintf(d->source,sizeof d->source,"%s",record->source);
    if(*d->source) {
        char actual[4096],expected[4096];
        if(d->source[0]=='/' || d->source[0]=='\\' || (d->source[0] && d->source[1]==':'))snprintf(actual,sizeof actual,"%s",d->source);
        else snprintf(actual,sizeof actual,"%s/%s",a->project,d->source);
        snprintf(expected,sizeof expected,"%s/%s",a->project,analysis?analysis_source(a):experiment_source(a));
        d->foreign=strcmp(actual,expected) && !ps_text_document_same_file(actual,expected);
    }
    ps_diagnostic display=*record;
    snprintf(display.source,sizeof display.source,"%s",diagnostic_basename(record->source));
    for(char *p=display.message;*p;p++)if(*p=='\n' || *p=='\r' || *p=='\t')*p=' ';
    (void)ps_diagnostic_format(&display,d->text,sizeof d->text);a->show_log=true;
}
static void parse_diagnostic(app *a, const char *line) {
    ps_compiler_diagnostic record;
    if(a->diagnostic_count>=64 || !ps_compiler_diagnostic_parse(line,&record))return;
    char actual[4096],experiment[4096],analysis[4096];
    int length;
    if(record.source[0]=='/' || record.source[0]=='\\' || record.source[1]==':')
        length=snprintf(actual,sizeof actual,"%s",record.source);
    else length=snprintf(actual,sizeof actual,"%s/%s",a->project,record.source);
    if(length<0 || (size_t)length>=sizeof actual)return;
    join(experiment,sizeof experiment,a->project,experiment_source(a));
    join(analysis,sizeof analysis,a->project,analysis_source(a));
    bool main_source=!strcmp(actual,experiment) || ps_text_document_same_file(actual,experiment);
    bool analysis_source_file=!strcmp(actual,analysis) || ps_text_document_same_file(actual,analysis);
    diagnostic *d = &a->diagnostics[a->diagnostic_count++];
    memset(d,0,sizeof *d);
    a->show_log = true;
    d->line=record.line;d->column=record.column;
    d->analysis=analysis_source_file;d->foreign=!main_source && !analysis_source_file;d->code=PS_INVALID;
    snprintf(d->source,sizeof d->source,"%s",record.source);
    snprintf(d->text,sizeof d->text,"%s:%d:%d %s",diagnostic_basename(record.source),record.line,record.column,record.message);
}
static void diagnostic_bytes(app *a, const char *text, size_t size) {
    for (size_t i = 0; i < size; i++) {
        if (text[i] == '\n') {
            a->diagnostic_line[a->diagnostic_used] = 0;
            parse_diagnostic(a, a->diagnostic_line);
            a->diagnostic_used = 0;
        } else if (text[i] != '\r' && a->diagnostic_used + 1 < sizeof a->diagnostic_line)
            a->diagnostic_line[a->diagnostic_used++] = text[i];
    }
}
static void jump_to_diagnostic(app *a, const diagnostic *d) {
    if(d->line<=0 || !d->source[0])return;
    struct nk_text_edit *edit = d->analysis ? &a->analysis : &a->experiment;
    if(d->foreign) {
        char path[4096];
        if(d->source[0]=='/' || d->source[0]=='\\' || (d->source[0] && d->source[1]==':'))snprintf(path,sizeof path,"%s",d->source);
        else snprintf(path,sizeof path,"%s/%s",a->project,d->source);
        preview_workspace_path(a,path);
        if(a->tab!=8 || a->document_active>=a->document_count)return;
        if(!ps_text_document_same_file(path,a->documents[a->document_active].file.path))return;
        edit=&a->documents[a->document_active].edit;
    }
    const char *text = nk_str_get_const(&edit->string);
    int size = nk_str_len_char(&edit->string), at = 0, line = 1;
    while (at < size && line < d->line)
        if (text[at++] == '\n')
            line++;
    int start = at;
    while (at < size && text[at] != '\n')
        at++;
    edit->select_start = nk_utf_len(text, start);
    edit->select_end = nk_utf_len(text, at);
    edit->cursor = edit->select_start;
    edit->scrollbar.y =
        (float)(line > 3 ? line - 3 : 0) * (a->font_code->height + editor_row_padding(a));
    edit->scrollbar.x = 0;
    if(d->foreign)return;
    a->tab = d->analysis ? 2 : 0;
    if (d->analysis)
        a->analysis_tab = 1;
}
static void log_line(app *a, const char *format, ...) {
    char text[4096];
    va_list args;
    va_start(args, format);
    vsnprintf(text, sizeof text, format, args);
    va_end(args);
    size_t n = strlen(a->log), m = strlen(text);
    if (n + m + 2 >= sizeof a->log) {
        size_t drop = sizeof a->log / 2;
        while(drop<n && a->log[drop]!='\n')drop++;
        if(drop<n)drop++;
        memmove(a->log, a->log + drop, n - drop + 1);
        n -= drop;
    }
    memcpy(a->log + n, text, m);
    a->log[n + m] = '\n';
    a->log[n + m + 1] = 0;
}
static void status(app *a, const char *s) {
    snprintf(a->status, sizeof a->status, "%s", s);
    log_line(a, "%s", s);
}
static void join(char *out, size_t n, const char *base, const char *leaf) {
    snprintf(out, n, "%s/%s", base, leaf);
}
static bool exists(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f)
        return false;
    fclose(f);
    return true;
}
static bool copy_file_mode(const char *src, const char *dst, const char *mode) {
    FILE *in = fopen(src, "rb");
    if (!in)
        return false;
    FILE *out = fopen(dst, mode);
    if (!out) {
        fclose(in);
        return false;
    }
    char buf[8192];
    size_t n;
    bool ok = true;
    while ((n = fread(buf, 1, sizeof buf, in)) != 0)
        if (fwrite(buf, 1, n, out) != n) {
            ok = false;
            break;
        }
    if (ferror(in))
        ok = false;
    fclose(in);
    if (fclose(out))
        ok = false;
    return ok;
}
static bool copy_file_exclusive(const char *src, const char *dst) {
    return copy_file_mode(src, dst, "wbx");
}
static char *load_utf8_text_limit(const char *path, size_t *length,size_t maximum) {
    FILE *f = fopen(path, "rb");
    if (!f)
        return NULL;
    if (fseek(f, 0, SEEK_END)) {
        fclose(f);
        return NULL;
    }
    long size = ftell(f);
    if (size < 0 || (size_t)size > maximum) {
        fclose(f);
        return NULL;
    }
    rewind(f);
    char *text = malloc((size_t)size + 1);
    if (!text) {
        fclose(f);
        return NULL;
    }
    size_t n = fread(text, 1, (size_t)size, f);
    bool ok = !ferror(f) && n == (size_t)size;
    fclose(f);
    /* Accept well-formed UTF-8 source text, never silently replace invalid bytes. */
    for (size_t at = 0; ok && at < n;) {
        nk_rune rune;
        char encoded[NK_UTF_SIZE];
        int used = nk_utf_decode(text + at, &rune, (int)(n - at));
        int encoded_size = nk_utf_encode(rune, encoded, NK_UTF_SIZE);
        if (used <= 0 || used != encoded_size || memcmp(text + at, encoded, (size_t)used) ||
            rune == 127 || (rune < 32 && rune != '\n' && rune != '\r' && rune != '\t')) {
            ok = false;
            break;
        }
        at += (size_t)used;
    }
    if (!ok) {
        free(text);
        return NULL;
    }
    text[n] = 0;
    *length = n;
    return text;
}
static char *load_utf8_text(const char *path,size_t *length) {
    return load_utf8_text_limit(path,length,PS_DOC_MAX_BYTES);
}
static bool set_editor_text(struct nk_text_edit *edit, const char *text, size_t n) {
    bool ok = ps_source_text_valid(text, n);
    if (ok) {
        struct nk_text_edit replacement;
        nk_textedit_init_default(&replacement);
        replacement.mode = NK_TEXT_EDIT_MODE_INSERT;
        replacement.single_line = false;
        nk_str_append_text_char(&replacement.string, text, (int)n);
        ok = nk_str_len_char(&replacement.string) == (int)n &&
             (!n || memcmp(nk_str_get_const(&replacement.string), text, n) == 0);
        if (ok) {
            replacement.cursor = 0;
            replacement.select_start = replacement.select_end = 0;
            nk_textedit_free(edit);
            *edit = replacement;
        } else
            nk_textedit_free(&replacement);
    }
    return ok;
}
static bool load_editor(struct nk_text_edit *edit, const char *path) {
    size_t n = 0;
    char *text = load_utf8_text(path, &n);
    bool ok = text && set_editor_text(edit, text, n);
    free(text);
    return ok;
}
#include "report_details.inc"
static bool save_editor(struct nk_text_edit *edit, const char *path) {
    int n = nk_str_len_char(&edit->string);
    if (n < 0) return false;
    const char *text = nk_str_get_const(&edit->string);
    if (exists(path)) {
        ps_text_document document = {0};
        bool ok = ps_text_document_open(&document, path) == PS_DOCUMENT_OK &&
                  ps_text_document_save(&document, text, (size_t)n) == PS_DOCUMENT_OK;
        ps_text_document_destroy(&document);
        return ok;
    }
    if (!ps_source_text_valid(text, (size_t)n)) return false;
    char temporary[4096];
    if (ps_private_temporary_write(path, text, (size_t)n, NULL, temporary) != PS_OK)
        return false;
    bool ok = SDL_RenamePath(temporary, path);
    if (!ok) SDL_RemovePath(temporary);
    return ok;
}
static int project_display_worker(void *user) {
    app *a=user;
    a->display_save_result=ps_project_display_save_document(&a->display_save_document,&a->display_save_value);
    SDL_SetAtomicInt(&a->display_save_done,1);return 0;
}
static void project_display_finish(app *a,bool wait) {
    if(!a->display_save_thread || (!wait && !SDL_GetAtomicInt(&a->display_save_done)))return;
    SDL_WaitThread(a->display_save_thread,NULL);a->display_save_thread=NULL;
    if(a->display_save_result==PS_DOCUMENT_OK) {
        ps_text_document_destroy(&a->project_manifest_snapshot);
        a->project_manifest_snapshot=a->display_save_document;
        memset(&a->display_save_document,0,sizeof a->display_save_document);
        status(a,"Anzeigevorgabe für dieses Projekt gespeichert.");
    } else status(a,a->display_save_result==PS_DOCUMENT_CONFLICT?
        "Projektdatei extern geändert; Anzeigevorgabe wurde nicht gespeichert.":"Anzeigevorgabe konnte nicht gespeichert werden.");
    ps_text_document_destroy(&a->display_save_document);
}
static void project_display_save(app *a) {
    if(!a->loaded || a->display_save_thread || !a->project_manifest_snapshot.saved || a->recovery)return;
    const ps_text_document *source=&a->project_manifest_snapshot;
    ps_text_document_destroy(&a->display_save_document);
    a->display_save_document=*source;
    a->display_save_document.saved=malloc(source->length+1);
    if(!a->display_save_document.saved){memset(&a->display_save_document,0,sizeof a->display_save_document);status(a,"Nicht genug Speicher für Anzeigevorgabe.");return;}
    memcpy(a->display_save_document.saved,source->saved,source->length+1);
    a->display_save_value=(ps_project_display){.defined=true,.planar=a->camera_2d,.orthographic=a->orthographic,
        .plane=a->camera_plane,.flags=(a->show_vectors?PS_PROJECT_VIEW_VECTORS:0)|(a->show_paths?PS_PROJECT_VIEW_PATHS:0)|
        (a->show_points?PS_PROJECT_VIEW_POINTS:0)|(a->show_labels?PS_PROJECT_VIEW_LABELS:0)|(a->show_grid?PS_PROJECT_VIEW_GRID:0)};
    SDL_SetAtomicInt(&a->display_save_done,0);
    a->display_save_thread=SDL_CreateThread(project_display_worker,"physim-display-save",a);
    if(!a->display_save_thread){ps_text_document_destroy(&a->display_save_document);status(a,"Anzeigevorgabe konnte nicht gestartet werden.");}
    else status(a,"Anzeigevorgabe wird gespeichert …");
}
static void project_display_apply(app *a,const ps_project_display *display) {
    if(!display->defined) {
        a->camera_2d=false;a->camera_plane=0;
        a->yaw=PS_CAMERA_DEFAULT.yaw;a->pitch=PS_CAMERA_DEFAULT.pitch;
        a->orthographic=(a->preferences.view_flags&PS_VIEW_ORTHOGRAPHIC)!=0;
        a->show_vectors=(a->preferences.view_flags&PS_VIEW_VECTORS)!=0;
        a->show_paths=(a->preferences.view_flags&PS_VIEW_PATHS)!=0;
        a->show_points=(a->preferences.view_flags&PS_VIEW_POINTS)!=0;
        a->show_labels=(a->preferences.view_flags&PS_VIEW_LABELS)!=0;
        a->show_grid=(a->preferences.view_flags&PS_VIEW_GRID)!=0;
        return;
    }
    a->camera_2d=display->planar;a->camera_plane=display->plane;a->orthographic=display->orthographic;
    if(display->planar)scene_camera_plane(a,display->plane);
    else {a->yaw=PS_CAMERA_DEFAULT.yaw;a->pitch=PS_CAMERA_DEFAULT.pitch;}
    a->show_vectors=(display->flags&PS_PROJECT_VIEW_VECTORS)!=0;
    a->show_paths=(display->flags&PS_PROJECT_VIEW_PATHS)!=0;
    a->show_points=(display->flags&PS_PROJECT_VIEW_POINTS)!=0;
    a->show_labels=(display->flags&PS_PROJECT_VIEW_LABELS)!=0;
    a->show_grid=(display->flags&PS_PROJECT_VIEW_GRID)!=0;
}
static bool save_project_settings(app *a) {
    char path[4096];
    join(path, sizeof path, a->project, "physim.project");
    ps_project_settings settings = {.analysis_only=a->analysis_only, .release = a->profile != 0, .timestep = a->dt,
                                   .speed = a->simulation_speed, .parameters = a->parameters,
                                   .adaptive=a->adaptive_steps,.minimum_timestep=a->minimum_dt,
                                   .maximum_timestep=a->maximum_dt};
    snprintf(settings.breakpoints, sizeof settings.breakpoints, "%s", a->step_breakpoints);
    if (!ps_project_seed_parse(a->seed, &settings.seed)) return false;
    if(ps_project_settings_save(path,&settings)!=PS_DOCUMENT_OK)return false;
    if(ps_text_document_open(&a->project_manifest_snapshot,path)!=PS_DOCUMENT_OK)return false;
    ps_project_settings verified;
    if(ps_project_settings_read_document(&a->project_manifest_snapshot,&verified)!=PS_DOCUMENT_OK)return false;
    a->project_format_version=verified.format_version;
    memcpy(a->project_id,verified.project_id,33);memcpy(a->experiment_id,verified.experiment_id,33);return true;
}
static bool process_settings_valid(app *a){
    if(a->runner_limit_invalid[0] || a->runner_memory_mib<0 || a->runner_memory_mib>16384){a->limits_disclosure=NK_MAXIMIZED;status(a,"Speicherlimit: ganze Zahl von 0 bis 16384 MiB eingeben.");return false;}
    if(a->runner_limit_invalid[1] || !isfinite(a->runner_wall_seconds) || a->runner_wall_seconds<0 || a->runner_wall_seconds>86400){a->limits_disclosure=NK_MAXIMIZED;status(a,"Zeitlimit: endliche Zahl von 0 bis 86400 s eingeben.");return false;}
    return true;
}
static bool simulation_settings_valid(app *a) {
    uint64_t seed;
    ps_step_breakpoints breakpoints;
    if (!ps_step_breakpoints_parse(a->step_breakpoints, &breakpoints)) {
        status(a, "Haltepunkte: bis zu 32 verschiedene Schrittzahlen von 0 bis 1000000000, mit Kommas getrennt.");
        return false;
    }
    if (!ps_project_timestep_valid(a->dt)) {
        status(a, "Zeitschritt: positiven, endlichen Wert bis 1 Sekunde eingeben.");
        return false;
    }
    if (!ps_project_seed_parse(a->seed, &seed)) {
        status(a, "Zufallsseed: ganze Zahl von 0 bis 18446744073709551615 eingeben.");
        return false;
    }
    if (!ps_speed_valid(a->simulation_speed)) {
        status(a, "Geschwindigkeit: 0 für Offline oder Faktor 0,1 bis 16 wählen.");
        return false;
    }
    ps_project_settings steps={.timestep=a->dt,.adaptive=a->adaptive_steps,
                               .minimum_timestep=a->minimum_dt,.maximum_timestep=a->maximum_dt};
    if(!ps_project_step_bounds_valid(&steps)) {
        status(a,"Adaptive Schritte: 0 < Minimum ≤ Startschritt ≤ Maximum ≤ 1 Sekunde wählen.");
        return false;
    }
    return true;
}
static bool test_editor_failed_import(app *a) {
    char path[4096];
    join(path, sizeof path, a->project, "invalid-import-test.c");
    FILE *f = fopen(path, "wbx");
    if (!f)
        return false;
    const unsigned char invalid[] = {'A', 0xff, 'B'};
    bool ok = fwrite(invalid, 1, sizeof invalid, f) == sizeof invalid;
    if (fclose(f))
        ok = false;
    int length = nk_str_len_char(&a->experiment.string);
    uint32_t before =
        ps_crc32((const unsigned char *)nk_str_get_const(&a->experiment.string), (size_t)length);
    if (ok) {
        bool loaded = load_editor(&a->experiment, path);
        int after_length = nk_str_len_char(&a->experiment.string);
        uint32_t after = ps_crc32((const unsigned char *)nk_str_get_const(&a->experiment.string),
                                  (size_t)after_length);
        ok = !loaded && after_length == length && after == before;
        if (!ok)
            log_line(a, "Import regression: loaded=%d, length=%d/%d, crc=%08x/%08x", loaded, length,
                     after_length, before, after);
    }
    if (remove(path))
        ok = false;
    return ok;
}
/* Exercises the actual primary-editor path using only self-test fixtures. */
static bool test_editor_safe_save(app *a) {
    char source[4096], foreign[4096], candidate[4096], backup[4096];
    join(source,sizeof source,a->project,"safe-save-test.c");
    join(foreign,sizeof foreign,a->project,"safe-save-foreign.txt");
    int n=snprintf(candidate,sizeof candidate,"%s.tmp",source);
    if(n<0 || n>=(int)sizeof candidate)return false;
    n=snprintf(backup,sizeof backup,"%s.bak",source);
    if(n<0 || n>=(int)sizeof backup)return false;
    FILE *f=fopen(foreign,"wbx");if(!f)return false;
    bool ok=fputs("foreign contents",f)>=0;
    if(fclose(f))ok=false;
    struct nk_text_edit edit;nk_textedit_init_default(&edit);
    ok=ok && set_editor_text(&edit,"source one",10) && save_editor(&edit,source);
#ifndef _WIN32
    if(ok)ok=!chmod(source,0700) && !symlink(foreign,candidate);
#else
    if(ok){f=fopen(candidate,"wbx");ok=f && fputs("foreign contents",f)>=0;if(f && fclose(f))ok=false;}
#endif
    ok=ok && set_editor_text(&edit,"source two",10) && save_editor(&edit,source);
    size_t size=0;char *bytes=load_utf8_text(foreign,&size);
    ok=ok && bytes && size==16 && !memcmp(bytes,"foreign contents",16);free(bytes);
    bytes=load_utf8_text(backup,&size);
    ok=ok && bytes && size==10 && !memcmp(bytes,"source one",10);free(bytes);
#ifndef _WIN32
    struct stat x,y;
    ok=ok && !stat(source,&x) && !stat(backup,&y) && (x.st_mode&0777)==0700 && (y.st_mode&0777)==0700;
    ok=ok && !lstat(candidate,&x) && S_ISLNK(x.st_mode);
#endif
    nk_textedit_free(&edit);
    SDL_RemovePath(candidate);SDL_RemovePath(source);SDL_RemovePath(backup);SDL_RemovePath(foreign);
    return ok;
}
// clang-format off
#include "autosave_actions.inc"
// clang-format on
static void save_project(app *a) {
    if(a->display_save_thread){status(a,"Anzeigevorgabe wird noch gespeichert; danach erneut speichern.");return;}
    if (!a->loaded || a->recovery)
        return;
    if (!a->dirty && !a->analysis_dirty && !a->project_settings_dirty && !a->project_definitions_dirty)
        return;
    if (!simulation_settings_valid(a)) return;
    char *saved[2] = {copy_editor_text(&a->experiment), copy_editor_text(&a->analysis)};
    if (!saved[0] || !saved[1]) {
        free(saved[0]);
        free(saved[1]);
        status(a, "Speichern fehlgeschlagen: Quelle zu groß oder Speicher erschöpft.");
        return;
    }
    char p[4096];
    join(p, sizeof p, a->project, experiment_source(a));
    bool ok = !a->dirty || (!a->analysis_only && save_editor(&a->experiment, p));
    join(p, sizeof p, a->project, analysis_source(a));
    ok = (!a->analysis_dirty || save_editor(&a->analysis, p)) && ok;
    if (ok && (a->project_settings_dirty || a->project_definitions_dirty))
        ok = save_project_settings(a);
    if (ok) {
        a->dirty = a->analysis_dirty = a->project_settings_dirty = a->project_definitions_dirty = false;
        for (unsigned i = 0; i < 2; i++) {
            free(a->saved_source[i]);
            a->saved_source[i] = saved[i];
            saved[i] = NULL;
        }
        a->autosave_current = false;
        a->autosave_due = ps_clock() + a->preferences.autosave_seconds;
        if (!a->autosave_blocked) {
            autosave_path(a, p, sizeof p);
            if (exists(p) && !SDL_RemovePath(p))
                log_line(a, "Alte Autosave-Datei konnte nicht entfernt werden.");
            a->autosave_error[0] = 0;
        }
        status(a, "Projekt gespeichert.");
    } else
        status(a, "Speichern fehlgeschlagen; vorhandene Dateien und Backups pruefen.");
    free(saved[0]);
    free(saved[1]);
}
static void invalidate_build(app *a) {
    ++a->source_revision;
    a->built = false;
}
static void select_build_profile(app *a, int profile) {
    if (!a->loaded || (profile != 0 && profile != 1) || a->profile == profile) return;
    a->profile = profile;
    a->project_settings_dirty = true;
    invalidate_build(a);
}
#include "document_actions.inc"
static bool build_inputs_current(const app *a) {
    return a->source_revision == a->build_revision && !a->dirty && !a->analysis_dirty &&
           !documents_dirty(a);
}
static bool jobs_idle(app *a) {
    return !a->job.running && !a->runner.running && !a->data.thread && !a->report_thread &&
           !a->batch_thread && !a->import_thread && !a->display_save_thread;
}
static bool idle(app *a) { return !a->reset_pending && jobs_idle(a); }
static void clear_project(app *a) {
    ps_comparison_key empty={.revision=++a->comparison_revision};
    if(a->comparison)(void)ps_comparison_request(a->comparison,&empty);
    a->comparison_pending_active[0]=0;
    model_edit_clear(a);
    completion_close(a);
    a->source_tab_closed[0]=a->source_tab_closed[1]=false;
    a->file_tab_keyboard_edit=NULL;
    a->caret_edit=NULL;
    ps_text_document_destroy(&a->project_manifest_snapshot);a->project_format_version=0;
    a->project_id[0]=a->experiment_id[0]=0;
    ps_report_destroy(a->analysis_report);
    a->analysis_report = NULL;
    ps_library_destroy(a->library);
    a->library = NULL;
    nk_textedit_free(&a->experiment);
    nk_textedit_free(&a->analysis);
    nk_textedit_init_default(&a->experiment);
    nk_textedit_init_default(&a->analysis);
    for (unsigned i = 0; i < 2; i++) {
        free(a->saved_source[i]);
        a->saved_source[i] = NULL;
    }
    a->project[0] = a->last_run[0] = a->report[0] = 0;
    a->loaded = a->built = a->dirty = a->analysis_dirty = false;
    a->diagnostic_raw=false;
    a->build_info_valid = false;
    memset(&a->build_info, 0, sizeof a->build_info);
    a->project_settings_dirty = a->project_definitions_dirty = false;
    memset(&a->parameters, 0, sizeof a->parameters);
    a->live_event_count=0;a->live_event_omitted=0;a->live_warning_valid=false;
    a->language_experiment = a->language_analysis = a->analysis_only = false;
    a->selected_count = a->channel_count = 0;
    a->history_count = 0;
    a->simulation_time = 0;
    memset(a->values, 0, sizeof a->values);
    timeline_clear(a);
    a->scene.count = 0;
    a->scene_view = (ps_scene_view){0};
    a->scene_selected = false;
    a->loaded_report_path[0] = a->result_error[0] = 0;
    report_details_clear(a);
    memset(a->live_channels,0,sizeof a->live_channels);
    a->run_details_manager=false;
    ps_timeline_destroy(&a->data.timeline);
    memset(&a->data, 0, sizeof a->data);
}
static void refresh_workspace_entries(app *a) {
    a->workspace_tree_error[0] = 0;
    if (!a->workspace_open) {
        ps_workspace_tree_destroy(&a->workspace_tree);
        return;
    }
    const char *roots[33] = {a->workspace};
    for (unsigned i = 0; i < a->workspace_addition_count; i++)
        roots[i + 1] = a->workspace_additions[i];
    ps_result r = ps_workspace_tree_refresh(&a->workspace_tree, roots,
                                           a->workspace_addition_count + 1);
    if (r != PS_OK)
        snprintf(a->workspace_tree_error, sizeof a->workspace_tree_error,
                 "Dateibaum nicht vollständig geladen (%s). Betroffene Ordner sind markiert.",
                 ps_result_string(r));
}
static bool assign_current_project_ids(app *a) {
    if(!a->loaded || !idle(a) || a->library_thread || a->recovery || a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)return false;
    ps_project_identity_assignment report;
    ps_document_result result=ps_project_assign_ids_document(&a->project_manifest_snapshot,&report);
    if(result!=PS_DOCUMENT_OK){status(a,result==PS_DOCUMENT_CONFLICT?"Projektbeschreibung wurde extern geändert. Projekt erneut öffnen.":"Projekt-IDs konnten nicht gespeichert werden. Vorhandene Dateien bleiben erhalten.");return false;}
    memcpy(a->project_id,report.project_id,33);memcpy(a->experiment_id,report.experiment_id,33);
    status(a,report.changed?"Projekt-IDs gespeichert. Sicherung: physim.project.bak.":"Projekt-IDs sind bereits vorhanden.");return true;
}
static bool migrate_current_project(app *a) {
    if(!a->loaded || !idle(a) || a->library_thread || a->recovery)return false;
    /* Migrating the manifest must not implicitly save unrelated editor changes. */
    if(a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty) {
        status(a,"Vor der Formataktualisierung Änderungen speichern oder verwerfen.");return false;
    }
    char path[4096];join(path,sizeof path,a->project,"physim.project");ps_project_migration report;
    if(!ps_text_document_same_file(path,a->project_manifest_snapshot.path))return false;
    ps_document_result result=ps_project_migrate_document(&a->project_manifest_snapshot,&report);
    if(result!=PS_DOCUMENT_OK){status(a,result==PS_DOCUMENT_CONFLICT?"Projektbeschreibung wurde extern geändert. Projekt erneut öffnen.":"Projektformat konnte nicht aktualisiert werden; vorhandene Dateien bleiben erhalten.");return false;}
    a->project_format_version=report.to_version;
    status(a,report.changed?"Projektformat auf Version 2 aktualisiert. Sicherung: physim.project.bak.":"Projektformat ist bereits aktuell; keine Dateien geändert.");return true;
}
static bool open_project(app *a) {
    bool leaving_manager = a->project_manager;
    if (a->recovery)
        return false;
    if (!idle(a) || a->library_thread) {
        status(a, "Zuerst den laufenden Job beenden.");
        return false;
    }
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        save_project(a);
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        return false;
    if (!documents_save_all(a)) return false;
    char p[4096];
    join(p, sizeof p, a->project_input, "physim.project");
    ps_project_settings project_settings;ps_text_document manifest_snapshot={0};
    if (ps_text_document_open(&manifest_snapshot,p)!=PS_DOCUMENT_OK ||
        ps_project_settings_read_document(&manifest_snapshot,&project_settings)!=PS_DOCUMENT_OK) {
        ps_text_document_destroy(&manifest_snapshot);
        status(a, "Projektdatei fehlt oder ist ungültig. Quellen und Einstellungen bleiben erhalten.");
        return false;
    }
    bool language = project_settings.language_experiment;
    bool analysis_language = project_settings.language_analysis;
    struct nk_text_edit experiment, analysis;
    nk_textedit_init_default(&experiment);
    nk_textedit_init_default(&analysis);
    join(p, sizeof p, a->project_input, language ? "main.phys" : "main.c");
    if (!project_settings.analysis_only && !load_editor(&experiment, p)) {
        nk_textedit_free(&experiment);
        nk_textedit_free(&analysis);
        status(a, "Experimentquelle konnte nicht geladen werden (UTF-8, maximal 256 KiB).");
        ps_text_document_destroy(&manifest_snapshot);return false;
    }
    join(p, sizeof p, a->project_input, analysis_language ? "analysis.phys" : "analysis.c");
    if (!load_editor(&analysis, p)) {
        nk_textedit_free(&experiment);
        nk_textedit_free(&analysis);
        status(a, "Analysequelle konnte nicht geladen werden.");
        ps_text_document_destroy(&manifest_snapshot);return false;
    }
    char *saved[2] = {copy_editor_text(&experiment), copy_editor_text(&analysis)};
    if (!saved[0] || !saved[1]) {
        free(saved[0]);
        free(saved[1]);
        nk_textedit_free(&experiment);
        nk_textedit_free(&analysis);
        status(a, "Projekt konnte nicht geladen werden: Speicher erschöpft.");
        ps_text_document_destroy(&manifest_snapshot);return false;
    }
    documents_clear(a);
    clear_project(a);
    for (unsigned i = 0; i < 2; i++) {
        free(a->saved_source[i]);
        a->saved_source[i] = saved[i];
    }
    nk_textedit_free(&a->experiment);
    nk_textedit_free(&a->analysis);
    a->experiment = experiment;
    a->language_experiment = language;
    a->language_analysis = analysis_language;
    a->analysis_only=project_settings.analysis_only;
    a->project_format_version=project_settings.format_version;
    memcpy(a->project_id,project_settings.project_id,33);memcpy(a->experiment_id,project_settings.experiment_id,33);
    a->project_manifest_snapshot=manifest_snapshot;
    a->analysis = analysis;
    snprintf(a->project, sizeof a->project, "%s", a->project_input);
    snprintf(a->workspace, sizeof a->workspace, "%s", a->project_input);
    a->workspace_open = true;
    a->workspace_disclosure = NK_MINIMIZED;
    a->workspace_addition_count = 0;
    refresh_workspace_entries(a);
    a->project_manager = false;
    a->workspace_preview_path[0] = 0;
    if (leaving_manager || a->tab == 8)
        a->tab = 0;
    a->loaded = true;
    a->built = false;
    project_display_apply(a,&project_settings.display);
    a->parameters = project_settings.parameters;
    a->profile = project_settings.release ? 1 : 0;
    a->dt = project_settings.timestep;
    a->simulation_speed = project_settings.speed;
    a->adaptive_steps=project_settings.adaptive;
    a->minimum_dt=project_settings.minimum_timestep;
    a->maximum_dt=project_settings.maximum_timestep;
    snprintf(a->step_breakpoints, sizeof a->step_breakpoints, "%s", project_settings.breakpoints);
    snprintf(a->seed, sizeof a->seed, "%llu", (unsigned long long)project_settings.seed);
    a->project_settings_dirty = a->project_definitions_dirty = false;
    a->batch_sweep = false;
    a->batch_target=a->batch_adaptive=false;
    a->batch_sweep_ready = false;
    a->batch_sweep_parameter = 0;
    a->batch_sweep_start[0] = a->batch_sweep_end[0] = 0;
    a->dirty = a->analysis_dirty = false;
    a->last_run[0] = 0;
    memset(&a->batch_options, 0, sizeof a->batch_options);
    memset(&a->batch_result, 0, sizeof a->batch_result);
    a->batch_last_report[0] = 0;
    SDL_SetAtomicInt(&a->batch_completed, 0);
    ps_report_destroy(a->analysis_report);
    a->analysis_report = NULL;
    a->show_report = false;
    report_details_clear(a);
    a->result_error[0] = 0;
    a->run_details_manager=false;
    ps_timeline_destroy(&a->data.timeline);
    memset(&a->data, 0, sizeof a->data);
    timeline_clear(a);
    a->scene.count = 0;
    a->scene_view = (ps_scene_view){0};
    a->scene_selected = false;
    a->history_count = 0;
    a->channel_count = 0;
    ps_library_destroy(a->library);
    a->library = NULL;
    a->selected_count = 0;
    a->library_query[0] = 0;
    a->library_error[0] = 0;
    refresh_library(a);
    if(a->analysis_only){a->tab=0;a->analysis_tab=1;}
    status(a, a->analysis_only?"Analyseprojekt geladen. Messläufe importieren und Analyse bauen.":"Projekt geladen. Build kompiliert die lokalen Quelldateien.");
    check_recovery(a);
    return true;
}
static void new_project(app *a) {
    if (!documents_save_all(a)) return;
    if (!idle(a) || a->library_thread || a->recovery)
        return;
    char p[4096], src[4096];
    const char *reserved[] = {"main.c", "main.phys", "analysis.c", "analysis.phys", "physim.project",
                              ".physim-autosave"};
    for (size_t i = 0; i < sizeof reserved / sizeof reserved[0]; i++) {
        join(p, sizeof p, a->project_input, reserved[i]);
        if (exists(p)) {
            status(a,
                   "Projektdateien existieren bereits. Oeffnen oder einen neuen Ordner waehlen.");
            return;
        }
    }
    bool language = a->example >= 8 && a->example <= 19;
    join(p, sizeof p, a->project_input, language ? "main.phys" : "main.c");
    if (!ps_make_directory(a->project_input)) {
        status(a, "Projektordner konnte nicht erstellt werden. Elternordner muss existieren.");
        return;
    }
    const char *examples[] = {"pendulum",  "projectile", "collision",
                              "box_floor", "spring",     "uncertain_projectile", "box_collision", "buoyancy"};
    if (language)
        snprintf(src, sizeof src, "%s/examples/language/%s.phys", a->root,
                 a->example == 8 ? "pendulum" : a->example == 9 ? "projectile_drag"
                 : a->example == 10 ? "uncertain_projectile" : a->example == 11 ? "spinning_body"
                 : a->example == 12 ? "box_contacts" : a->example == 13 ? "joint_pendulum"
                 : a->example == 14 ? "coupled_bodies" : a->example == 15 ? "fast_sphere"
                 : a->example == 16 ? "spring" : a->example == 17 ? "buoyancy"
                 : a->example == 18 ? "collision" : "box_collision");
    else
        snprintf(src, sizeof src, "%s/examples/%s/main.c", a->root, examples[a->example]);
    if (!a->manager_analysis_only && !copy_file_exclusive(src, p)) {
        status(a, "Experimentvorlage konnte nicht kopiert werden.");
        return;
    }
    bool analysis_language = a->template_analysis_language == 1;
    join(src, sizeof src, a->root, a->manager_analysis_only
        ? (analysis_language?"examples/analysis_only/analysis.phys":"examples/analysis_only/analysis.c")
        : analysis_language
        ? (a->example == 0 || a->example == 8 ? "examples/documentation/pendulum_analysis.phys"
           : a->example == 10 || a->example == 5 ? "examples/language/analysis_sensors.phys"
           : a->example == 18 || a->example == 2 ? "examples/language/analysis_collision.phys"
           : a->example == 19 || a->example == 6 ? "examples/language/analysis_box_collision.phys"
           : a->example == 17 || a->example == 7 ? "examples/language/analysis_buoyancy.phys"
                                                  : "examples/language/analysis.phys")
        : "examples/pendulum/analysis.c");
    join(p, sizeof p, a->project_input, analysis_language ? "analysis.phys" : "analysis.c");
    if (!copy_file_exclusive(src, p)) {
        status(a, "Analysevorlage fehlt.");
        return;
    }
    join(p, sizeof p, a->project_input, "physim.project");
    FILE *f = fopen(p, "wx");
    if (!f) {
        status(a, "Projektbeschreibung konnte nicht geschrieben werden.");
        return;
    }
    char project_id[33],experiment_id[33];ps_project_id_generate(project_id);ps_project_id_generate(experiment_id);
    bool written = a->manager_analysis_only
        ? fprintf(f,"physim_project=2\nkind=analysis\nanalysis=%s\nmodules=core,units,data,analysis\nprofile=Debug\n",analysis_language?"analysis.phys":"analysis.c")>0
        : fprintf(f, "physim_project=2\nkind=experiment\nexperiment=%s\nanalysis=%s\nmodules=core,memory,array,string_view,hashmap,math,data,run_stream,run_index,"
               "snapshot,analysis,scene,numerics,units,series,report,report_export,mechanics,contact_world,box_contacts,collision,measurement,"
               "thermodynamics,electromagnetism,waves,optics,fluid,properties\nprofile=Debug\nsimulation.dt=0.005\nsimulation.seed=42\n", language ? "main.phys" : "main.c",
               analysis_language ? "analysis.phys" : "analysis.c") > 0;
    if(written && fprintf(f,"project.id=%s\n",project_id)<0)written=false;
    if(written && !a->manager_analysis_only && fprintf(f,"experiment.id=%s\n",experiment_id)<0)written=false;
    if (fclose(f)) written = false;
    if (!written) {
        status(a, "Projektbeschreibung konnte nicht vollständig gespeichert werden.");
        return;
    }
    join(p, sizeof p, a->project_input, "runs");
    ps_make_directory(p);
    open_project(a);
    if (a->loaded && a->example == 4) {
        a->camera_target = ps_v3(-.35, .1, 0);
        a->zoom = 2.5f;
    }
    if (a->loaded && a->example == 7) {
        a->camera_target = ps_v3(0, 0, 0);
        a->zoom = 1.3f;
    }
    if (a->loaded && a->example == 6) {
        a->camera_target = ps_v3(0, -.1, 0);
        a->zoom = 2.8f;
    }
    if (a->loaded && a->example == 13) {
        a->camera_target = ps_v3(0, 1.2, 0);
        a->zoom = 4.5f;
    }
    if (a->loaded && a->example == 14) {
        a->camera_target = ps_v3(0.8, 0.9, 0);
        a->zoom = 4.5f;
    }
    if (a->loaded && a->example == 15) {
        a->camera_target = ps_v3(0, 0.6, 0);
        a->zoom = 4.5f;
    }
    if (a->loaded && a->example == 16) {
        a->camera_target = ps_v3(0, 0, 0);
        a->zoom = 2.8f;
    }
    if (a->loaded && a->example == 17) {
        a->camera_target = ps_v3(0, 0, 0);
        a->zoom = 2.4f;
    }
}
static void build_project(app *a) {
    if (a->recovery)
        return;
    if (!a->loaded || !idle(a))
        return;
    if(!process_settings_valid(a))return;
    if (!documents_save_all(a)) return;
    save_project(a);
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        return;
    char manifest[4096];join(manifest,sizeof manifest,a->project,"physim.project");
    ps_project_settings current;
    if(ps_project_settings_read(manifest,&current)!=PS_DOCUMENT_OK || current.analysis_only!=a->analysis_only ||
       current.language_analysis!=a->language_analysis || current.language_experiment!=a->language_experiment) {
        invalidate_build(a);status(a,"Projektbeschreibung wurde geändert. Projekt erneut öffnen.");return;
    }
    char builder[4096], compiler[4096];
    join(a->build_directory, sizeof a->build_directory, a->project,
         a->profile ? "build/Release" : "build/Debug");
    join(builder, sizeof builder, a->bin, "physim-build" EXE_EXT);
    join(compiler, sizeof compiler, a->bin, "physimc" EXE_EXT);
    const char *args[] = {builder, "--project", a->project, "--sdk", a->root,
                         "--output", a->build_directory, "--physimc", compiler,
                         "--profile", a->profile ? "Release" : "Debug", NULL};
    a->built = false;
    a->diagnostic_count = 0;
    a->diagnostic_used = 0;
    a->build_revision = a->source_revision;
    if (ps_process_start(&a->job, args, a->project)) {
        model_edit_submitted(a);
        a->profile_job_recorded = false;
        a->job_kind = 2;
        status(a,a->analysis_only?"Physim baut die Analyse ...":"Physim baut Experiment und Analyse ...");
    } else
        status(a, "Physim-Build konnte nicht gestartet werden. Installation prüfen.");
}
static bool command(app *a, uint32_t type) {
    unsigned char frame[32], payload[4];
    uint32_t n = 0;
    if (type == PS_MSG_HELLO) {
        ps_put_u32(payload, PS_ABI_VERSION);
        n = 4;
    }
    size_t size = ps_wire_encode(frame, type, a->command_seq++, payload, n);
    return ps_process_write(&a->runner, frame, size);
}
static bool select_simulation_speed(app *a, double speed) {
    if (!a->loaded || !ps_speed_valid(speed) || a->reset_pending || a->reset_starting ||
        (a->runner.running && (!a->hello || a->stop_at)))
        return false;
    if (a->simulation_speed == speed)
        return true;
    if (a->runner.running) {
        unsigned char frame[28], payload[8];
        ps_put_f64(payload, speed);
        size_t size = ps_wire_encode(frame, PS_MSG_SPEED, a->command_seq++, payload, 8);
        if (!ps_process_write(&a->runner, frame, size)) {
            status(a, "Geschwindigkeit konnte nicht geändert werden.");
            return false;
        }
    }
    a->simulation_speed = speed;
    a->project_settings_dirty = true;
    return true;
}
#include "model_edit.inc"
static void unique_path(app *a, char *out, size_t cap, const char *suffix) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    char stamp[64];
    strftime(stamp, sizeof stamp, "%Y%m%d-%H%M%S", t);
    snprintf(out, cap, "%s/runs/%s-%llu%s", a->project, stamp, (unsigned long long)SDL_GetTicksNS(),
             suffix);
}
static bool record_limits(const char *prefix, const ps_process_limits *limits) {
    char path[4200];
    int n = snprintf(path, sizeof path, "%s.limits.txt", prefix);
    if (n < 0 || (size_t)n >= sizeof path)
        return false;
    FILE *file = fopen(path, "wbx");
    if (!file)
        return false;
    bool ok = fprintf(file, "physim_limits=1\nrequested_memory_bytes=%llu\nwall_seconds=%.17g\n"
                            "wall_includes_pause=1\nzero_disables_limit=1\n",
                      (unsigned long long)limits->memory_bytes, limits->wall_seconds) >= 0;
    if (fclose(file))
        ok = false;
    if (!ok)
        remove(path);
    return ok;
}
static bool discover_parameters(app *a) {
    char runner[4096], module[4096];
    join(runner, sizeof runner, a->bin, "physim-runner" EXE_EXT);
    join(module, sizeof module, a->build_directory, "experiment" MODULE_EXT);
    const char *args[] = {runner, module, "--describe", NULL};
    ps_process_limits limits = {(uint64_t)a->runner_memory_mib * UINT64_C(1048576), 30};
    a->parameter_output[0] = 0;
    a->parameter_output_used = 0;
    a->parameter_output_overflow = false;
    if (!ps_process_start_limited(&a->job, args, a->project, &limits))
        return false;
    a->profile_job_recorded = false;
    a->job_kind = 5;
    status(a, "Build erfolgreich. Experimentparameter werden gelesen ...");
    return true;
}
static void begin_run_view(app *a) {
    timeline_clear(a);
    a->selected_count = 1;
    snprintf(a->selected_runs[0], sizeof a->selected_runs[0], "%s", a->last_run);
    ps_report_destroy(a->analysis_report);
    a->analysis_report = NULL;
    a->show_report = false;
    report_details_clear(a);
    a->result_error[0] = 0;
    a->history_count = 0;
    a->history_seen = 0;
    a->history_stride = 1;
    a->scene_view = (ps_scene_view){0};
    a->scene_selected = false;
}
static bool start_run_mode(app *a, bool paused) {
    if(a->analysis_only){status(a,"Analyseprojekte werten gespeicherte Messläufe aus. Zur Auswertung wechseln.");return false;}
    if (a->recovery)
        return false;
    if(!process_settings_valid(a))return false;
    if (!simulation_settings_valid(a)) return false;
    if (a->project_settings_dirty || a->project_definitions_dirty)
        save_project(a);
    if (a->project_settings_dirty || a->project_definitions_dirty)
        return false;
    if (!a->built || !idle(a) || a->dirty) {
        status(a, "Zuerst das gespeicherte Projekt erfolgreich bauen.");
        return false;
    }
    char runner[4096], module[4096], dt[64], speed[64], src[4096], copy[4096], runs[4096], next_run[4096];
    join(runs, sizeof runs, a->project, "runs");
    if (!ps_make_directory(runs)) {
        status(a, "Laufordner konnte nicht angelegt werden.");
        return false;
    }
    join(runner, sizeof runner, a->bin, "physim-runner" EXE_EXT);
    join(module, sizeof module, a->build_directory, "experiment" MODULE_EXT);
    unique_path(a, next_run, sizeof next_run, ".psrun");
    snprintf(dt, sizeof dt, "%.17g", a->dt);
    snprintf(speed, sizeof speed, "%.17g", a->simulation_speed);
    char minimum[64],maximum[64];
    snprintf(minimum,sizeof minimum,"%.17g",a->minimum_dt);
    snprintf(maximum,sizeof maximum,"%.17g",a->maximum_dt);
    char parameter_arguments[PS_MAX_PARAMETERS][128];
    const char *args[24 + 2 * PS_MAX_PARAMETERS] = {
        runner, module, next_run, "--interactive", "--log-events", "--diagnostics", "--dt", dt, "--seed", a->seed,
        "--speed", speed};
    size_t argument_count = 12;
    if(a->project_id[0]){args[argument_count++]="--project-id";args[argument_count++]=a->project_id;}
    if(a->experiment_id[0]){args[argument_count++]="--experiment-id";args[argument_count++]=a->experiment_id;}
    if (a->step_breakpoints[0]) {
        args[argument_count++] = "--break-at-steps"; args[argument_count++] = a->step_breakpoints;
    }
    if(a->adaptive_steps) {
        args[argument_count++]="--adaptive";
        args[argument_count++]="--min-dt";args[argument_count++]=minimum;
        args[argument_count++]="--max-dt";args[argument_count++]=maximum;
    }
    for (uint32_t i = 0; i < a->parameters.count; i++) {
        double selected;
        if (ps_parameter_catalog_value(&a->parameters, i, &selected) != PS_OK) {
            char message[160];
            snprintf(message, sizeof message, "Parameter %s: endlichen Wert innerhalb der Grenzen eingeben.",
                     a->parameters.entries[i].name);
            status(a, message);
            return false;
        }
        snprintf(parameter_arguments[i], sizeof parameter_arguments[i], "%s=%.17g",
                 a->parameters.entries[i].name, selected);
        args[argument_count++] = "--param";
        args[argument_count++] = parameter_arguments[i];
    }
    args[argument_count] = NULL;
    join(src, sizeof src, a->project, experiment_source(a));
    snprintf(copy, sizeof copy, "%s.experiment.%s", next_run,
             a->language_experiment ? "phys" : "c");
    if (!copy_file_exclusive(src, copy)) {
        status(a, "Quellcode-Snapshot konnte nicht gespeichert werden.");
        return false;
    }
    ps_process_limits limits = {(uint64_t)a->runner_memory_mib * UINT64_C(1048576),
                                a->runner_wall_seconds};
    if (!record_limits(next_run, &limits)) {
        status(a, "Laufgrenzen konnten nicht archiviert werden.");
        return false;
    }
    if (ps_process_start_limited(&a->runner, args, a->project, &limits)) {
        a->model_edit.ready=false;
        a->live_event_count=0;a->live_event_omitted=0;a->live_warning_valid=false;
        a->live_event_scroll_x=a->live_event_scroll_y=0;
        a->profile_runner_recorded = false;
        snprintf(a->reset_previous_run, sizeof a->reset_previous_run, "%s", a->last_run);
        snprintf(a->last_run, sizeof a->last_run, "%s", next_run);
        a->start_paused = a->reset_starting = paused;
        /* A reset keeps the displayed state until a valid initial snapshot arrives. */
        if (!paused) {
            begin_run_view(a);
            a->channel_count = 0;
            memset(a->values, 0, sizeof a->values);
            a->simulation_time = 0;
            a->scene.count = 0;
        }
        memset(&a->wire, 0, sizeof a->wire);
        a->command_seq = 0;
        a->paused = true;
        a->hello = false;
        a->heartbeat = ps_clock();
        a->stop_at = 0;
        a->tab = 1;
        status(a, "Runner gestartet; Versionsabgleich ...");
        return true;
    } else
        status(a, "Runner konnte nicht gestartet werden.");
    return false;
}
static void start_run(app *a) { (void)start_run_mode(a, false); }
static bool runner_control_ready(const app *a) {
    return a->runner.running && a->hello && !a->reset_starting && a->stop_at==0;
}
static bool runner_keyboard_key(app *a,const SDL_KeyboardEvent *key) {
    if(a->tab!=1 || (key->key!=SDLK_F8 && key->key!=SDLK_F9))return false;
    if(!key->repeat && !(key->mod & (SDL_KMOD_CTRL|SDL_KMOD_GUI|SDL_KMOD_ALT|SDL_KMOD_SHIFT))) {
        if(key->key==SDLK_F8 && runner_control_ready(a) && a->paused)command(a,PS_MSG_STEP);
        if(key->key==SDLK_F9 && a->runner.running && !a->stop_at) {
            command(a,PS_MSG_STOP);a->stop_at=ps_clock();
        }
    }
    return true;
}
/* A reset owns the stop/reap/load/relaunch sequence. Other actions remain idle-gated. */
static bool reset_available(app *a) {
    return a->loaded && !a->analysis_only && a->built && build_inputs_current(a) && !a->recovery &&
           !a->reset_pending && !a->reset_starting && !a->job.running && !a->data.thread && !a->report_thread &&
           !a->batch_thread && (!a->runner.running || (a->hello && !a->stop_at));
}
static void reset_run(app *a) {
    if (!reset_available(a))
        return;
    if (a->runner.running) {
        if (!command(a, PS_MSG_STOP)) {
            status(a, "Zurücksetzen fehlgeschlagen: Runner konnte nicht gestoppt werden.");
            return;
        }
        a->stop_at = ps_clock();
    }
    a->reset_pending = true;
    status(a, "Simulation wird zurückgesetzt. Der bisherige Lauf bleibt gespeichert.");
}
static int load_dataset(void *user) {
    dataset *d = user;
    ps_run_reader r;
    d->result = ps_run_open(&r, d->path);
    if (d->result != PS_OK) {
        SDL_SetAtomicInt(&d->done, 1);
        return 0;
    }
    d->channel_count = r.channels;
    memcpy(d->channels, r.schema, sizeof d->channels);
    snprintf(d->metadata, sizeof d->metadata, "%s", r.metadata);
    int mask[PS_MAX_CHANNELS];
    for (uint32_t j = 0; j < r.channels; j++) {
        d->result = ps_channel_status_index(r.schema, r.channels, j, &mask[j]);
        if (d->result != PS_OK) {
            ps_run_reader_close(&r);
            SDL_SetAtomicInt(&d->done, 1);
            return 0;
        }
    }
    double t, v[PS_MAX_CHANNELS];
    uint64_t stride = 1, seen = 0;
    long records_begin = ftell(r.file);
    d->timeline_result = PS_OK;
    while ((d->result = ps_run_next(&r, &t, v)) == PS_OK) {
        bool invalid = false;
        for (uint32_t j = 0; j < r.channels; j++) {
            int s = mask[j];
            if (s >= 0 && v[s] != 0 && v[s] != 1 && v[s] != 2)
                invalid = true;
            if (s < 0 || v[s] == 1)
                ps_statistics_push(&d->stats[j], v[j]);
        }
        if (invalid) {
            d->result = PS_CORRUPT;
            break;
        }
        if (d->timeline_result == PS_OK) {
            ps_snapshot frame = {.time = t, .count = r.channels, .paused = true};
            memcpy(frame.values, v, r.channels * sizeof *v);
            d->timeline_result = ps_timeline_push(&d->timeline, &frame);
        }
        if (seen % stride == 0) {
            if (d->count == PREVIEW) {
                for (int i = 0; i < PREVIEW / 2; i++) {
                    d->time[i] = d->time[i * 2];
                    for (uint32_t j = 0; j < r.channels; j++)
                        d->values[j][i] = d->values[j][i * 2];
                }
                d->count /= 2;
                stride *= 2;
            }
            d->time[d->count] = t;
            for (uint32_t j = 0; j < r.channels; j++)
                d->values[j][d->count] = mask[j] < 0 || v[mask[j]] == 1 ? v[j] : NAN;
            d->count++;
        }
        seen++;
    }
    d->total = seen;
    if (d->result == PS_EOF || d->result == PS_RECOVERED) {
        /* Keep the same open file: a renamed/replaced path must not mix two runs. */
        if (records_begin >= 0 && !fseek(r.file, records_begin, SEEK_SET)) {
            r.samples = 0;
            r.complete = false;
            ps_snapshot frame;
            ps_result next;
            while ((next = ps_run_snapshot_next(&r, &frame)) == PS_OK) {
                if (!d->recorded_scenes) {
                    ps_timeline_clear(&d->timeline);
                    d->recorded_scenes = true;
                }
                next = ps_timeline_push(&d->timeline, &frame);
                if (next != PS_OK) break;
            }
            if (d->recorded_scenes || d->timeline_result == PS_OK) d->timeline_result = next;
        } else d->timeline_result = PS_IO;
    }
    ps_run_reader_close(&r);
    SDL_SetAtomicInt(&d->done, 1);
    return 0;
}
static void request_dataset(app *a) {
    if (a->data.thread || !a->last_run[0])
        return;
    a->comparison_revision++;
    if(a->data.count && a->plot_channel>=0 && a->plot_channel<(int)a->data.channel_count) {
        a->plot_channel_identity=a->data.channels[a->plot_channel];a->plot_channel_identity_valid=true;
    }
    if (strcmp(a->plot_data_path, a->last_run)) {
        memset(a->data_views, 0, sizeof a->data_views);
        snprintf(a->plot_data_path, sizeof a->plot_data_path, "%s", a->last_run);
        a->plot_drag = NULL;
    }
    a->run_details_manager=false;
    ps_timeline_destroy(&a->data.timeline);
    memset(&a->data, 0, sizeof a->data);
    snprintf(a->data.path, sizeof a->data.path, "%s", a->last_run);
    SDL_SetAtomicInt(&a->data.done, 0);
    a->data.thread = SDL_CreateThread(load_dataset, "physim-dataset", &a->data);
    if (!a->data.thread)
        status(a, "Datensatz-Worker konnte nicht gestartet werden.");
}
static int load_report(void *user) {
    app *a = user;
    a->report_result = ps_report_load(a->result_path, &a->pending_report);
    SDL_SetAtomicInt(&a->report_done, 1);
    return 0;
}
static void request_report_path(app *a, const char *path) {
    if (a->report_thread)
        return;
    snprintf(a->result_path, sizeof a->result_path, "%s", path);
    a->result_error[0] = 0;
    if (!exists(a->result_path)) {
        snprintf(
            a->result_error, sizeof a->result_error,
            "Diese Analyse hat keinen App-Bericht erzeugt. Exportdateien liegen im runs-Ordner.");
        return;
    }
    SDL_SetAtomicInt(&a->report_done, 0);
    a->report_thread = SDL_CreateThread(load_report, "physim-report", a);
    if (!a->report_thread)
        snprintf(a->result_error, sizeof a->result_error, "Ergebnis konnte nicht geladen werden.");
}
static void request_report(app *a) {
    char path[4096];
    int n = snprintf(path, sizeof path, "%s.psreport", a->report);
    if (n < 0 || (size_t)n >= sizeof path) {
        status(a, "Berichtspfad ist zu lang.");
        return;
    }
    request_report_path(a, path);
}
// clang-format off
#include "library_actions.inc"
#include "batch_actions.inc"
// clang-format on
static void analyze(app *a, bool csv) {
    if (a->recovery)
        return;
    if(!process_settings_valid(a))return;
    if (!csv && (!a->built || a->analysis_dirty)) {
        status(a, "Analysecode zuerst speichern und bauen.");
        return;
    }
    if ((!a->last_run[0] && (csv || (!a->selected_count && !a->analysis_only))) || !idle(a)) {
        status(a, "Zuerst einen Lauf stoppen und speichern.");
        return;
    }
    char runner[4096], module[4096], source[4096], snapshot_path[4096];
    join(runner, sizeof runner, a->bin, "physim-analysis-runner" EXE_EXT);
    join(module, sizeof module, a->build_directory, "analysis" MODULE_EXT);
    unique_path(a, a->report, sizeof a->report, csv ? ".csv" : "-analysis");
    unsigned count = !csv && a->selected_count ? a->selected_count : 1;
    const char *input = !csv && a->selected_count ? a->selected_runs[0] : a->last_run;
    const char *args[5 + PS_ANALYSIS_MAX_INPUTS] = {runner, csv ? "--csv" : module, input,
                                                    a->report, NULL};
    if(!csv && a->analysis_only && !a->selected_count && !a->last_run[0]) {
        count=0;args[2]="--runs";args[3]=a->report;args[4]=NULL;
    }
    else if (!csv && count > 1) {
        args[2] = "--runs";
        for (unsigned i = 0; i < count; i++)
            args[i + 4] = a->selected_runs[i];
        args[count + 4] = NULL;
    }
    if (!csv) {
        join(source, sizeof source, a->build_directory, "build.config");
        int n = snprintf(snapshot_path, sizeof snapshot_path, "%s.build.txt", a->report);
        if (n < 0 || (size_t)n >= sizeof snapshot_path || !copy_file_exclusive(source, snapshot_path)) {
            status(a, "Analyse-Buildinformationen konnten nicht archiviert werden.");
            return;
        }
        join(source, sizeof source, a->project, analysis_source(a));
        snprintf(snapshot_path, sizeof snapshot_path, "%s.source.%s", a->report,
                 a->language_analysis ? "phys" : "c");
        if (!copy_file_exclusive(source, snapshot_path)) {
            status(a, "Analyse-Quellcode konnte nicht archiviert werden.");
            return;
        }
    }
    ps_process_limits limits = {(uint64_t)a->runner_memory_mib * UINT64_C(1048576),
                                a->runner_wall_seconds};
    if (!record_limits(a->report, &limits)) {
        status(a, "Auswertungsgrenzen konnten nicht archiviert werden.");
        return;
    }
    if (ps_process_start_limited(&a->job, args, a->project, &limits)) {
        a->profile_job_recorded = false;
        if (!csv && strcmp(input, a->last_run)) {
            snprintf(a->last_run, sizeof a->last_run, "%s", input);
            request_dataset(a);
        }
        a->job_kind = csv ? 4 : 3;
        status(a, csv ? "CSV-Export laeuft ..." : "Analyse laeuft im separaten Prozess ...");
    } else
        status(a, "Analyse-Runner konnte nicht gestartet werden.");
}
static void synchronize_live_schema(app *a) {
    for (uint32_t j = 0; j < a->channel_count; j++) {
        a->channel_status[j] = -1;
        (void)ps_channel_status_index(a->live_channels, a->channel_count, j,
                                      &a->channel_status[j]);
    }
}
static void add_history(app *a) {
    if (a->history_count && a->simulation_time <= a->history_t[a->history_count - 1])
        return;
    if (a->history_seen++ % a->history_stride)
        return;
    if (a->history_count == PREVIEW) {
        for (int i = 0; i < PREVIEW / 2; i++) {
            a->history_t[i] = a->history_t[i * 2];
            for (uint32_t j = 0; j < a->channel_count; j++)
                a->history_v[j][i] = a->history_v[j][i * 2];
        }
        a->history_count /= 2;
        a->history_stride *= 2;
    }
    int at = a->history_count++;
    a->history_t[at] = a->simulation_time;
    for (uint32_t j = 0; j < a->channel_count; j++)
        a->history_v[j][at] =
            a->channel_status[j] < 0 || a->values[a->channel_status[j]] == 1 ? a->values[j] : NAN;
}
static int import_worker(void *user) {
    app *a=user;a->import_result=ps_run_import(a->import_source,a->import_destination);
    SDL_SetAtomicInt(&a->import_done,1);return 0;
}
static void import_run(app *a,const char *path) {
    if(!a->loaded || !idle(a) || a->library_thread || a->recovery){status(a,"Zuerst einen laufenden Job beenden und ein Projekt öffnen.");return;}
    if(!path || strlen(path)>=sizeof a->import_source){status(a,"Importpfad ist zu lang.");return;}
    snprintf(a->import_source,sizeof a->import_source,"%s",path);
    unique_path(a,a->import_destination,sizeof a->import_destination,"-import.psrun");
    SDL_SetAtomicInt(&a->import_done,0);a->import_thread=SDL_CreateThread(import_worker,"physim-import",a);
    status(a,a->import_thread?"Messlauf wird kopiert und geprüft …":"Import konnte nicht gestartet werden.");
}
static void profile_process_finished(app *a,ps_process *p,int kind,bool *recorded) {
    if (*recorded || p->running || !p->pid) return;
    *recorded = true;
    if (!a->profiler) return;
    ps_app_profile_process row = {0};
    row.process_id = (uint32_t)p->pid;
    row.time_seconds = ps_clock() - a->profile_started_at;
    row.kind = kind; row.exit_code = p->exit_code; row.timed_out = p->timed_out;
    row.scope = p->usage_scope;
    row.available = ps_process_usage_final(p, &row.usage, &row.scope);
    ps_app_profile_record_process(a->profiler, &row);
}
static void pump(app *a) {
    project_display_finish(a,false);
    if(a->import_thread && SDL_GetAtomicInt(&a->import_done)) {
        SDL_WaitThread(a->import_thread,NULL);a->import_thread=NULL;
        if(a->import_result==PS_OK || a->import_result==PS_RECOVERED) {
            snprintf(a->last_run,sizeof a->last_run,"%s",a->import_destination);
            a->selected_count=0;select_run(a,a->last_run,true);refresh_workspace_entries(a);refresh_library(a);
            a->tab=2;a->analysis_tab=0;a->show_report=false;request_dataset(a);
            status(a,a->import_result==PS_RECOVERED?"Unvollständiger Messlauf importiert; gültiger Präfix bleibt erhalten.":"Messlauf und vorhandene Quellsnapshots importiert.");
        } else {char message[160];snprintf(message,sizeof message,"Import fehlgeschlagen (%s). Vorhandene Daten bleiben erhalten.",ps_result_string(a->import_result));status(a,message);}
    }
    pump_batch(a);
    pump_library(a);
    if (a->report_thread && SDL_GetAtomicInt(&a->report_done)) {
        SDL_WaitThread(a->report_thread, NULL);
        a->report_thread = NULL;
        if (a->report_result == PS_OK) {
            report_details_clear(a);
            ps_report_destroy(a->analysis_report);
            a->analysis_report = a->pending_report;
            a->pending_report = NULL;
            a->result_view = 0;
            memset(a->report_views, 0, sizeof a->report_views);
            a->plot_drag = NULL;
            a->show_report = true;
            snprintf(a->loaded_report_path, sizeof a->loaded_report_path, "%s", a->result_path);
            status(a, "Analyseergebnis geladen. Diagramme und Tabellen sind bereit.");
        } else {
            snprintf(a->result_error, sizeof a->result_error,
                     "Bericht abgewiesen: %s. Ein vorheriges Ergebnis bleibt erhalten.",
                     ps_result_string(a->report_result));
            status(a, a->result_error);
        }
    }
    if (a->job.running) {
        char buf[4096];
        int n;
        for (int i = 0; i < 16 && (n = ps_process_read(&a->job, buf, sizeof buf - 1)) > 0; i++) {
            if (a->profiler) a->profile_frame.job_bytes += (uint64_t)n;
            buf[n] = 0;
            if (a->job_kind == 5) {
                if ((size_t)n < sizeof a->parameter_output - a->parameter_output_used) {
                    memcpy(a->parameter_output + a->parameter_output_used, buf, (size_t)n + 1);
                    a->parameter_output_used += (size_t)n;
                } else
                    a->parameter_output_overflow = true;
            }
            if (a->job_kind == 1 || a->job_kind == 2 || a->job_kind == 3)
                diagnostic_bytes(a, buf, (size_t)n);
            log_line(a, "%s", buf);
        }
        if (!ps_process_poll(&a->job)) {
            profile_process_finished(a, &a->job, a->job_kind, &a->profile_job_recorded);
            int code = a->job.exit_code;
            ps_process_close(&a->job);
            if(code && (a->job_kind==3 || a->job_kind==4)) {
                char path[4096];snprintf(path,sizeof path,"%s.psdiag",a->report);ps_diagnostic record;
                if(ps_diagnostic_load(path,&record)==PS_OK)structured_diagnostic(a,&record,true);
            }
            if (!code && a->job_kind == 2) {
                char configuration[4096];
                join(configuration, sizeof configuration, a->build_directory, "build.config");
                a->build_info_valid = ps_project_build_info_read(configuration, &a->build_info);
                if (!a->diagnostic_count)
                    a->show_log = false;
                if (!build_inputs_current(a))
                    status(a, "Build fertig; Editor wurde waehrenddessen geaendert. Erneut bauen.");
                else if(a->analysis_only) {
                    a->built=true;status(a,"Analyse erfolgreich gebaut. Gespeicherte Läufe können ausgewertet werden.");
                }
                else if (!discover_parameters(a))
                    status(a, "Build fertig; Parameterabfrage konnte nicht gestartet werden.");
            } else if (a->job_kind == 5) {
                a->built = !code && !a->job.timed_out && !a->parameter_output_overflow &&
                           ps_parameter_catalog_parse(&a->parameters, a->parameter_output) &&
                           build_inputs_current(a);
                if (a->built) {
                    a->batch_sweep_ready = false;
                    a->project_definitions_dirty = true; /* Persist validated definitions without changing user-setting dirtiness. */
                }
                status(a, a->built ? "Build und Parameterabfrage erfolgreich. Experiment bereit."
                          : !build_inputs_current(a)
                              ? "Dateien oder Buildprofil wurden während des Builds geändert. Erneut bauen."
                              : "Parameterabfrage fehlgeschlagen. Details im Protokoll; erneut bauen.");
            } else if (!code && (a->job_kind == 3 || a->job_kind == 4)) {
                refresh_library(a);
                status(a, "Auswertung abgeschlossen; Ergebnisse im runs-Ordner.");
                if (a->job_kind == 3) {
                    request_dataset(a);
                    request_report(a);
                }
            } else if (a->job.timed_out) {
                status(a, "Auswertung nach Zeitlimit beendet. Vorhandene Ergebnisse bleiben erhalten.");
            } else {
                char message[128];
                snprintf(message, sizeof message, "Job beendet (Exit %d). Details im Protokoll.",
                         code);
                status(a, message);
            }
        }
    }
    if (a->runner.running) {
        int got = ps_process_read(&a->runner, a->wire.data + a->wire.used,
                                  sizeof a->wire.data - a->wire.used);
        if (got > 0) {
            a->wire.used += (size_t)got;
            if (a->profiler) a->profile_frame.runner_bytes += (uint64_t)got;
        }
        uint32_t type, n;
        const unsigned char *p;
        int r = 0;
        while ((r = ps_wire_peek(&a->wire, &type, &p, &n)) > 0) {
            a->heartbeat = ps_clock();
            if (type == PS_MSG_HELLO && !a->hello) {
                char hello[8193];
                memcpy(hello, p, n);
                hello[n] = 0;
                char *line = strchr(hello, '\n');
                uint32_t count = 0;
                char names[PS_MAX_CHANNELS][96] = {{0}};
                if (line) {
                    line++;
                    while (*line && count < PS_MAX_CHANNELS) {
                        char *end = strchr(line, '\n');
                        if (!end)
                            break;
                        *end = 0;
                        snprintf(names[count++], 96, "%s", line);
                        line = end + 1;
                    }
                }
                ps_run_reader schema_reader;
                if(ps_run_open(&schema_reader,a->last_run)!=PS_OK) {r=-1;break;}
                bool valid_schema=schema_reader.channels==count;
                for(uint32_t i=0;i<count && valid_schema;i++) {
                    char label[96];snprintf(label,sizeof label,"%s [%s]",schema_reader.schema[i].name,schema_reader.schema[i].unit);
                    valid_schema=!strcmp(label,names[i]);
                }
                if(valid_schema) {
                    memcpy(a->reset_starting?a->reset_channels:a->live_channels,schema_reader.schema,sizeof a->live_channels);
                    memcpy(a->reset_starting?a->reset_channel_names:a->channel_names,names,sizeof names);
                }
                ps_run_reader_close(&schema_reader);
                if(!valid_schema){r=-1;break;}
                if (a->reset_starting)
                    a->reset_channel_count = count;
                else {
                    a->channel_count = count;
                    synchronize_live_schema(a);
                }
                a->hello = true;
                command(a, PS_MSG_HELLO);
                if (!a->start_paused)
                    command(a, PS_MSG_RUN);
                status(a, a->start_paused
                              ? "Runner bereit. Anfangszustand wird geladen."
                              : "Simulation laeuft. Messwerte werden fortlaufend gespeichert.");
            } else if (type == PS_MSG_SNAPSHOT) {
                bool was_paused = a->paused, paused;
                double time, values[PS_MAX_CHANNELS];
                uint32_t count;
                ps_scene scene;
                if (!ps_snapshot_decode(p, n, &time, values, &count, &scene, &paused) ||
                    (a->reset_starting && (time != 0 || !paused || count != a->reset_channel_count))) {
                    r = -1;
                    break;
                }
                a->simulation_time = time;
                memcpy(a->values, values, count * sizeof *values);
                a->channel_count = count;
                a->scene = scene;
                a->paused = paused;
                if (a->reset_starting) {
                    memcpy(a->channel_names, a->reset_channel_names, sizeof a->channel_names);
                    memcpy(a->live_channels,a->reset_channels,sizeof a->live_channels);
                    synchronize_live_schema(a);
                    begin_run_view(a);
                    a->reset_starting = false;
                    a->reset_previous_run[0] = 0;
                    status(a, "Zurückgesetzt. Anfangszustand pausiert; Einzelschritt oder Fortsetzen wählen.");
                } else if (was_paused != a->paused)
                    status(a, a->paused
                                  ? "Simulation pausiert. Einzelschritt oder Fortsetzen wählen."
                                  : "Simulation läuft. Messwerte werden gespeichert.");
                ps_snapshot frame = {.time = time, .count = count, .scene = scene, .paused = paused};
                memcpy(frame.values, values, count * sizeof *values);
                ps_result timeline_result = ps_timeline_push(&a->timeline, &frame);
                a->timeline_scenes = true;
                if (timeline_result != PS_OK)
                    snprintf(a->timeline_error, sizeof a->timeline_error,
                             "Zeitleiste: %s", ps_result_string(timeline_result));
                if (!a->timeline_browsing) ps_scene_view_sync(&a->scene_view, &a->scene);
                add_history(a);
            } else if(type==PS_MSG_LOG) {
                ps_log_record record;
                if(!ps_wire_log_decode(p,n,&record)){r=-1;break;}
                if(a->live_event_count==sizeof a->live_events/sizeof *a->live_events) {
                    memmove(a->live_events,a->live_events+1,(a->live_event_count-1)*sizeof *a->live_events);
                    a->live_event_count--;a->live_event_omitted++;
                }
                a->live_events[a->live_event_count++]=record;
                if(record.level>=PS_LOG_WARNING){a->live_warning=record;a->live_warning_valid=true;}
                log_line(a,"Experiment [%s, t=%.17g s]: %s",ps_log_level_name(record.level),record.time_s,record.message);
            } else if(type==PS_MSG_DIAGNOSTIC) {
                ps_diagnostic record;if(ps_diagnostic_decode(p,n,&record)!=PS_OK){r=-1;break;}
                structured_diagnostic(a,&record,false);char text[PS_DIAGNOSTIC_WIRE_MAX+256];
                (void)ps_diagnostic_format(&record,text,sizeof text);log_line(a,"Runner: %s",text);
            } else if (type == PS_MSG_ERROR) {
                char error[8193];
                memcpy(error, p, n);
                error[n] = 0;
                parse_diagnostic(a, error);
                log_line(a, "Runner: %s", error);
            } else if (type != PS_MSG_HEARTBEAT && type != PS_MSG_BYE) {
                r = -1;
                break;
            }
            ps_wire_consume(&a->wire, n);
        }
        if (r < 0) {
            ps_process_kill(&a->runner);
            status(a, "Ungueltige Runner-Nachricht; Prozess beendet.");
        }
        if (a->stop_at && ps_clock() - a->stop_at > 1) {
            ps_process_kill(&a->runner);
            status(a,
                   "Runner nach Stop-Timeout beendet. Vollstaendige Messbloecke bleiben lesbar.");
        }
        if (!ps_process_poll(&a->runner)) {
            profile_process_finished(a, &a->runner, 0, &a->profile_runner_recorded);
            int code = a->runner.exit_code;
            ps_process_close(&a->runner);
            a->paused = true;
            a->hello = false;
            char message[200];
            bool failed_reset = a->reset_starting;
            bool recorded_run = exists(a->last_run);
            if (failed_reset) {
                snprintf(a->last_run, sizeof a->last_run, "%s", a->reset_previous_run);
                a->reset_previous_run[0] = 0;
                a->reset_starting = false;
                snprintf(message, sizeof message,
                         "Zurücksetzen fehlgeschlagen (Exit %d). Der bisherige Zustand bleibt erhalten.", code);
            } else if (!recorded_run && a->runner.timed_out)
                snprintf(message, sizeof message,
                         "Runner nach Zeitlimit beendet; keine Messdatei angelegt. Details im Protokoll.");
            else if (!recorded_run)
                snprintf(message, sizeof message,
                         "Runner beendet (Exit %d); keine Messdatei angelegt. Details im Protokoll.", code);
            else if (a->runner.timed_out)
                snprintf(message, sizeof message,
                         "Runner nach Zeitlimit beendet. Vollständige Messblöcke bleiben lesbar.");
            else
                snprintf(message, sizeof message,
                         "Runner beendet (Exit %d). Lauf gespeichert bzw. bis zum letzten Block "
                         "rekonstruierbar.", code);
            status(a, message);
            if (!failed_reset && recorded_run)
                request_dataset(a);
            refresh_library(a);
        }
    }
    if (a->data.thread && SDL_GetAtomicInt(&a->data.done)) {
        SDL_WaitThread(a->data.thread, NULL);
        a->data.thread = NULL;
        if(a->plot_channel_identity_valid) {
            a->plot_channel=0;
            for(uint32_t i=0;i<a->data.channel_count;i++) {
                const ps_channel *wanted=&a->plot_channel_identity,*candidate=a->data.channels+i;
                bool wanted_angle=!strcmp(wanted->unit,"rad") || !strcmp(wanted->unit,"deg") || !strcmp(wanted->unit,"°");
                bool candidate_angle=!strcmp(candidate->unit,"rad") || !strcmp(candidate->unit,"deg") || !strcmp(candidate->unit,"°");
                if(!strcmp(wanted->name,candidate->name) && !memcmp(wanted->dimension,candidate->dimension,7) && wanted_angle==candidate_angle){a->plot_channel=(int)i;break;}
            }
            a->plot_channel_identity_valid=false;
        }
        if (a->data.result == PS_EOF || a->data.result == PS_RECOVERED) {
            ps_timeline_destroy(&a->timeline);
            a->timeline = a->data.timeline;
            memset(&a->data.timeline, 0, sizeof a->data.timeline);
            a->timeline_scenes = a->data.recorded_scenes;
            if (a->data.timeline_result != PS_EOF && a->data.timeline_result != PS_RECOVERED)
                snprintf(a->timeline_error, sizeof a->timeline_error, "Zeitleiste: %s",
                         ps_result_string(a->data.timeline_result));
            else a->timeline_error[0] = 0;
            if (a->timeline.seen) {
                const ps_snapshot *latest = &a->timeline.latest;
                a->simulation_time = latest->time;
                memcpy(a->values, latest->values, sizeof a->values);
                a->channel_count = a->data.channel_count;
                memcpy(a->live_channels,a->data.channels,sizeof a->live_channels);
                a->scene = latest->scene;
                for (uint32_t j = 0; j < a->channel_count; j++)
                    snprintf(a->channel_names[j], sizeof a->channel_names[j], "%s [%s]",
                             a->data.channels[j].name, a->data.channels[j].unit);
                synchronize_live_schema(a);
                if (!a->timeline_browsing) ps_scene_view_sync(&a->scene_view, &a->scene);
            }
            a->history_count = a->data.count;
            memcpy(a->history_t, a->data.time, sizeof a->history_t);
            memcpy(a->history_v, a->data.values, sizeof a->history_v);
            char message[128];
            snprintf(message, sizeof message, "%llu Messpunkte geladen%s.",
                     (unsigned long long)a->data.total,
                     a->data.result == PS_RECOVERED ? " (Lauf rekonstruiert)" : "");
            status(a, message);
        } else {
            a->data.count = 0;
            status(a, "Datensatz konnte nicht vollstaendig gelesen werden.");
        }
    }
    if (a->reset_pending && !a->quitting && jobs_idle(a)) {
        a->reset_pending = false;
        (void)start_run_mode(a, true);
    }
    timeline_tick(a);
}
static bool place_label(struct nk_rect *label, struct nk_rect viewport,
                        const struct nk_rect *placed, unsigned count) {
    if (viewport.h < label->h || viewport.w <= 0)
        return false;
    label->w = fminf(label->w, viewport.w);
    label->x = fmaxf(viewport.x, fminf(label->x, viewport.x + viewport.w - label->w));
    float preferred = label->y;
    for (unsigned attempt = 0; attempt <= 2 * count + 2; attempt++) {
        int row = attempt ? (int)((attempt + 1) / 2) * (attempt % 2 ? -1 : 1) : 0;
        label->y = preferred + (float)row * (label->h + 3);
        if (label->y < viewport.y || label->y + label->h > viewport.y + viewport.h)
            continue;
        bool overlap = false;
        for (unsigned j = 0; j < count; j++) {
            struct nk_rect p = placed[j];
            if (label->x < p.x + p.w + 2 && label->x + label->w + 2 > p.x &&
                label->y < p.y + p.h + 2 && label->y + label->h + 2 > p.y) {
                overlap = true;
                break;
            }
        }
        if (!overlap)
            return true;
    }
    return false;
}
static void scene_selection_sync(app *a) {
    if (a->scene_selected && a->scene_selected_id) {
        a->scene_selected = false;
        for (uint32_t i = 0; i < display_scene(a)->count; i++)
            if (display_scene(a)->objects[i].id == a->scene_selected_id) {
                a->scene_selected = true;
                a->scene_selected_slot = i;
                break;
            }
    }
    if (a->scene_selected_slot >= display_scene(a)->count) a->scene_selected = false;
}
static bool scene_entry_enabled(const app *a, uint32_t i) {
    return ps_scene_view_enabled(&a->scene_view,display_scene(a),i,a->show_vectors,a->show_paths,a->show_points,a->show_labels);
}
static void scene_select_entry(app *a,uint32_t slot) {
    const ps_scene *scene=display_scene(a);
    a->scene_selected=slot<scene->count;
    if(!a->scene_selected) return;
    a->scene_selected_slot=slot;a->scene_selected_id=scene->objects[slot].id;
    a->laboratory_tree_reveal=true;
    int parent=ps_scene_parent_index(scene,slot);
    for(unsigned depth=0;parent>=0 && depth<PS_MAX_OBJECTS;depth++) {
        a->scene_view.collapsed &= ~(UINT32_C(1)<<(unsigned)parent);
        parent=ps_scene_parent_index(scene,(uint32_t)parent);
    }
}
static void scene_camera_plane(app *a,unsigned plane) {
    if(plane>2) return;
    a->camera_plane=plane;
    a->yaw=plane==1?(float)PS_PI/2:0;
    a->pitch=plane==2?(float)PS_PI/2:0;
}
static void scene_camera_2d(app *a,bool enabled) {
    a->camera_2d=enabled;
    if(enabled) {
        scene_camera_plane(a,a->camera_plane);
        a->orthographic=true;
    }
}
static void scene_camera_axes(const app *a,ps_vec3 *right,ps_vec3 *up) {
    if(a->camera_2d) {
        *right=a->camera_plane==1?ps_v3(0,0,-1):ps_v3(1,0,0);
        *up=a->camera_plane==2?ps_v3(0,0,-1):ps_v3(0,1,0);
    } else {
        *right=ps_v3(cos(a->yaw),0,-sin(a->yaw));
        *up=ps_v3(-sin(a->yaw)*sin(a->pitch),cos(a->pitch),-cos(a->yaw)*sin(a->pitch));
    }
}
static bool scene_shortcut(app *a, const SDL_KeyboardEvent *key) {
    if (a->tab != 1 || a->recovery || !(key->mod & SDL_KMOD_ALT) ||
        (key->mod & (SDL_KMOD_CTRL | SDL_KMOD_GUI)))
        return false;
    bool shift = (key->mod & SDL_KMOD_SHIFT) != 0;
    if(key->key==SDLK_2 && !shift) {
        if(!key->repeat) scene_camera_2d(a,!a->camera_2d);
        return true;
    }
    float dx = key->key == SDLK_RIGHT ? 1.f : key->key == SDLK_LEFT ? -1.f : 0.f;
    float dy = key->key == SDLK_UP ? 1.f : key->key == SDLK_DOWN ? -1.f : 0.f;
    if (dx || dy) {
        if (shift || a->camera_2d) {
            ps_vec3 right,up;scene_camera_axes(a,&right,&up);
            a->camera_target = ps_vadd(a->camera_target,
                ps_vscale(ps_vadd(ps_vscale(right, dx), ps_vscale(up, dy)), a->zoom * .025));
        } else {
            a->yaw = remainderf(a->yaw + dx * .08f, 2 * (float)PS_PI);
            a->pitch = fmaxf(-(float)PS_PI / 2,
                             fminf((float)PS_PI / 2, a->pitch + dy * .08f));
        }
        return true;
    }
    if (!shift && (key->key == SDLK_PAGEUP || key->key == SDLK_PAGEDOWN)) {
        a->zoom = fmaxf(1.5f, fminf(12, a->zoom * (key->key == SDLK_PAGEUP ? .9f : 1 / .9f)));
        return true;
    }
    if (shift) return false;
    if (key->key == SDLK_HOME) {
        if (!key->repeat) {
            a->camera_2d=false;
            a->yaw = PS_CAMERA_DEFAULT.yaw;
            a->pitch = PS_CAMERA_DEFAULT.pitch;
            a->zoom = PS_CAMERA_DEFAULT.distance;
            a->camera_target = PS_CAMERA_DEFAULT.target;
            a->orthographic = PS_CAMERA_DEFAULT.orthographic;
        }
        return true;
    }
    if (key->key != SDLK_N && key->key != SDLK_P && key->key != SDLK_H)
        return false;
    if (key->repeat) return true;
    ps_scene_view_sync(&a->scene_view, display_scene(a));
    scene_selection_sync(a);
    if (key->key == SDLK_H) {
        if (a->scene_selected) {
            a->scene_view.hidden |= UINT32_C(1) << a->scene_selected_slot;
            a->scene_selected = false;
        }
        return true;
    }
    int direction = key->key == SDLK_N ? 1 : -1;
    int index = a->scene_selected ? (int)a->scene_selected_slot : direction > 0 ? -1 : 0;
    a->scene_selected = false;
    for (uint32_t step = 0; step < display_scene(a)->count; step++) {
        index = (index + direction + (int)display_scene(a)->count) % (int)display_scene(a)->count;
        if (scene_entry_enabled(a, (uint32_t)index) ||
            ((display_scene(a)->objects[index].shape==PS_GROUP || display_scene(a)->objects[index].shape==PS_FRAME) && ps_scene_view_visible(&a->scene_view,(uint32_t)index))) {
            scene_select_entry(a,(uint32_t)index);
            break;
        }
    }
    return true;
}
static void viewport(app *a, float height) {
    memset(a->scene_label_bounds,0,sizeof a->scene_label_bounds);
    struct nk_context *ui = a->ui;
    nk_layout_row_dynamic(ui, height, 1);
    struct nk_rect r;
    enum nk_widget_layout_states widget_state = nk_widget(&r, ui);
    if(ui->current->layout->flags & NK_WINDOW_ROM) widget_state=NK_WIDGET_ROM;
    bool framed=laboratory_visible(a);
    if(framed)r=laboratory_scene_prepare(a,r);
    a->scene_viewport_bounds = r;
    struct nk_input *input = &ui->input;
    bool camera_input=widget_state==NK_WIDGET_VALID && nk_input_is_mouse_hovering_rect(input,r) &&
        (!framed || !nk_input_is_mouse_hovering_rect(input,a->laboratory_scene_select));
    if (camera_input) {
        if (!a->camera_2d && nk_input_is_mouse_down(input, NK_BUTTON_RIGHT)) {
            a->yaw -= input->mouse.delta.x * .008f;
            a->pitch += input->mouse.delta.y * .008f;
            a->pitch = fmaxf(-(float)PS_PI / 2, fminf((float)PS_PI / 2, a->pitch));
            a->yaw = remainderf(a->yaw, 2 * (float)PS_PI);
        }
        if (nk_input_is_mouse_down(input, NK_BUTTON_MIDDLE) ||
            (a->camera_2d && nk_input_is_mouse_down(input, NK_BUTTON_RIGHT))) {
            double scale = a->zoom / fmaxf(r.h, 1);
            ps_vec3 right,up;scene_camera_axes(a,&right,&up);
            a->camera_target =
                ps_vadd(a->camera_target, ps_vadd(ps_vscale(right, -input->mouse.delta.x * scale),
                                                  ps_vscale(up, input->mouse.delta.y * scale)));
        }
        a->zoom = fmaxf(1.5f, fminf(12, a->zoom * expf(-input->mouse.scroll_delta.y * .1f)));
    }
    ps_camera camera = {a->yaw,          a->pitch,        a->zoom, a->camera_target,
                        a->orthographic, a->show_vectors, a->show_grid};
    int w, h, pw, ph;
    SDL_GetWindowSize(a->window, &w, &h);
    SDL_GetWindowSizeInPixels(a->window, &pw, &ph);
    int width = (int)fmaxf(1, r.w * (float)pw / (float)(w ? w : 1));
    int pixels = (int)fmaxf(1, r.h * (float)ph / (float)(h ? h : 1));
    ps_scene visible = *display_scene(a);
    uint32_t visible_slots[PS_MAX_OBJECTS];
    ps_mat4 transforms[PS_MAX_OBJECTS];
    if(ps_scene_transforms(&visible,transforms)!=PS_OK)return;
    for (uint32_t i = 0; i < display_scene(a)->count; i++) {
        const ps_object *o = &display_scene(a)->objects[i];
        (void)o;
        visible_slots[i]=i;
        if(!scene_entry_enabled(a,i))visible.objects[i].color=0;
    }
    /* Startup preferences can be loaded before the GL renderer exists. Use the
     * actual frame palette here as well as in explicit theme changes. */
    struct nk_color scene_clear=UI_COLOR(canvas),scene_grid=UI_COLOR(plot_grid);
    ps_graphics_background(a->graphics,scene_clear.r,scene_clear.g,scene_clear.b);
    ps_graphics_scene_colors(a->graphics,((uint32_t)scene_clear.r<<24)|((uint32_t)scene_clear.g<<16)|((uint32_t)scene_clear.b<<8)|255,
        ((uint32_t)scene_grid.r<<24)|((uint32_t)scene_grid.g<<16)|((uint32_t)scene_grid.b<<8)|255);
    unsigned texture = ps_graphics_scene(a->graphics, &visible, &camera, width, pixels);
    if (texture) {
        if (a->profiler) a->profile_frame.has_scene = ps_graphics_scene_stats(a->graphics, &a->profile_frame.scene);
        bool picking = camera_input &&
                       nk_input_is_mouse_pressed(input, NK_BUTTON_LEFT);
        scene_selection_sync(a);
        if (picking) {
            int hit = ps_graphics_pick(a->graphics, (input->mouse.pos.x-r.x)/r.w,
                                       (input->mouse.pos.y-r.y)/r.h);
            a->scene_selected = hit >= 0;
            if (hit >= 0) {
                scene_select_entry(a,visible_slots[hit]);
            }
        }
        struct nk_image image = nk_image_id((int)texture);
        nk_draw_image(nk_window_get_canvas(ui), r, &image, nk_rgb(255, 255, 255));
        struct nk_command_buffer *canvas = nk_window_get_canvas(ui);
        struct nk_rect previous = canvas->clip;
        float left = fmaxf(previous.x, r.x), top = fmaxf(previous.y, r.y);
        float right = fminf(previous.x + previous.w, r.x + r.w),
              bottom = fminf(previous.y + previous.h, r.y + r.h);
        nk_push_scissor(canvas, nk_rect(left, top, fmaxf(0, right - left), fmaxf(0, bottom - top)));
        const struct nk_user_font *font = ui->style.font;
        struct nk_rect placed[PS_MAX_OBJECTS+3];
        unsigned placed_count = 0;
        if(framed) {
            struct nk_rect controls[]={a->laboratory_scene_label,a->laboratory_scene_status,a->laboratory_scene_select};
            float padding=4*a->preferences.ui_size/16.f;
            for(unsigned i=0;i<3;i++)if(controls[i].w>0) {
                struct nk_rect c=controls[i];placed[placed_count++]=nk_rect(c.x-padding,c.y-padding,c.w+2*padding,c.h+2*padding);
            }
        }
        for (uint32_t i = 0; i < visible.count; i++) {
            const ps_object *o = &visible.objects[i];
            float x, y;ps_vec3 anchor;
            if(ps_transform_point(transforms[i],o->a,&anchor)!=PS_OK)continue;
            if (o->shape != PS_LABEL || !o->text[0] || !(o->color & 255) ||
                !ps_graphics_project(&camera, anchor, (double)width / pixels, &x, &y))
                continue;
            int length = (int)strlen(o->text);
            float text_width = font->width(font->userdata, font->height, o->text, length);
            struct nk_rect label = nk_rect(r.x + x * r.w + 7, r.y + y * r.h - font->height - 4,
                                           text_width + 8, font->height + 4);
            float preferred_y = label.y;
            if (!place_label(&label, r, placed, placed_count))
                continue;
            placed[placed_count++] = label;
            a->scene_label_bounds[visible_slots[i]] = label;
            if (picking && nk_input_is_mouse_hovering_rect(input, label)) {
                scene_select_entry(a,visible_slots[i]);
            }
            if (fabsf(label.y - preferred_y) > 1)
                nk_stroke_line(canvas, r.x + x * r.w, r.y + y * r.h, label.x,
                               label.y + label.h * .5f, 1, nk_rgba(140, 164, 187, 160));
            nk_fill_rect(canvas, label, 3, nk_rgba(12, 22, 33, 220));
            label.x += 4;
            label.w -= 8;
            label.y += 2;
            uint32_t c = o->color;
            nk_draw_text(canvas, label, o->text, length, font, nk_rgba(0, 0, 0, 0),
                         nk_rgba((int)(c >> 24), (int)((c >> 16) & 255), (int)((c >> 8) & 255),
                                 (int)(c & 255)));
        }
        nk_push_scissor(canvas, previous);
        if (a->timeline_error[0])
            nk_draw_text(canvas, nk_rect(r.x + 10, r.y + 10, r.w - 20, 22), a->timeline_error,
                         (int)strlen(a->timeline_error), font, nk_rgba(0, 0, 0, 0), UI_COLOR(error));
        if (a->timeline.seen && !a->timeline_scenes) {
            const char *message = "Keine Szenenaufzeichnung · Zeitleiste zeigt Messwerte";
            nk_draw_text(canvas, nk_rect(r.x + 10, r.y + (a->timeline_error[0] ? 36 : 10), r.w - 20, 22), message,
                         (int)strlen(message), font, nk_rgba(0, 0, 0, 0), UI_COLOR(muted));
        }
    } else {
        nk_fill_rect(nk_window_get_canvas(ui), r, 0, nk_rgb(70, 20, 25));
        status(a, SDL_GetError());
    }
    if(framed)laboratory_scene_chrome(a);
}
// clang-format off
#include "plot_ui.inc"
// clang-format on
static void plot_draw(app *a, const double *times, const double *values, int count, float height,
                 const char *label, bool scatter, ps_plot_view *view,const ps_graphic_snapshot *comparison) {
    struct nk_context *ui = a->ui;
    double lo = INFINITY, hi = -INFINITY;
    for (int i = 0; i < count; i++)
        if (isfinite(values[i])) {
            lo = fmin(lo, values[i]);
            hi = fmax(hi, values[i]);
        }
    ps_graphic_description description={0};
    bool compared=comparison && ps_graphic_snapshot_describe(comparison,&description)==PS_OK;
    bool have_values = compared || isfinite(lo);
    if (have_values)
        plot_expand_range(&lo, &hi, true);
    double bounds[] = {count ? times[0] : 0, count ? times[count - 1] : 1, lo, hi};
    if(compared)memcpy(bounds,description.axes.full,sizeof bounds);
    bool analysis=a->tab==2 && a->analysis_tab==0 && !a->project_manager && view;
    struct nk_color curve_color=analysis?ui_palette->curves[0]:UI_COLOR(accent);
    if(analysis)analysis_plot_heading(a,view,have_values && (compared || count>1)?bounds:NULL,comparison);
    else {
        nk_layout_row_dynamic(ui, 22, 1);
        nk_label_colored(ui, label, NK_TEXT_LEFT, UI_COLOR(muted));
        if(view)plot_controls(a, view, have_values && count > 1 ? bounds : NULL);
    }
    nk_layout_row_dynamic(ui, height, 1);
    struct nk_rect r;
    nk_widget(&r, ui);
    struct nk_command_buffer *canvas = nk_window_get_canvas(ui);
    nk_fill_rect(canvas, r, 6, UI_COLOR(edit));
    if (!compared && count < 2)
        return;
    if (!have_values) {
        const char *message = "Keine gültigen Messwerte in dieser Vorschau.";
        nk_draw_text(canvas, nk_rect(r.x + 12, r.y + 12, r.w - 24, 24), message,
                     (int)strlen(message), ui->style.font, UI_COLOR(edit),
                     UI_COLOR(muted));
        return;
    }
    if (!compared && !(times[count - 1] > times[0]))
        return;
    struct nk_rect area = analysis?nk_rect(r.x+66,r.y+54,r.w-94,r.h-106):nk_rect(r.x+70,r.y+20,r.w-90,r.h-55);
    if(analysis){nk_draw_text(canvas,nk_rect(area.x,r.y+22,r.w-94,22),label,(int)strlen(label),ui->style.font,UI_COLOR(edit),UI_COLOR(muted));ps_ui_accessibility_label(ui,r,label);}
    ps_plot_view fit;
    ps_plot_view_reset(&fit);
    if (view)
        plot_interact(a, view, area, bounds);
    else
        view = &fit;
    double displayed[4];
    plot_display_bounds(view, bounds, displayed);
    double x_offset = ps_plot_axis_offset(displayed[0], displayed[1]);
    double y_offset = ps_plot_axis_offset(displayed[2], displayed[3]);
    if (x_offset || y_offset) {
        char note[192];
        snprintf(note, sizeof note, "Offset: Zeit %.17g s · Wert %.17g · Achsenwerte addieren",
                 x_offset, y_offset);
        nk_draw_text(canvas, nk_rect(r.x + 8, r.y + 1, r.w - 16, 18), note, (int)strlen(note),
                     ui->style.font, UI_COLOR(edit), UI_COLOR(muted));
    }
    int ticks = area.h < 80 ? 3 : 5;
    if(analysis)for(unsigned i=0;i<6;i++){float x=area.x+area.w*(float)i/5;nk_stroke_line(canvas,x,area.y,x,area.y+area.h,1,UI_COLOR(plot_grid));}
    for (int i = 0; i < ticks; i++) {
        float y = area.y + area.h * (float)i / (float)(ticks - 1);
        nk_stroke_line(canvas, area.x, y, area.x + area.w, y, 1, UI_COLOR(plot_grid));
        char text[40];
        double tick=plot_tick(displayed[2]-y_offset,displayed[3]-y_offset,1-(double)i/(ticks-1));
        if(analysis)plot_axis_label(text,sizeof text,tick,displayed[2]-y_offset,displayed[3]-y_offset);
        else snprintf(text,sizeof text,"%.4g",tick);
        nk_draw_text(canvas, nk_rect(r.x + 4, y - 8, 62, 18), text, (int)strlen(text),
                     ui->style.font, UI_COLOR(edit), UI_COLOR(muted));
    }
    struct nk_rect previous_clip = canvas->clip;
    nk_push_scissor(canvas, plot_intersection(area, previous_clip));
    for(uint32_t j=0;j<(compared?description.plot.curves:1);j++) {
        const ps_curve_data *curve=NULL;const uint8_t *mask=NULL;
        if(compared) {
            ps_report_curve_view(ps_graphic_snapshot_report(comparison),0,j,&curve);
            ps_report_curve_mask(ps_graphic_snapshot_report(comparison),0,j,&mask);
        }
        const double *t=compared?curve->x:times,*v=compared?curve->y:values;
        uint32_t n=compared?curve->count:(uint32_t)count;bool dots=compared?curve->kind==PS_PLOT_SCATTER:scatter;
        struct nk_color color=compared?ui_palette->curves[j]:curve_color;
        double dash=compared && j!=description.reference && !(description.reference==PS_GRAPHIC_NO_REFERENCE && !j)?(j%2?10:3):0,phase=0;
        for(uint32_t i=0;i<n;i++) {
            if(!isfinite(v[i]) || (mask && !(mask[i]&1))){phase=0;continue;}
            double x2=plot_fraction(view,bounds,0,t[i]),y2=plot_fraction(view,bounds,1,v[i]);
            bool before=i && isfinite(v[i-1]) && (!mask || ((mask[i-1]&1) && !(mask[i]&2)));
            bool after=i+1<n && isfinite(v[i+1]) && (!mask || ((mask[i+1]&1) && !(mask[i+1]&2)));
            if(dots || (!before && !after))plot_dot(canvas,area,x2,y2,2,color);
            if(!before)phase=0;
            if(!dots && before)plot_pattern(canvas,area,plot_fraction(view,bounds,0,t[i-1]),plot_fraction(view,bounds,1,v[i-1]),x2,y2,dash,&phase,color);
        }
    }
    if (a->tab == 1) {
        double x = plot_fraction(view, bounds, 0, display_time(a));
        if (x >= 0 && x <= 1) {
            float position = area.x + (float)x * area.w;
            nk_stroke_line(canvas, position, area.y, position, area.y + area.h, 1,
                           UI_COLOR(accent));
        }
    }
    nk_push_scissor(canvas, previous_clip);
    for (int endpoint = 0; endpoint < (analysis?6:2); endpoint++) {
        char text[48];
        double tick=analysis?plot_tick(displayed[0]-x_offset,displayed[1]-x_offset,endpoint/5.):displayed[endpoint]-x_offset;
        snprintf(text, sizeof text, analysis?"%.5g":"%.5g s",tick);
        float text_width = ui->style.font->width(ui->style.font->userdata, ui->style.font->height,
                                                 text, (int)strlen(text));
        float x=analysis?area.x+area.w*(float)endpoint/5-text_width/2:endpoint?area.x+area.w-text_width:area.x;
        nk_draw_text(canvas, nk_rect(x, area.y + area.h + 10, text_width + 1, 22), text,
                     (int)strlen(text), ui->style.font, UI_COLOR(edit), UI_COLOR(muted));
    }
    if(analysis) {
        nk_draw_text(canvas,nk_rect(area.x+area.w-70,area.y+area.h+40,70,22),"Zeit [s]",8,ui->style.font,UI_COLOR(edit),UI_COLOR(muted));
        char range[160],preview[160];snprintf(range,sizeof range,"Zeitachse %.6g–%.6g s",displayed[0],displayed[1]);
        if(compared)snprintf(preview,sizeof preview,"%u %s%s",description.plot.curves,description.plot.curves==1?"Lauf":"Läufe",description.reduced?" · reduzierte Vorschau, Spitzen bleiben erhalten":" · alle Messpunkte");
        else snprintf(preview,sizeof preview,"Vorschau %d / %llu Messpunkte",count,(unsigned long long)a->data.total);
        float available=nk_window_get_content_region(ui).w,half=(available-ui->style.window.spacing.x)/2;
        bool stack=ui->style.font->width(ui->style.font->userdata,ui->style.font->height,range,(int)strlen(range))>half ||
            ui->style.font->width(ui->style.font->userdata,ui->style.font->height,preview,(int)strlen(preview))>half;
        if(stack) {
            nk_layout_row_dynamic(ui,ui->style.font->height+6,1);nk_label_colored(ui,range,NK_TEXT_LEFT,UI_COLOR(muted));
            nk_layout_row_dynamic(ui,documentation_height(ui->style.font,preview,strlen(preview),available)+4,1);nk_label_colored_wrap(ui,preview,UI_COLOR(muted));
        } else {
            nk_layout_row_dynamic(ui,49,2);nk_label_colored(ui,range,NK_TEXT_LEFT,UI_COLOR(muted));nk_label_colored(ui,preview,NK_TEXT_RIGHT,UI_COLOR(muted));
        }
    }
}
static void plot(app *a,const double *times,const double *values,int count,float height,
    const char *label,bool scatter,ps_plot_view *view) {
    plot_draw(a,times,values,count,height,label,scatter,view,NULL);
}
static struct nk_text_edit *editor_search_target(app *a) {
    if(a->recovery || a->document_pending || a->dialog_pending || a->project_manager ||
       a->layout_manager || a->workspace_manager || a->channel_unit_manager || a->run_details_manager) return NULL;
    workspace_document *doc=active_document(a);
    if(a->tab==8 && doc) return doc->recovery?NULL:&doc->edit;
    if(a->loaded && a->tab==0) return a->analysis_only?&a->analysis:&a->experiment;
    if(a->loaded && a->tab==2 && a->analysis_tab==1) return &a->analysis;
    return NULL;
}
static size_t editor_search_byte(struct nk_text_edit *edit,int position) {
    int bytes=nk_str_len_char(&edit->string),len=0;nk_rune rune;
    const char *text=nk_str_get_const(&edit->string);
    if(bytes<=0 || !text || position<=0)return 0;
    if(position>=nk_str_len(&edit->string))return (size_t)bytes;
    const char *at=nk_str_at_const(&edit->string,position,&rune,&len);
    return at?(size_t)(at-text):(size_t)bytes;
}
static void editor_search_open(app *a) {
    if(!editor_search_target(a))return;
    completion_close(a);
    a->show_search=true;a->search_focus=true;a->search_keyboard=true;
}
static void find_text_direction(app *a, struct nk_text_edit *edit, bool replace, bool backward) {
    const char *text = nk_str_get_const(&edit->string);
    int bytes = nk_str_len_char(&edit->string);
    if (!a->find[0] || !text)
        return;
    char *copy = malloc((size_t)bytes + 1);
    if (!copy)
        return;
    memcpy(copy, text, (size_t)bytes);
    copy[bytes] = 0;
    int first_selection=edit->select_start<edit->select_end?edit->select_start:edit->select_end;
    size_t cursor=editor_search_byte(edit,backward?first_selection:edit->cursor);
    int len = 0;
    nk_rune rune;
    char *found = NULL;
    if(replace) {
        int first=edit->select_start<edit->select_end?edit->select_start:edit->select_end;
        int last=edit->select_start<edit->select_end?edit->select_end:edit->select_start;
        if(first>=0 && first<last && last<=nk_str_len(&edit->string)) {
            const char *begin=nk_str_at_const(&edit->string,first,&rune,&len);
            const char *end=last==nk_str_len(&edit->string)?text+bytes:nk_str_at_const(&edit->string,last,&rune,&len);
            if(begin && end && (size_t)(end-begin)==strlen(a->find) && !memcmp(begin,a->find,(size_t)(end-begin)))
                found=copy+(begin-text);
        }
    }
    if(!found) {
        ps_editor_search_result result;
        if(ps_editor_search(copy,(size_t)bytes,a->find,strlen(a->find),cursor,backward,&result) && result.found)
            found=copy+result.begin;
    }
    if (found) {
        int at = nk_utf_len(copy, (int)(found - copy)),
            n = nk_utf_len(a->find, (int)strlen(a->find));
        edit->select_start = at;
        edit->select_end = at + n;
        edit->cursor = at + n;
        unsigned line = 0;
        for (const char *c = copy; c < found; c++)
            if (*c == '\n')
                line++;
        edit->scrollbar.y = (float)line * (a->font_code->height + editor_row_padding(a));
        const char *line_begin=found;
        while(line_begin>copy && line_begin[-1]!='\n')--line_begin;
        float hit_x=a->font_code->width(a->font_code->userdata,a->font_code->height,line_begin,(int)(found-line_begin));
        float hit_width=a->font_code->width(a->font_code->userdata,a->font_code->height,a->find,(int)strlen(a->find));
        float visible_width=fmaxf(24,a->source_editor_bounds.w-2*a->ui->style.edit.padding.x-10);
        edit->scrollbar.x=fmaxf(0,hit_x+hit_width-visible_width);
        if (replace) {
            edit->mode = NK_TEXT_EDIT_MODE_INSERT;
            int replacement_bytes=(int)strlen(a->replace);
            if(replacement_bytes) {
                if(!nk_textedit_paste(edit,a->replace,replacement_bytes)) {
                    status(a,"Ersetzen fehlgeschlagen. Der Quelltext bleibt erhalten.");free(copy);return;
                }
            } else nk_textedit_delete_selection(edit);
            if (edit == &a->experiment) {
                a->dirty = true;
                invalidate_build(a);
            } else if (edit == &a->analysis) {
                a->analysis_dirty = true;
                invalidate_build(a);
            } else document_changed(a, edit);
        }
    } else
        status(a, "Suchtext nicht gefunden.");
    free(copy);
}
static void find_text(app *a,struct nk_text_edit *edit,bool replace) {
    find_text_direction(a,edit,replace,false);
}
static bool c_keyword(const char *word, size_t length) {
    static const char *keywords[] = {
        "auto",    "break",  "case",     "char",    "const",    "continue",      "default",
        "do",      "double", "else",     "enum",    "extern",   "float",         "for",
        "goto",    "if",     "inline",   "int",     "long",     "register",      "restrict",
        "return",  "short",  "signed",   "sizeof",  "static",   "struct",        "switch",
        "typedef", "union",  "unsigned", "void",    "volatile", "while",         "bool",
        "true",    "false",  "NULL",     "_Atomic", "_Bool",    "_Static_assert"};
    for (size_t i = 0; i < sizeof keywords / sizeof keywords[0]; i++)
        if (strlen(keywords[i]) == length && !memcmp(word, keywords[i], length))
            return true;
    return false;
}
static bool language_keyword(const char *word, size_t length) {
    static const char *keywords[] = {
        "break", "case", "continue", "default", "else", "enum", "false", "for", "func",
        "if", "import", "in", "let", "mutating", "nil", "return", "self", "static",
        "struct", "switch", "true", "var", "while", "Int64", "Float64", "Bool", "String",
        "Void", "Vec2", "Vec3", "Vec4", "Quat", "Unit", "Quantity", "Channel", "Dataset", "Series", "Plot",
        "Distribution", "SensorConfig", "Sensor", "Measurement", "Table", "Body",
        "Contacts", "ContactSolver", "ContactResult", "DistanceJoint", "JointResult", "Submersion",
        "ContactConstraint", "JointConstraint", "ConstraintResult", "Sweep", "Aabb", "CollisionPair", "Mat3", "Mat4", "Bezier3", "Optional"};
    for (size_t i = 0; i < sizeof keywords / sizeof keywords[0]; i++)
        if (strlen(keywords[i]) == length && !memcmp(word, keywords[i], length))
            return true;
    return false;
}
/* Overlay lexical colors on the ordinary Nuklear editor; selection and cursor stay native.
 * Only the visible lines generate draw commands; scanning preserves multiline comments. */
static void syntax_text(app *a, struct nk_text_edit *edit, struct nk_rect bounds) {
    int kind = document_language(a, edit);
    bool language = kind == 1;
    struct nk_context *ui = a->ui;
    const struct nk_user_font *font = ui->style.font;
    struct nk_command_buffer *canvas = nk_window_get_canvas(ui);
    struct nk_rect area =
        nk_rect(bounds.x + ui->style.edit.padding.x + ui->style.edit.border,
                bounds.y + ui->style.edit.padding.y + ui->style.edit.border,
                bounds.w - 2 * (ui->style.edit.padding.x + ui->style.edit.border) -
                    ui->style.edit.scrollbar_size.x,
                bounds.h - 2 * (ui->style.edit.padding.y + ui->style.edit.border));
    struct nk_rect previous_clip = canvas->clip;
    nk_push_scissor(canvas, area);
    const char *text = nk_str_get_const(&edit->string);
    size_t size = (size_t)nk_str_len_char(&edit->string), at = 0;
    float row = font->height + ui->style.edit.row_padding;
    float x = area.x - edit->scrollbar.x, y = area.y - edit->scrollbar.y;
    size_t block_depth = 0;
    bool triple_string = false;
    while (at < size && y < area.y + area.h) {
        if (text[at] == '\n') {
            at++;
            x = area.x - edit->scrollbar.x;
            y += row;
            continue;
        }
        if (text[at] == '\r') {
            at++;
            continue;
        }
        size_t begin = at;
        struct nk_color color = UI_COLOR(code_text);
        if (kind < 0) {
            nk_rune rune;
            int n = nk_utf_decode(text + at, &rune, (int)(size - at));
            at += (size_t)(n > 0 ? n : 1);
        } else if (triple_string ||
            (language && at + 2 < size && text[at] == '"' && text[at + 1] == '"' &&
             text[at + 2] == '"')) {
            color = UI_COLOR(code_string);
            if (!triple_string) {
                at += 3;
                triple_string = true;
            }
            while (at < size && text[at] != '\n' && text[at] != '\r') {
                if (text[at] == '\\' && at + 1 < size && text[at + 1] != '\n' &&
                    text[at + 1] != '\r') {
                    at += 2;
                } else if (at + 2 < size && text[at] == '"' && text[at + 1] == '"' &&
                           text[at + 2] == '"') {
                    at += 3;
                    triple_string = false;
                    break;
                } else {
                    at++;
                }
            }
        } else if (block_depth || (at + 1 < size && text[at] == '/' && text[at + 1] == '*')) {
            color = UI_COLOR(code_comment);
            if (!block_depth) {
                at += 2;
                block_depth = 1;
            }
            while (at < size && text[at] != '\n') {
                if (language && at + 1 < size && text[at] == '/' && text[at + 1] == '*') {
                    block_depth++;
                    at += 2;
                } else if (at + 1 < size && text[at] == '*' && text[at + 1] == '/') {
                    at += 2;
                    if (!--block_depth)
                        break;
                } else
                    at++;
            }
        } else if ((at + 1 < size && text[at] == '/' && text[at + 1] == '/') ||
                   (!language && text[at] == '#')) {
            color = text[at] == '#' ? UI_COLOR(code_preprocessor) : UI_COLOR(code_comment);
            while (at < size && text[at] != '\n' && text[at] != '\r')
                at++;
        } else if (text[at] == '"' || (!language && text[at] == '\'')) {
            color = UI_COLOR(code_string);
            char quote = text[at++];
            while (at < size && text[at] != '\n') {
                if (text[at] == '\\' && at + 1 < size && text[at + 1] != '\n') {
                    at += 2;
                    continue;
                }
                if (text[at++] == quote)
                    break;
            }
        } else if ((language && ps_lang_identifier_width(text + at, size - at, 1)) ||
                   (!language && (isalpha((unsigned char)text[at]) || text[at] == '_'))) {
            if (language) {
                at += ps_lang_identifier_width(text + at, size - at, 1);
                while (at < size) {
                    size_t width = ps_lang_identifier_width(text + at, size - at, 0);
                    if (!width)
                        break;
                    at += width;
                }
            } else {
                at++;
                while (at < size && (isalnum((unsigned char)text[at]) || text[at] == '_'))
                    at++;
            }
            if (language ? language_keyword(text + begin, at - begin)
                         : c_keyword(text + begin, at - begin))
                color = UI_COLOR(code_keyword);
            else if (at - begin >= 3 && text[begin] == 'p' && text[begin + 1] == 's' &&
                     text[begin + 2] == '_')
                color = UI_COLOR(code_type);
        } else if (isdigit((unsigned char)text[at])) {
            color = UI_COLOR(code_number);
            at++;
            while (at < size && (isalnum((unsigned char)text[at]) || text[at] == '.' ||
                                 (language && text[at] == '_')))
                at++;
        } else {
            nk_rune rune;
            int n = nk_utf_decode(text + at, &rune, (int)(size - at));
            at += (size_t)(n > 0 ? n : 1);
        }
        int length = (int)(at - begin);
        float width = font->width(font->userdata, font->height, text + begin, length);
        if (y + row >= area.y && x + width >= area.x && x < area.x + area.w)
            nk_draw_text(canvas,
                         nk_rect(x, y + ui->style.edit.row_padding / 2, width + 1, font->height),
                         text + begin, length, font, nk_rgba(0, 0, 0, 0), color);
        x += width;
    }
    nk_push_scissor(canvas, previous_clip);
}
#include "completion_ui.inc"
static void editor_caret(app *a,struct nk_text_edit *edit,struct nk_rect bounds,bool changed) {
    struct nk_context *ui=a->ui;const struct nk_user_font *font=ui->style.font;
    const char *text=nk_str_get_const(&edit->string);if(!text)text="";
    nk_rune rune;int length;
    int bytes=nk_str_len_char(&edit->string);
    /* An empty nk_str may retain allocated storage while get_const returns
     * null. Keep line and cursor within the same fallback string object. */
    const char *cursor=bytes>0?nk_str_at_const(&edit->string,edit->cursor,&rune,&length):NULL;
    if(!cursor)cursor=text+bytes;
    const char *line=text;unsigned lines=0;
    for(const char *p=text;p<cursor;p++)if(*p=='\n'){line=p+1;lines++;}
    float x=bounds.x+ui->style.edit.padding.x+ui->style.edit.border-edit->scrollbar.x;
    x+=font->width(font->userdata,font->height,line,(int)(cursor-line));
    float y=bounds.y+ui->style.edit.padding.y+ui->style.edit.border-edit->scrollbar.y+lines*(font->height+ui->style.edit.row_padding)+ui->style.edit.row_padding/2;
    a->editor_caret=nk_rect(x,y,1,font->height);
    double now=ps_clock();
    if(a->caret_edit!=edit || a->caret_cursor!=edit->cursor || changed || nk_input_is_mouse_pressed(&ui->input,NK_BUTTON_LEFT))a->caret_activity=now;
    a->caret_edit=edit;a->caret_cursor=edit->cursor;
    if(edit->active && edit->select_start==edit->select_end && !(ui->current->layout->flags&NK_WINDOW_ROM) && fmod(now-a->caret_activity,1.05)<.60) {
        struct nk_command_buffer *canvas=nk_window_get_canvas(ui);struct nk_rect clip=canvas->clip;
        nk_push_scissor(canvas,nk_rect(bounds.x+ui->style.edit.padding.x,bounds.y+ui->style.edit.padding.y,bounds.w-2*ui->style.edit.padding.x-ui->style.edit.scrollbar_size.x,bounds.h-2*ui->style.edit.padding.y));
        nk_fill_rect(canvas,a->editor_caret,0,UI_COLOR(text));nk_push_scissor(canvas,clip);
    }
}
static void editor(app *a, struct nk_text_edit *edit, float height) {
    struct nk_context *ui = a->ui;
    if(a->completion_active && a->completion_edit!=edit)completion_close(a);
    height=fmaxf(100,height);
    nk_style_push_font(ui, a->font_code);
    nk_layout_row_begin(ui, NK_STATIC, height, 2);
    nk_layout_row_push(ui, 44);
    struct nk_rect gutter;
    nk_widget(&gutter, ui);
    nk_layout_row_push(ui, nk_window_get_content_region(ui).w - 60);
    int before =
        nk_str_len_char(&edit->string); /* Hash detects replacements of identical length, too. */
    uint32_t hash =
        ps_crc32((const unsigned char *)nk_str_get_const(&edit->string), (size_t)before);
    struct nk_rect editor_bounds = nk_widget_bounds(ui);
    a->source_editor_bounds=editor_bounds;
    /* The overlay belongs to the complete code pane, including its gutter and
     * scroll rail; text-input padding must not become an extra right margin. */
    a->source_editor_frame=nk_rect(ui->current->bounds.x,gutter.y,ui->current->bounds.w,editor_bounds.h);
    a->search_edit=edit;
    if (active_document(a) && edit == &active_document(a)->edit)
        a->document_bounds[6] = editor_bounds;
    struct nk_color transparent = nk_rgba(0, 0, 0, 0);
    if(a->completion_active && !edit->active && !ui->input.mouse.buttons[NK_BUTTON_LEFT].clicked &&
       !ui->input.mouse.buttons[NK_BUTTON_LEFT].down)nk_edit_focus(ui,NK_EDIT_ALWAYS_INSERT_MODE);
    if(a->completion_focus_edit==edit){nk_edit_focus(ui,NK_EDIT_ALWAYS_INSERT_MODE);a->completion_focus_edit=NULL;}
    nk_style_push_color(ui, &ui->style.edit.text_normal, transparent);
    nk_style_push_color(ui, &ui->style.edit.text_hover, transparent);
    nk_style_push_color(ui, &ui->style.edit.text_active, transparent);
    nk_style_push_color(ui, &ui->style.edit.selected_text_normal, transparent);
    nk_style_push_color(ui, &ui->style.edit.selected_text_hover, transparent);
    nk_style_push_color(ui, &ui->style.edit.selected_normal, UI_COLOR(selection_active));
    nk_style_push_color(ui, &ui->style.edit.selected_hover, UI_COLOR(selection_active));
    nk_style_push_color(ui, &ui->style.edit.cursor_normal, transparent);
    nk_style_push_color(ui, &ui->style.edit.cursor_hover, transparent);
    nk_style_push_color(ui, &ui->style.edit.cursor_text_normal, transparent);
    nk_style_push_color(ui, &ui->style.edit.cursor_text_hover, transparent);
    /* The suggestion list owns pointer input, while the editor keeps its
     * keyboard focus and processes typed text before accepting a suggestion. */
    struct nk_mouse pointer=ui->input.mouse;
    bool search_pointer=a->show_search && nk_input_is_mouse_hovering_rect(&ui->input,a->search_island_bounds);
    if(search_pointer && nk_input_is_mouse_pressed(&ui->input,NK_BUTTON_LEFT))a->search_keyboard=true;
    if(a->show_search && nk_input_is_mouse_pressed(&ui->input,NK_BUTTON_LEFT) && !search_pointer &&
       nk_input_is_mouse_hovering_rect(&ui->input,editor_bounds))a->search_keyboard=false;
    bool covered=search_pointer || (a->completion_active && nk_input_is_mouse_hovering_rect(&ui->input,a->completion_list_bounds));
    struct nk_keyboard keyboard=ui->input.keyboard;
    int saved_start=edit->select_start,saved_end=edit->select_end,saved_cursor=edit->cursor;
    struct nk_vec2 saved_scroll=edit->scrollbar;
    bool searching=a->show_search && (a->search_keyboard || a->search_focus);
    bool search_scroll=searching && !search_pointer && nk_input_is_mouse_hovering_rect(&ui->input,editor_bounds) &&
        (ui->input.mouse.scroll_delta.x!=0 || ui->input.mouse.scroll_delta.y!=0);
    /* Nuklear exposes the text scrollbar only for an active edit. Route this
     * wheel frame with keyboard input masked, then restore the search owner. */
    if(search_scroll)nk_edit_focus(ui,NK_EDIT_ALWAYS_INSERT_MODE);
    if(searching)memset(&ui->input.keyboard,0,sizeof ui->input.keyboard);
    if(covered) {
        for(unsigned i=0;i<NK_BUTTON_MAX;i++){ui->input.mouse.buttons[i].clicked=0;ui->input.mouse.buttons[i].down=0;}
        ui->input.mouse.pos=nk_vec2(-1,-1);ui->input.mouse.scroll_delta=nk_vec2(0,0);
    }
    nk_edit_buffer(ui, NK_EDIT_BOX | NK_EDIT_ALLOW_TAB | NK_EDIT_PRESERVE_UNDO | NK_EDIT_ALWAYS_INSERT_MODE, edit, nk_filter_default);
    if(searching) {
        ui->input.keyboard=keyboard;
        edit->select_start=saved_start;edit->select_end=saved_end;edit->cursor=saved_cursor;
        if(!search_scroll)edit->scrollbar=saved_scroll;
        edit->active=false;
    }
    if(covered)ui->input.mouse=pointer;
    bool accepted=a->completion_accept_pending;
    if(a->completion_active) {
        if(completion_refresh(a) && a->completion_accept_pending)completion_commit(a);
    }
    for (int i = 0; i < 11; i++)
        nk_style_pop_color(ui);
    syntax_text(a, edit, editor_bounds);
    int after = nk_str_len_char(&edit->string);
    bool changed=before!=after || hash!=ps_crc32((const unsigned char *)nk_str_get_const(&edit->string),(size_t)after);
    editor_caret(a,edit,editor_bounds,changed);
    if(changed) {
        if (edit == &a->experiment) {
            a->dirty = true;
            invalidate_build(a);
        } else if (edit == &a->analysis) {
            a->analysis_dirty = true;
            invalidate_build(a);
        } else document_changed(a, edit);
    }
    if(a->completion_typed && changed && !accepted && edit->active && completion_target(a)==edit && !a->completion_active && document_language(a,edit)>=0) {
        const char *text=nk_str_get_const(&edit->string);nk_rune rune;int n;
        const char *at=nk_str_at_const(&edit->string,edit->cursor,&rune,&n);
        size_t cursor=at?(size_t)(at-text):(size_t)after;ps_completion_query query;
        if(text && ps_completion_prepare(text,(size_t)after,cursor,document_language(a,edit)==1,&query)==PS_OK &&
           (query.member || strlen(query.prefix)>=2) && ps_completion_matches(&query,NULL,0))completion_open(a,edit);
    }
    a->completion_typed=false;
    nk_layout_row_end(ui);
    struct nk_command_buffer *canvas = nk_window_get_canvas(ui);
    nk_push_scissor(canvas, gutter);
    float line_h = ui->style.font->height + ui->style.edit.row_padding;
    int first = (int)(edit->scrollbar.y / line_h);
    for (int i = first; i < first + (int)(height / line_h) + 2; i++) {
        char number[20];
        snprintf(number, sizeof number, "%d", i + 1);
        float number_width=ui->style.font->width(ui->style.font->userdata,ui->style.font->height,number,(int)strlen(number));
        nk_draw_text(
            canvas,
            nk_rect(gutter.x+fmaxf(0,35-number_width),
                    gutter.y + (float)i * line_h - edit->scrollbar.y + ui->style.edit.padding.y, 42,
                    line_h),
            number, (int)strlen(number), ui->style.font, UI_COLOR(gutter), UI_COLOR(gutter_text));
    }
    nk_push_scissor(canvas, nk_window_get_content_region(ui));
    nk_style_pop_font(ui);
}
// clang-format off
static bool documentation_window_open(app *a);
static bool panel_is_detached(const app *a,unsigned panel);
static void panel_pull_handle(app *a,unsigned panel,struct nk_rect bounds);
static void panel_pull_input(app *a,float width,float height);
static void panel_pull_cancel(app *a);
static void timeline_design_draw(app *a);
static void panel_windows_destroy(app *a);
#include "editor_search_ui.inc"
static bool documentation_fonts_prepare(app *a,unsigned size,unsigned code_size);
static bool documentation_fonts_prepare_sizes(app *a,unsigned size,unsigned code_size,unsigned ui_size,unsigned editor_size);
#include "documentation_ui.inc"
#include "api_reference_ui.inc"
static struct nk_font *graphic_font_load(void *user,struct nk_font_atlas *atlas,float height,bool strong,
                                        const unsigned *ranges,char family[96]);
static void style(struct nk_context *ui);
static void toolbar_keyboard_close(app *a);
#include "graphic_export_ui.inc"
#include "report_ui.inc"
#include "library_ui.inc"
static void layouts_start(app *a);
static void channel_units_start(app *a);
#include "design_ui.inc"
#include "panel_windows.inc"
// clang-format on
static struct nk_font *system_font_sampling_demand(struct nk_font_atlas *atlas,const char *root,float size,bool code,bool title,
    unsigned char horizontal,unsigned char vertical,const nk_rune *demand,char family[96],bool transport_symbols) {
    static const nk_rune ui_ranges[] = {0x20,0x17f,0x192,0x192,0x300,0x4ff,0x1d40,0x1d40,0x1d63,0x1d63,0x1d65,0x1d65,
                                      0x1e00,0x1eff,0x2000,0x22ff,0x2500,0x257f,0x25cf,0x25cf,0x2c7c,0x2c7c,0};
    static const nk_rune code_ranges[] = {0x20,0x17f,0x192,0x192,0x300,0x4ff,0x1d40,0x1d40,0x1d63,0x1d63,0x1d65,0x1d65,
                                        0x1e00,0x1eff,0x2000,0x22ff,0x2500,0x257f,0x25cf,0x25cf,0x2c7c,0x2c7c,0};
    static const nk_rune transport_ranges[]={0x20,0x17f,0x192,0x192,0x300,0x4ff,0x1d40,0x1d40,0x1d63,0x1d63,0x1d65,0x1d65,
        0x1e00,0x1eff,0x2000,0x22ff,0x2500,0x257f,0x25a0,0x25a0,0x25b6,0x25b8,0x25cb,0x25cb,0x25cf,0x25cf,0x2c7c,0x2c7c,0};
    struct nk_font_config config = nk_font_config(size);
    config.range = demand?demand:transport_symbols?transport_ranges:code?code_ranges:ui_ranges;
    config.oversample_h = horizontal;
    config.oversample_v = vertical;
    char path[4096];
#ifdef _WIN32
    const char *platform_family=code?"Consolas":"Segoe UI";
    const char *windows = SDL_getenv("WINDIR");
    snprintf(path, sizeof path, "%s/Fonts/%s", windows ? windows : "C:/Windows",
             code    ? (title?"consolab.ttf":"consola.ttf")
             : title ? "seguisb.ttf"
                     : "segoeui.ttf");
#elif defined(__APPLE__)
    const char *platform_family=code?"Menlo":"Helvetica";
    snprintf(path, sizeof path, "/System/Library/Fonts/%s", code ? "Menlo.ttc" : "Helvetica.ttc");
#else
    const char *platform_family=code?"DejaVu Sans Mono":"DejaVu Sans";
    snprintf(path, sizeof path, "/usr/share/fonts/truetype/dejavu/%s",
             code    ? (title?"DejaVuSansMono-Bold.ttf":"DejaVuSansMono.ttf")
             : title ? "DejaVuSans-Bold.ttf"
                     : "DejaVuSans.ttf");
#endif
    const char *bundled=SDL_getenv("PHYSIM_TEST_BUNDLED_FONTS");
    bool force_bundled=bundled && !strcmp(bundled,"1");
    struct nk_font *font = NULL;
    if(!force_bundled && exists(path)) {
#ifdef __APPLE__
        font=ps_ui_font_add_file_face(atlas,path,size,&config,title);
        if(font)printf("Platform font face: %s index=%d bold=%d\n",path,font->config->ttf_index,title);
#else
        font=nk_font_atlas_add_from_file(atlas,path,size,&config);
#endif
    }
    if(!font) {
        int n=snprintf(path,sizeof path,"%s/third_party/fonts/%s",root,
                       code?(title?"NotoSansMono-SemiBold.ttf":"NotoSansMono.ttf"):title?"NotoSans-Bold.ttf":"NotoSans.ttf");
        if(n>=0 && (size_t)n<sizeof path)font=nk_font_atlas_add_from_file(atlas,path,size,&config);
        if(force_bundled && font)printf("Bundled primary font: %s\n",path);
        if(font && family)snprintf(family,96,"%s",code?"Noto Sans Mono":"Noto Sans");
    } else if(family)snprintf(family,96,"%s",platform_family);
    if(!font)return NULL;
    if(transport_symbols && size==16)printf("UI primary font: %s\n",path);
    if(transport_symbols) {
        /* The transport keeps the original CSS symbols. Their bounded fallback
         * belongs to the main UI bank, not the separately inventoried F1 roles. */
        static const nk_rune symbols[]={0x2161,0x2161,0x21ba,0x21ba,0x2502,0x2502,
            0x25a0,0x25a0,0x25b6,0x25b8,0x25cb,0x25cb,0x25cf,0x25cf,0};
#ifdef _WIN32
        int symbol_n=snprintf(path,sizeof path,"%s/Fonts/seguisym.ttf",windows?windows:"C:/Windows");
        if(!force_bundled && symbol_n>=0 && (size_t)symbol_n<sizeof path && exists(path)) {
            if(!ps_ui_font_add_fallback(atlas,font,path,symbols))return NULL;
            if(size==16)printf("UI symbol fallback: %s\n",path);
        }
#endif
        int symbol_noto=snprintf(path,sizeof path,"%s/third_party/fonts/NotoSansSymbols-Regular.ttf",root);
        if(symbol_noto<0 || (size_t)symbol_noto>=sizeof path || !ps_ui_font_add_fallback(atlas,font,path,symbols))return NULL;
        if(size==16)printf("UI symbol fallback: %s\n",path);
    }
    if(code && title)printf("Workspace marker font: %s\n",path);
    /* Offline fallback covers our text ranges, phonetic modifiers, diagrams and
     * emoji. Add only glyphs absent from earlier sources, keeping the atlas small. */
    static const nk_rune fallback_ranges[]={0x20,0x17f,0x192,0x192,0x300,0x4ff,0x1d40,0x1d40,0x1d63,0x1d63,0x1d65,0x1d65,
        0x1e00,0x1eff,0x2000,0x22ff,0x2500,0x257f,0x25cf,0x25cf,0x2603,0x2603,0x2c7c,0x2c7c,0x1f30d,0x1f30d,0x1f600,0x1f600,0};
    static const nk_rune transport_fallback_ranges[]={0x20,0x17f,0x192,0x192,0x300,0x4ff,0x1d40,0x1d40,0x1d63,0x1d63,0x1d65,0x1d65,
        0x1e00,0x1eff,0x2000,0x22ff,0x2500,0x257f,0x25a0,0x25a0,0x25b6,0x25b8,0x25cb,0x25cb,0x25cf,0x25cf,0x2603,0x2603,0x2c7c,0x2c7c,0x1f30d,0x1f30d,0x1f600,0x1f600,0};
    static const char *const files[]={"NotoSans-Bold.ttf","NotoSans.ttf","NotoSansMono.ttf","NotoSansMath-Regular.ttf","NotoSansSymbols2-Regular.ttf","NotoEmoji.ttf"};
    for(size_t i=0;i<sizeof files/sizeof files[0];i++) {
        if(i==0 && !title)continue;
        int n=snprintf(path,sizeof path,"%s/third_party/fonts/%s",root,files[i]);
        if(n<0 || (size_t)n>=sizeof path || !ps_ui_font_add_fallback(atlas,font,path,demand?demand:transport_symbols?transport_fallback_ranges:fallback_ranges)) {
            SDL_SetError("Offline fallback font unavailable: %s",files[i]);return NULL;
        }
    }
    return font;
}
static struct nk_font *system_font_sampling(struct nk_font_atlas *atlas,const char *root,float size,bool code,bool title,
    unsigned char horizontal,unsigned char vertical) {
    return system_font_sampling_demand(atlas,root,size,code,title,horizontal,vertical,NULL,NULL,false);
}
static struct nk_font *graphic_font_load(void *user,struct nk_font_atlas *atlas,float height,bool strong,
    const unsigned *ranges,char family[96]) {
    return system_font_sampling_demand(atlas,user,height,false,strong,2,1,ranges,family,false);
}
static struct nk_font *system_font(struct nk_font_atlas *atlas,const char *root,float size,bool code,bool title) {
    return system_font_sampling(atlas,root,size,code,title,3,2);
}
#include "graphic_raster_tests.inc"
#include "documentation_window.inc"
static void test_window_key_mod(SDL_Window *window, SDL_Keycode key, SDL_Keymod mod) {
    SDL_Event e; SDL_zero(e);
    e.type = SDL_EVENT_KEY_DOWN;
    e.key.windowID = SDL_GetWindowID(window);
    e.key.key = key;
    e.key.mod = mod;
    e.key.down = true;
    SDL_PushEvent(&e);
    e.type = SDL_EVENT_KEY_UP;
    e.key.down = false;
    SDL_PushEvent(&e);
}
static void test_window_key(SDL_Window *window, SDL_Keycode key) {
    test_window_key_mod(window, key, PS_UI_COMMAND_MOD);
}
static void create_managed_project(app *a) {
    a->manager_error[0]=0;
    if (!idle(a) || a->library_thread || a->recovery) {
        status(a, "Zuerst den laufenden Job beenden.");
        snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;
        return;
    }
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        save_project(a);
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty) {
        snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;
        return;
    }
    if (!a->manager_name[0] || !strcmp(a->manager_name, ".") ||
        !strcmp(a->manager_name, "..") || strpbrk(a->manager_name, "/\\")) {
        status(a, "Einen gültigen Projektordnernamen eingeben.");
        snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;
        return;
    }
    SDL_PathInfo parent;
    if (!SDL_GetPathInfo(a->manager_parent, &parent) ||
        parent.type != SDL_PATHTYPE_DIRECTORY) {
        status(a, "Der Zielordner für das Projekt existiert nicht.");
        snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;
        return;
    }
    int n = snprintf(a->project_input, sizeof a->project_input, "%s/%s", a->manager_parent,
                     a->manager_name);
    if (n < 0 || n >= (int)sizeof a->project_input) {
        status(a, "Projektpfad ist zu lang.");
        snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;
        return;
    }
    static const int language_templates[8] = {8, 9, 18, 12, 16, 10, 19, 17};
    a->example = a->manager_experiment_language
                     ? language_templates[a->manager_template] : a->manager_template;
    new_project(a);
    if(a->project_manager){snprintf(a->manager_error,sizeof a->manager_error,"%s",a->status);a->manager_error_reveal=true;}
}
static bool open_workspace_path(app *a, const char *path) {
    SDL_PathInfo info;
    if (!path || !SDL_GetPathInfo(path, &info) || info.type != SDL_PATHTYPE_DIRECTORY) {
        status(a, "Ordner konnte nicht geöffnet werden.");
        return false;
    }
    if (!idle(a) || a->library_thread || a->recovery) {
        status(a, "Zuerst den laufenden Job beenden.");
        return false;
    }
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        save_project(a);
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        return false;
    if (strlen(path) >= sizeof a->workspace) {
        status(a, "Ordnerpfad ist zu lang.");
        return false;
    }
    if (!documents_save_all(a)) return false;
    char manifest[4096];
    join(manifest, sizeof manifest, path, "physim.project");
    if (exists(manifest)) {
        char previous[4096];snprintf(previous,sizeof previous,"%s",a->project_input);
        snprintf(a->project_input,sizeof a->project_input,"%s",path);
        if (!open_project(a)) {
            snprintf(a->project_input,sizeof a->project_input,"%s",previous);
            return false;
        }
        a->tab=0;
        return true;
    }
    documents_clear(a);
    clear_project(a);
    snprintf(a->workspace, sizeof a->workspace, "%s", path);
    snprintf(a->project_input, sizeof a->project_input, "%s", path);
    a->workspace_open = true;
    a->workspace_disclosure = NK_MAXIMIZED;
    a->project_manager = false;
    a->tab = 0;
    a->workspace_preview_path[0] = 0;
    a->workspace_addition_count = 0;
    refresh_workspace_entries(a);
    status(a, "Ordner geöffnet. Kein Physim-Projekt erkannt; Dateien können angesehen werden.");
    return true;
}

#include "workspace_actions.inc"
#include "workspace_catalog_actions.inc"

static Uint32 workspace_dialog_event;
static const int dialog_open_folder = PS_DIALOG_OPEN_FOLDER;
static const int dialog_add_file = PS_DIALOG_ADD_FILE;
static const int dialog_add_folder = PS_DIALOG_ADD_FOLDER;
static const int dialog_manager_parent = PS_DIALOG_MANAGER_PARENT;
static const int dialog_import_run=PS_DIALOG_IMPORT_RUN;
static const int dialog_resume_batch=PS_DIALOG_RESUME_BATCH;
static void SDLCALL workspace_dialog_callback(void *userdata, const char *const *filelist,
                                               int filter) {
    (void)filter;
    SDL_Event event = {0};
    event.type = workspace_dialog_event;
    event.user.code = *(const int *)userdata;
    /* Zenity in SDL 3.2.30 can report cancellation as an empty first string. */
    event.user.data1 = filelist && filelist[0] && filelist[0][0] ? SDL_strdup(filelist[0]) : NULL;
    event.user.data2 = filelist ? NULL : (void *)1;
    if (!SDL_PushEvent(&event))
        SDL_free(event.user.data1);
}
static void choose_workspace_path(app *a, int mode) {
    if (a->dialog_pending || workspace_dialog_event == (Uint32)-1)
        return;
    a->dialog_pending = true;
    if(mode==PS_DIALOG_RESUME_BATCH && *a->batch_resume_test_path) {
        const char *files[]={a->batch_resume_test_path,NULL};workspace_dialog_callback((void *)&dialog_resume_batch,files,0);
    }
    else if(mode==PS_DIALOG_IMPORT_RUN && *a->import_test_path) {
        const char *files[]={a->import_test_path,NULL};workspace_dialog_callback((void *)&dialog_import_run,files,0);
    }
    else if(mode==PS_DIALOG_IMPORT_RUN) {
        static const SDL_DialogFileFilter filters[]={{"Physim-Messlauf","psrun"}};
        SDL_ShowOpenFileDialog(workspace_dialog_callback,(void *)&dialog_import_run,a->window,filters,1,NULL,false);
    }
    else if (mode == PS_DIALOG_ADD_FILE)
        SDL_ShowOpenFileDialog(workspace_dialog_callback, (void *)&dialog_add_file, a->window,
                               NULL, 0, a->workspace_open ? a->workspace : NULL, false);
    else {
        const int *dialog_mode = mode == PS_DIALOG_OPEN_FOLDER ? &dialog_open_folder
                                 : mode == PS_DIALOG_RESUME_BATCH ? &dialog_resume_batch
                                 : mode == PS_DIALOG_MANAGER_PARENT ? &dialog_manager_parent
                                                                    : &dialog_add_folder;
        const char *location = mode == PS_DIALOG_MANAGER_PARENT ? a->manager_parent
                               : a->workspace_open ? a->workspace : NULL;
        SDL_ShowOpenFolderDialog(workspace_dialog_callback, (void *)dialog_mode, a->window,
                                 location, false);
    }
}
static void add_workspace_path(app *a, const char *path) {
    SDL_PathInfo info;
    if (!a->workspace_open || !SDL_GetPathInfo(path, &info)) {
        status(a, "Zuerst einen Ordner öffnen; Auswahl konnte nicht gelesen werden.");
        return;
    }
    if (strlen(path) >= sizeof a->workspace_additions[0]) {
        status(a, "Ausgewählter Pfad ist zu lang.");
        return;
    }
    for (unsigned i = 0; i < a->workspace_addition_count; i++)
        if (!strcmp(path, a->workspace_additions[i]))
            return;
    if (a->workspace_addition_count == 32) {
        status(a, "Maximal 32 zusätzliche Dateien und Ordner sind möglich.");
        return;
    }
    snprintf(a->workspace_additions[a->workspace_addition_count++],
             sizeof a->workspace_additions[0], "%s", path);
    refresh_workspace_entries(a);
    status(a, "Datei oder Ordner zum Workspace hinzugefügt.");
}
static void test_key(app *a, SDL_Keycode key) {
    test_window_key(a->window, key);
}
#define PS_TEST_MOUSE_ID ((SDL_MouseID)0x50535445u)
/* Scripted desktop workflows are isolated from native pointer and focus events.
 * Window resizing, minimizing and closing still come from the real desktop. */
static bool test_scripted_external_input(const SDL_Event *e) {
    switch (e->type) {
    case SDL_EVENT_MOUSE_MOTION: return e->motion.which != PS_TEST_MOUSE_ID;
    case SDL_EVENT_MOUSE_BUTTON_DOWN:
    case SDL_EVENT_MOUSE_BUTTON_UP: return e->button.which != PS_TEST_MOUSE_ID;
    case SDL_EVENT_MOUSE_WHEEL: return e->wheel.which != PS_TEST_MOUSE_ID;
    case SDL_EVENT_WINDOW_FOCUS_LOST: return e->window.data1 != (int)PS_TEST_MOUSE_ID;
    default: return false;
    }
}
static void test_window_mouse_count(SDL_Window *window,struct nk_rect rect,bool down,Uint8 clicks) {
    float x = rect.x + rect.w * .5f, y = rect.y + rect.h * .5f;
    SDL_Event e = {0};
    e.type = SDL_EVENT_MOUSE_MOTION;
    e.motion.windowID = SDL_GetWindowID(window);
    e.motion.which = PS_TEST_MOUSE_ID;
    e.motion.x = x;
    e.motion.y = y;
    SDL_PushEvent(&e);
    SDL_zero(e);
    e.type = down ? SDL_EVENT_MOUSE_BUTTON_DOWN : SDL_EVENT_MOUSE_BUTTON_UP;
    e.button.windowID = SDL_GetWindowID(window);
    e.button.which = PS_TEST_MOUSE_ID;
    e.button.x = x;
    e.button.y = y;
    e.button.button = SDL_BUTTON_LEFT;
    e.button.down = down;
    e.button.clicks = clicks;
    SDL_PushEvent(&e);
}
static void test_window_mouse(SDL_Window *window,struct nk_rect rect,bool down) {
    test_window_mouse_count(window,rect,down,1);
}
static void test_mouse(app *a,struct nk_rect rect,bool down) {
    test_window_mouse(a->window,rect,down);
}
// clang-format off
#include "autosave_tests.inc"
#include "batch_tests.inc"
#include "plot_tests.inc"
#include "camera_plane_tests.inc"
#include "scene_visibility_tests.inc"
#include "ui_size_tests.inc"
#include "settings_tests.inc"
#include "workspace_tree_tests.inc"
#include "document_tests.inc"
#include "document_recovery_tests.inc"
#include "toolbar_tests.inc"
#include "keyboard_menu_tests.inc"
#include "documentation_keyboard_tests.inc"
#include "project_manager_keyboard_tests.inc"
#include "project_settings_tests.inc"
#include "project_migration_tests.inc"
#include "reset_tests.inc"
#include "isolation_tests.inc"
#include "speed_tests.inc"
#include "timeline_tests.inc"
#include "docking_tests.inc"
#include "hierarchy_tests.inc"
#include "step_breakpoint_tests.inc"
#include "inspector_tests.inc"
#include "layout_tests.inc"
#include "workspace_catalog_tests.inc"
#include "pchip_tests.inc"
#include "channel_units_tests.inc"
#include "analysis_project_tests.inc"
#include "analysis_workspace_tests.inc"
#include "analysis_units_tests.inc"
#include "analysis_comparison_tests.inc"
#include "shell_theme_tests.inc"
#include "library_selection_tests.inc"
#include "report_details_tests.inc"
#include "run_details_tests.inc"
#include "batch_resume_tests.inc"
#include "batch_missing_tests.inc"
#include "series_mask_tests.inc"
#include "logging_tests.inc"
#include "frame_tests.inc"
#include "contact_world_tests.inc"
#include "material_tutorial_tests.inc"
#include "spring_tutorial_tests.inc"
#include "pendulum_tutorial_tests.inc"
#include "pendulum_medium_tests.inc"
#include "collision_tutorial_tests.inc"
#include "diagnostic_tests.inc"
#include "editor_replace_tests.inc"
#include "completion_tests.inc"
#include "source_outline_tests.inc"
#include "file_tabs_tests.inc"
#include "workbench_tests.inc"
#include "file_tabs_design_tests.inc"
#include "laboratory_tests.inc"
#include "transport_design_tests.inc"
#include "timeline_design_tests.inc"
#include "inspector_design_tests.inc"
#include "object_design_tests.inc"
#include "tree_design_tests.inc"
#include "camera_design_tests.inc"
#include "scene_frame_tests.inc"
#include "measurement_design_tests.inc"
#include "curve_design_tests.inc"
#include "run_fields_tests.inc"
#include "inspector_tail_tests.inc"
#include "inspector_channel_tests.inc"
#include "panel_window_tests.inc"
#include "model_edit_tests.inc"
#include "api_reference_tests.inc"
#include "api_card_tests.inc"
#include "parameter_form_tests.inc"
#include "adaptive_tests.inc"
#include "series_tests.inc"
#include "monte_carlo_tutorial_tests.inc"
#include "saved_run_tutorial_tests.inc"
#include "native_dialog_tests.inc"
#include "component_details_tests.inc"
#include "analysis_editor_tests.inc"
#include "workspace_tests.inc"
// clang-format on
/* Independent archive check for the optional tutorial energy-ledger report. */
static bool test_project_run_identity(const app *a) {
    if(!ps_run_identity_valid(a->project_id) || !ps_run_identity_valid(a->experiment_id))return false;
    ps_run_reader reader;if(ps_run_open(&reader,a->last_run)!=PS_OK)return false;
    char project[64],experiment[64];snprintf(project,sizeof project,"\nproject_id=%s\n",a->project_id);
    snprintf(experiment,sizeof experiment,"\nexperiment_id=%s\n",a->experiment_id);
    bool ok=strstr(reader.metadata,project)!=NULL && strstr(reader.metadata,experiment)!=NULL;
    ps_run_reader_close(&reader);return ok;
}
static bool test_pendulum_balance_report(const app *a) {
    const ps_curve_data *curve=NULL;ps_plot_info plot;ps_table_info table;ps_table_row row;
    const int8_t joules[]={2,1,-2,0,0,0,0};
    if(ps_report_plot_read(a->analysis_report,2,&plot)!=PS_OK ||
       strcmp(plot.title,"Energy balance error") || plot.curves!=1 ||
       memcmp(plot.y_unit.dimension,joules,7) || strcmp(plot.y_unit.symbol,"J") ||
       ps_report_curve_view(a->analysis_report,2,0,&curve)!=PS_OK ||
       curve->kind!=PS_PLOT_LINE || !curve->count || curve->source_count!=a->data.total ||
       ps_report_table_read(a->analysis_report,3,&table)!=PS_OK ||
       strcmp(table.title,"Energy balance") || table.columns!=2 || table.rows!=1 ||
       memcmp(table.column[0].unit.dimension,joules,7) ||
       memcmp(table.column[1].unit.dimension,joules,7) ||
       ps_report_row_read(a->analysis_report,3,0,&row)!=PS_OK)return false;
    ps_run_reader reader;
    if(ps_run_open(&reader,a->last_run)!=PS_OK)return false;
    bool ok=reader.channels==11 && !strcmp(reader.schema[9].name,"energy.dissipated") &&
            !strcmp(reader.schema[10].name,"energy.balance") &&
            !memcmp(reader.schema[9].dimension,joules,7) && !memcmp(reader.schema[10].dimension,joules,7);
    double time,values[PS_MAX_CHANNELS],initial=0,last_loss=0,max_error=0;
    uint64_t count=0;uint32_t point=0;ps_result status=PS_INVALID;
    while(ok && (status=ps_run_next(&reader,&time,values))==PS_OK) {
        if(!count)initial=values[10];
        double error=values[10]-initial;
        ok=values[9]>=0 && values[10]==values[4]+values[9];
        max_error=fmax(max_error,fabs(error));last_loss=values[9];count++;
        if(point<curve->count && curve->x[point]==time) {
            ok=ok && curve->y[point]==error;point++;
        }
    }
    ok=ok && status==PS_EOF && count==a->data.total && point==curve->count &&
       row.values[0]==last_loss && row.values[1]==max_error;
    ps_run_reader_close(&reader);return ok;
}
static bool test_general_balance_report(const app *a) {
    const ps_curve_data *curve=NULL;ps_plot_info plot;ps_table_info table;ps_table_row row;
    const int8_t joules[]={2,1,-2,0,0,0,0};
    if(ps_report_plot_read(a->analysis_report,4,&plot)!=PS_OK ||
       strcmp(plot.title,"Numerischer Energiebilanzfehler") || plot.curves!=1 ||
       memcmp(plot.y_unit.dimension,joules,7) ||
       ps_report_curve_view(a->analysis_report,4,0,&curve)!=PS_OK ||
       curve->kind!=PS_PLOT_LINE || !curve->count || curve->source_count!=a->data.total ||
       ps_report_table_read(a->analysis_report,1,&table)!=PS_OK ||
       strcmp(table.column[0].label,"Max. Bilanzabweichung") || table.rows!=1 ||
       memcmp(table.column[0].unit.dimension,joules,7) ||
       ps_report_row_read(a->analysis_report,1,0,&row)!=PS_OK)return false;
    ps_run_reader reader;if(ps_run_open(&reader,a->last_run)!=PS_OK)return false;
    int energy=-1,loss=-1,balance=-1;
    for(uint32_t i=0;i<reader.channels;i++) {
        if(!strcmp(reader.schema[i].name,"energy"))energy=(int)i;
        if(!strcmp(reader.schema[i].name,"energy.dissipated"))loss=(int)i;
        if(!strcmp(reader.schema[i].name,"energy.balance"))balance=(int)i;
    }
    bool ok=energy>=0 && loss>=0 && balance>=0;
    if(ok)ok=!memcmp(reader.schema[balance].dimension,joules,7) && !memcmp(reader.schema[loss].dimension,joules,7);
    double time,values[PS_MAX_CHANNELS],initial=0,max_error=0;uint64_t count=0;
    uint32_t point=0;ps_result status=PS_INVALID;
    while(ok && (status=ps_run_next(&reader,&time,values))==PS_OK) {
        if(!count)initial=values[balance];
        double error=values[balance]-initial;count++;
        ok=values[loss]>=0 && values[balance]==values[energy]+values[loss];
        max_error=fmax(max_error,fabs(error));
        if(point<curve->count && curve->x[point]==time){ok=ok && curve->y[point]==error;point++;}
    }
    ok=ok && status==PS_EOF && count==a->data.total && point==curve->count && row.values[0]==max_error;
    ps_run_reader_close(&reader);return ok;
}
int main(int argc, char **argv) {
    double profile_app_started = ps_clock();
    bool graphic_raster_test=argc>1 && !strcmp(argv[1],"--graphic-raster-test");
    if(graphic_raster_test && argc!=4)return 2;
    bool workspace_test = argc > 1 && !strcmp(argv[1], "--workspace-test");
    bool workspace_state_test = argc > 1 && !strcmp(argv[1], "--workspace-state-test");
    if (workspace_state_test && argc != 4)
        return 1;
    bool toolbar_test = workspace_state_test &&
                        (!strcmp(argv[3], "toolbar") || !strcmp(argv[3], "toolbar-noise"));
    if (workspace_test && argc != 3)
        return 2;
    bool syntax_preview_test = argc > 1 && !strcmp(argv[1], "--syntax-preview-test");
    if (syntax_preview_test && argc != 4)
        return 2;
    bool identity_test=argc>1 && !strcmp(argv[1],"--project-identity-test");
    bool migration_test=identity_test || (argc>1 && !strcmp(argv[1],"--project-migration-test"));
    if(migration_test && (argc!=4 || (strcmp(argv[3],"normal") && strcmp(argv[3],"stale") && strcmp(argv[3],"dirty"))))return 2;
    bool settings_test = argc > 1 && !strcmp(argv[1], "--settings-test");
    if (settings_test && (argc != 4 || (strcmp(argv[3], "write") && strcmp(argv[3], "read") &&
        strcmp(argv[3], "keyboard") && strcmp(argv[3], "keyboard-read") &&
        strcmp(argv[3], "checkbox-native") && strcmp(argv[3], "checkbox-remote") &&
        strcmp(argv[3], "options-native") && strcmp(argv[3], "options-remote") &&
        strcmp(argv[3], "focus-native") && strcmp(argv[3], "focus-remote") &&
        strcmp(argv[3], "reset") && strcmp(argv[3], "defaults") && strcmp(argv[3], "corrupt") &&
        strcmp(argv[3], "maxwrite") && strcmp(argv[3], "maxread") &&
        strcmp(argv[3], "theme-light") && strcmp(argv[3], "theme-light-read") &&
        strcmp(argv[3], "theme-contrast") && strcmp(argv[3], "theme-contrast-read") &&
        strcmp(argv[3], "theme-cancel") && strcmp(argv[3], "theme-defaults") &&
        strcmp(argv[3], "theme-dark-read") && strncmp(argv[3],"ui-size-",8))))
        return 2;
    bool camera_plane_test=argc>1 && !strcmp(argv[1],"--camera-plane-test");
    bool scene_visibility_test=argc>1 && !strcmp(argv[1],"--scene-visibility-test");
    if((camera_plane_test || scene_visibility_test) && (argc!=4 || (strcmp(argv[3],"16") && strcmp(argv[3],"22"))))return 2;
    bool plot_noise = argc > 1 && !strcmp(argv[1], "--plot-test-noise");
    bool plot_test = scene_visibility_test || camera_plane_test || plot_noise || (argc > 1 && !strcmp(argv[1], "--plot-test"));
    if (plot_test && !camera_plane_test && !scene_visibility_test && argc != 3)
        return 2;
    bool batch_test = argc > 1 && !strcmp(argv[1], "--batch-test");
    if (batch_test && argc != 3 && argc != 4)
        return 2;
    int test_batch_workers = 2;
    if (batch_test && argc == 4) {
        if (strlen(argv[3]) != 1 || argv[3][0] < '2' || argv[3][0] > '8')
            return 2;
        test_batch_workers = argv[3][0] - '0';
    }
    bool autosave_crash = argc > 1 && !strcmp(argv[1], "--autosave-crash");
    bool recovery_test = argc > 1 && !strcmp(argv[1], "--autosave-recover");
    if ((autosave_crash && argc != 3) || (recovery_test && argc != 4)) {
        fprintf(stderr, "Usage: physim --autosave-crash new-project | "
                        "--autosave-recover project restore|discard|conflict|cancel|corrupt\n");
        return 2;
    }
    const char *recovery_mode = recovery_test ? argv[3] : "";
    if (recovery_test && strcmp(recovery_mode, "restore") && strcmp(recovery_mode, "discard") &&
        strcmp(recovery_mode, "conflict") && strcmp(recovery_mode, "cancel") &&
        strcmp(recovery_mode, "corrupt"))
        return 2;
    bool docs_noise = argc > 1 && !strcmp(argv[1], "--docs-test-noise");
    bool docs_test = docs_noise || (argc > 1 && !strcmp(argv[1], "--docs-test"));
    if (docs_test && argc != 3) {
        fprintf(stderr, "Usage: physim --docs-test output-directory\n");
        return 2;
    }
    int test_example = 0;
    bool test_language_analysis = false;
    if (argc > 1 && !strcmp(argv[1], "--self-test")) {
        if (argc < 3 || argc > 4) {
            fprintf(stderr,
                    "Usage: physim --self-test new-project "
                    "[pendulum|projectile|collision|box_floor|spring|uncertain_projectile|box_collision|buoyancy|"
                    "language_pendulum|language_projectile|language_sensors|language_body|language_contact|language_joint|language_graph|language_sweep|language_spring|language_buoyancy|language_collision|language_box_collision|language_full|language_mixed]\n");
            return 2;
        }
        if (argc == 4) {
            if (!strcmp(argv[3], "projectile"))
                test_example = 1;
            else if (!strcmp(argv[3], "collision"))
                test_example = 2;
            else if (!strcmp(argv[3], "box_floor"))
                test_example = 3;
            else if (!strcmp(argv[3], "spring"))
                test_example = 4;
            else if (!strcmp(argv[3], "uncertain_projectile"))
                test_example = 5;
            else if (!strcmp(argv[3], "box_collision"))
                test_example = 6;
            else if (!strcmp(argv[3], "buoyancy"))
                test_example = 7;
            else if (!strcmp(argv[3], "language_pendulum"))
                test_example = 8;
            else if (!strcmp(argv[3], "language_projectile")) {
                test_example = 9;
                test_language_analysis = true;
            }
            else if (!strcmp(argv[3], "language_sensors")) {
                test_example = 10;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_body")) {
                test_example = 11;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_contact")) {
                test_example = 12;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_full")) {
                test_example = 8;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_joint")) {
                test_example = 13;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_mixed")) {
                test_example = 0;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_graph")) {
                test_example = 14;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_sweep")) {
                test_example = 15;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_spring")) {
                test_example = 16;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_buoyancy")) {
                test_example = 17;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_collision")) {
                test_example = 18;
                test_language_analysis = true;
            } else if (!strcmp(argv[3], "language_box_collision")) {
                test_example = 19;
                test_language_analysis = true;
            } else if (strcmp(argv[3], "pendulum")) {
                fprintf(stderr, "Unknown test example\n");
                return 2;
            }
        }
    }
    bool trace_test = SDL_getenv("PHYSIM_TEST_TRACE") != NULL;
    if (trace_test)
        fprintf(stderr, "APP TEST TRACE: initializing SDL\n");
    SDL_SetMainReady();
    if (!SDL_Init(SDL_INIT_VIDEO)) {
        fprintf(stderr, "SDL: %s\n", SDL_GetError());
        return 1;
    }
    if (trace_test) {
        const char *driver = SDL_GetCurrentVideoDriver();
        fprintf(stderr, "APP TEST TRACE: SDL initialized, video driver %s\n", driver ? driver : "unknown");
    }
    workspace_dialog_event = SDL_RegisterEvents(1);
    if (workspace_dialog_event == (Uint32)-1) {
        fprintf(stderr, "Workspace dialog event: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
#ifdef __APPLE__
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 4);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 1);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);
#else
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
#endif
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    if (trace_test)
        fprintf(stderr, "APP TEST TRACE: creating window\n");
    SDL_Window *window =
        SDL_CreateWindow("Physim | Experiment Studio", 1440, 940,
                         SDL_WINDOW_RESIZABLE | SDL_WINDOW_HIGH_PIXEL_DENSITY | SDL_WINDOW_OPENGL |
                         (graphic_raster_test?SDL_WINDOW_HIDDEN:0));
    if (trace_test)
        fprintf(stderr, "APP TEST TRACE: window %s, creating OpenGL context\n", window ? "created" : "failed");
    ps_graphics *graphics = window ? ps_graphics_create(window) : NULL;
    if (!graphics) {
        fprintf(stderr, "OpenGL initialization: %s\n", SDL_GetError());
        if (argc < 2 || strncmp(argv[1], "--", 2))
            SDL_ShowSimpleMessageBox(SDL_MESSAGEBOX_ERROR, "Physim: Grafikfehler", SDL_GetError(),
                                     window);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }
    if(graphic_raster_test) {
        bool ok=graphic_raster_self_test(graphics,window,argv[2],argv[3]);
        ps_graphics_destroy(graphics);SDL_DestroyWindow(window);SDL_Quit();return ok?0:1;
    }
    if (argc > 1 && !strcmp(argv[1], "--renderer-test")) {
        bool ok = ps_graphics_test(graphics, argc > 2 ? argv[2] : NULL) &&
                  nk_sdl_test_input(window, graphics);
        if (!ok)
            fprintf(stderr, "GPU TEST: %s\n", SDL_GetError());
        ps_graphics_destroy(graphics);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return ok ? 0 : 1;
    }
    if (trace_test)
        fprintf(stderr, "APP TEST TRACE: window and OpenGL ready\n");
    SDL_SetWindowMinimumSize(window, 1080, 740);
    app *a = calloc(1, sizeof *a);
    if (!a) {
        ps_graphics_destroy(graphics);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }
    a->window = window;
    a->primary_window = window;
    if (SDL_SetWindowHitTest(window, window_hit_test, a))
        SDL_SetWindowBordered(window, false);
    else
        fprintf(stderr, "Integrierter Fensterkopf: %s\n", SDL_GetError());
    a->preferences = PS_PREFERENCES_DEFAULT;
    a->doc_jump_block = -1;
    a->graphics = graphics;
    a->camera_target = PS_CAMERA_DEFAULT.target;
    a->png_scale = 2;
    a->ui = nk_sdl_init(window, graphics);
    if (!a->ui) {
        free(a);
        ps_graphics_destroy(graphics);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }
    char executable[4096];
    if (!ps_executable_path(executable, sizeof executable))
        snprintf(executable, sizeof executable, "%s", argv[0]);
    char *slash = strrchr(executable, '/'), *back = strrchr(executable, '\\');
    if (back && (!slash || back > slash))
        slash = back;
    if (slash)
        *slash = 0;
    snprintf(a->bin, sizeof a->bin, "%s", executable);
    snprintf(a->root, sizeof a->root, "%s/..", a->bin);
    char check[4096];
    join(check, sizeof check, a->root, "include/physim/core.h");
#ifdef __APPLE__
    if (!exists(check)) {
        snprintf(a->root, sizeof a->root, "%s/../Resources", a->bin);
        join(check, sizeof check, a->root, "include/physim/core.h");
    }
#endif
    if (!exists(check))
        snprintf(a->root, sizeof a->root, "%s", PS_SOURCE_DIR);
    struct nk_font_atlas *atlas = nk_sdl_font_stash_begin(a->ui);
    if(trace_test)fprintf(stderr,"APP TEST TRACE: main fonts begin %.6f\n",ps_clock());
    struct nk_font *ui_fonts[4], *title_fonts[4];
    bool ui_fonts_ok=true;
    for(int i=0;i<4;i++) {
        ui_fonts[i]=system_font_sampling_demand(atlas,a->root,(float)(16+i*2),false,false,3,2,NULL,NULL,true);
        title_fonts[i]=system_font(atlas,a->root,(float)(23+i*2),false,true);
        ui_fonts_ok &= ui_fonts[i]!=NULL && title_fonts[i]!=NULL;
    }
    struct nk_font *font=ui_fonts[0];
    struct nk_font *code_fonts[6];
    bool code_fonts_ok = true;
    for (int i = 0; i < 6; i++) {
        code_fonts[i] = system_font(atlas,a->root,(float)(12 + i * 2),true,false);
        code_fonts_ok &= code_fonts[i] != NULL;
    }
    struct nk_font *title_font = title_fonts[0];
    static const nk_rune marker_ranges[]={0x20,0x7e,0};
    struct nk_font *marker_font=system_font_sampling_demand(atlas,a->root,16,true,true,3,2,marker_ranges,NULL,false);
    ui_fonts_ok &= marker_font!=NULL;
    a->workbench_marker_em=ps_ui_font_em_ratio(marker_font);
    a->workbench_regular_em=ps_ui_font_em_ratio(font);
    a->workbench_bold_em=ps_ui_font_em_ratio(title_font);
    a->workbench_code_em=ps_ui_font_em_ratio(code_fonts[0]);
    if(trace_test)fprintf(stderr,"APP TEST TRACE: main font sources ready %.6f\n",ps_clock());
    if (!ui_fonts_ok || !code_fonts_ok || !title_font || !nk_sdl_font_stash_end(a->ui)) {
        fprintf(stderr, "Font initialization: %s\n", SDL_GetError());
        nk_sdl_shutdown(a->ui);
        free(a);
        ps_graphics_destroy(graphics);
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }
    style(a->ui);
    if(trace_test)fprintf(stderr,"APP TEST TRACE: main fonts ready %.6f\n",ps_clock());
    a->font_ui = &font->handle;
    for(int i=0;i<4;i++){a->ui_fonts[i]=&ui_fonts[i]->handle;a->title_fonts[i]=&title_fonts[i]->handle;}
    for (int i = 0; i < 6; i++)
        a->code_fonts[i] = &code_fonts[i]->handle;
    a->font_code = a->code_fonts[0];
    a->font_title = &title_font->handle;
    a->workbench_marker_source=&marker_font->handle;
    nk_style_set_font(a->ui, &font->handle);
    nk_textedit_init_default(&a->experiment);
    nk_textedit_init_default(&a->analysis);
    char projects[4096];
#ifdef __APPLE__
    const char *documents = SDL_GetUserFolder(SDL_FOLDER_DOCUMENTS);
    char *fallback = documents ? NULL : SDL_GetPrefPath("Physim", "Physim");
    join(projects, sizeof projects, documents ? documents : fallback ? fallback : ".", "Physim");
    SDL_free(fallback);
#else
    join(projects, sizeof projects, a->root, "projects");
#endif
    ps_make_directory(projects);
    snprintf(a->manager_parent, sizeof a->manager_parent, "%s", projects);
    a->dt = 0.005;
    a->simulation_speed = 1;
    a->minimum_dt=1e-8;a->maximum_dt=.1;
    a->batch_dt = .005;
    a->batch_end_time=1;a->batch_minimum_dt=1e-8;a->batch_maximum_dt=.1;
    a->batch_timeout = 30;
    a->batch_runs = 256;
    a->batch_workers = SDL_GetNumLogicalCPUCores();
    if (a->batch_workers < 1)
        a->batch_workers = 1;
    if (a->batch_workers > 4)
        a->batch_workers = 4;
    a->batch_steps = 200;
    snprintf(a->batch_seed, sizeof a->batch_seed, "42");
    snprintf(a->batch_channel, sizeof a->batch_channel, "position.x");
    snprintf(a->seed, sizeof a->seed, "42");
    a->yaw = PS_CAMERA_DEFAULT.yaw;
    a->pitch = PS_CAMERA_DEFAULT.pitch;
    a->zoom = PS_CAMERA_DEFAULT.distance;
    a->show_vectors = true;
    a->show_grid = true;
    a->show_paths = a->show_points = a->show_labels = true;
    a->history_stride = 1;
    status(a, "Bereit. Ordner öffnen oder ein neues Projekt anlegen.");
    bool smoke = argc > 1 && !strcmp(argv[1], "--smoke");
    bool workflow_test = argc > 2 && !strcmp(argv[1], "--self-test");
    bool self_test = migration_test || settings_test || plot_test || batch_test || docs_test || recovery_test ||
                     workspace_test || workspace_state_test || syntax_preview_test ||
                     workflow_test;
    bool test_resize_failed=false;
    if (self_test && SDL_getenv("PHYSIM_TEST_SMALL")) {
        if(!SDL_SetWindowSize(window,1080,740) || !SDL_SyncWindow(window)) {
            fprintf(stderr,"Test window resize: %s\n",SDL_GetError());
            a->quitting=true;test_resize_failed=true;
        }
        SDL_PumpEvents();
    }
    if (argc < 2 || strncmp(argv[1], "--", 2)) {
        preferences_start(a, NULL);
        workspace_state_start(a, NULL);
        document_drafts_start(a, NULL);
    }
    int test_stage=0,exit_code=test_resize_failed?1:0;
    double test_started = ps_clock(), paused_time = 0;
    unsigned doc_input_events = 0, doc_input_bytes = 0;
    nk_uint test_doc_scroll = 0;
    SDL_WindowID test_doc_window_id = 0;
    ps_report *test_previous_report = NULL;
    char test_original_run[4096] = {0}, test_original_report[4096] = {0};
    uint64_t test_original_samples = 0;
    int test_library_row = -1;
    if (syntax_preview_test) {
        snprintf(a->project, sizeof a->project, "%s", argv[2]);
        if (!ps_make_directory(a->project) || !load_editor(&a->experiment, argv[3])) {
            exit_code = 1;
            a->quitting = true;
        } else {
            a->loaded = true;
            a->language_experiment = true;
            test_stage = 120;
        }
    } else if (workspace_state_test) {
        if (!workspace_test_start(a, argv[2], argv[3])) {
            exit_code = 1;
            a->quitting = true;
        }
    } else if (workspace_test) {
        if (a->workspace_open || a->loaded || a->project_input[0] ||
            !ps_make_directory(argv[2])) {
            exit_code = 1;
            a->quitting = true;
        }
        test_stage = 100;
    } else if(migration_test) {
        snprintf(a->project_input,sizeof a->project_input,"%s",argv[2]);
        if(!open_project(a)){exit_code=1;a->quitting=true;}
    } else if (settings_test) {
        snprintf(a->project, sizeof a->project, "%s", argv[2]);
        char path[4096];
        join(path, sizeof path, a->project, "preferences.bin");
        if (!strcmp(argv[3], "write") && !ps_make_directory_exclusive(a->project)) {
            exit_code = 1;
            a->quitting = true;
        }
        preferences_start(a, path);
        a->loaded = true;
        const char *sample = "/* Darstellungstest */\ndouble energy(double mass, double speed) {\n"
                             "    return 0.5 * mass * speed * speed;\n}\n";
        nk_str_append_text_char(&a->experiment.string, sample, (int)strlen(sample));
    } else if (autosave_crash) {
        snprintf(a->project_input, sizeof a->project_input, "%s", argv[2]);
        new_project(a);
        bool ok = test_autosave_crash(a);
        fprintf(stdout, "AUTOSAVE ABRUPT EXIT: %s\n", ok ? "PASSED" : "FAILED");
        fflush(stdout);
        _Exit(ok ? 0 : 1);
    } else if (recovery_test) {
        snprintf(a->project_input, sizeof a->project_input, "%s", argv[2]);
        open_project(a);
        bool corrupt = !strcmp(recovery_mode, "corrupt");
        bool conflict = !strcmp(recovery_mode, "conflict");
        if (!a->loaded || (corrupt ? !a->autosave_blocked || a->recovery
                                   : !a->recovery || a->recovery_conflict != conflict)) {
            exit_code = 1;
            a->quitting = true;
        }
        test_stage = 80;
    } else if (plot_test) {
        if((camera_plane_test || scene_visibility_test) && !strcmp(argv[3],"22")) {
            ps_preferences p=a->preferences;p.ui_size=22;preferences_apply(a,&p);
        }
        if (!test_plot_setup(a, argv[2])) {
            exit_code = 1;
            a->quitting = true;
        }
    } else if (docs_test) {
        snprintf(a->project, sizeof a->project, "%s", argv[2]);
        if (!ps_make_directory(a->project)) {
            a->quitting = true;
            exit_code = 1;
        }
        test_stage = 20;
    } else if (batch_test) {
        a->example = 5;
        a->batch_workers = test_batch_workers - 1; /* Incremented through the actual UI control. */
        snprintf(a->project_input, sizeof a->project_input, "%s", argv[2]);
        new_project(a);
        if (!a->loaded) {
            exit_code = 1;
            a->quitting = true;
        } else {
            build_project(a);
            test_stage = 90;
        }
    } else if (self_test) {
        a->example = test_example;
        a->template_analysis_language = test_language_analysis ? 1 : 0;
        if (test_example == 1 || test_example == 5 || test_example == 10) {
            a->camera_target = ps_v3(-.7, .3, 0);
            a->zoom = 4.5f;
        }
        snprintf(a->project_input, sizeof a->project_input, "%s", argv[2]);
        new_project(a);
        if (!a->loaded || nk_str_len_char(&a->experiment.string) < 100 ||
            nk_str_len_char(&a->analysis.string) < 100) {
            fprintf(stderr, "Self-test requires a new writable project directory.\n");
            a->quitting = true;
            exit_code = 1;
        } else if (!test_editor_failed_import(a) || !test_editor_safe_save(a)) {
            status(a, "SELF-TEST: Import oder sicheres Speichern fehlgeschlagen.");
            a->quitting = true;
            exit_code = 1;
        } else {
            const char *failure = a->language_experiment || a->language_analysis
                                      ? "\nlet expectedFailure: Float64 = true\n"
                                      : "\n#error PHYSIM_EXPECTED_BUILD_FAILURE\n";
            struct nk_text_edit *target = test_language_analysis ? &a->analysis : &a->experiment;
            nk_str_append_text_char(&target->string, failure, (int)strlen(failure));
            if (test_language_analysis) a->analysis_dirty = true;
            else a->dirty = true;
            build_project(a);
            test_stage = -1;
        }
    } else if (argc > 1 && !smoke) {
        open_workspace_path(a, argv[1]);
    }
    if (trace_test)
        fprintf(stderr, "APP TEST TRACE: initial stage %d, status %s\n", test_stage, a->status);
    const char *profile_directory = SDL_getenv("PHYSIM_PROFILE_DIR");
    bool profile_requested = profile_directory && *profile_directory;
    a->profile_started_at = profile_app_started;
    if (profile_requested) {
        a->profiler = ps_app_profile_start(profile_directory);
        if (!a->profiler) fprintf(stderr, "App profiling could not start; app continues.\n");
    }
    double profile_ready = 0;
    Uint64 profile_previous = a->profiler ? SDL_GetTicksNS() : 0;
    unsigned frames = 0;
    while (!a->quitting) {
        Uint64 profile_frame_started = a->profiler ? SDL_GetTicksNS() : 0;
        Uint64 profile_phase = profile_frame_started;
        if (a->profiler) {
            a->profile_frame = (ps_app_profile_frame){0};
            a->profile_frame.frame = frames;
        }
        graphic_export_tick(a);
        preferences_theme_tick(a);
        api_reference_insert_tick(a);
        documentation_actions_tick(a);
        a->workspace_tip.dismissed=false;
        nk_input_begin(a->ui);
        if (a->doc_ui)
            nk_input_begin(a->doc_ui);
        for(unsigned i=0;i<PS_PANEL_COUNT;i++)if(a->panels[i].ui)nk_input_begin(a->panels[i].ui);
        SDL_Event e;
        while (SDL_PollEvent(&e)) {
            if(e.type==SDL_EVENT_KEY_DOWN || e.type==SDL_EVENT_TEXT_INPUT || e.type==SDL_EVENT_WINDOW_FOCUS_LOST) {
                a->workspace_tip.dismissed=true;a->workspace_tip.visible=false;
            }
            if (e.type == workspace_dialog_event) {
                a->dialog_pending = false;
                const char *path = (const char *)e.user.data1;
                if (path) {
                    if (e.user.code == PS_DIALOG_OPEN_FOLDER)
                        open_workspace_path(a, path);
                    else if(e.user.code==PS_DIALOG_IMPORT_RUN)import_run(a,path);
                    else if(e.user.code==PS_DIALOG_RESUME_BATCH)resume_batch(a,path);
                    else if (e.user.code == PS_DIALOG_MANAGER_PARENT)
                        snprintf(a->manager_parent, sizeof a->manager_parent, "%s", path);
                    else
                        add_workspace_path(a, path);
                    SDL_free(e.user.data1);
                } else if (e.user.data2) {
                    status(a, "Dateiauswahl fehlgeschlagen.");
                }
                continue;
            }
            if ((workflow_test || migration_test || plot_test || toolbar_test || settings_test || docs_test ||
                 (workspace_state_test && strncmp(argv[3],"native-dialog",13) &&
                  strcmp(argv[3],"documents-unfiltered"))) && test_scripted_external_input(&e) &&
                !(workspace_state_test && !strcmp(argv[3],"timeline-design") && timeline_design.sink &&
                  e.type==SDL_EVENT_WINDOW_FOCUS_LOST && e.window.windowID==SDL_GetWindowID(a->window))) continue;
            if (self_test && e.type == SDL_EVENT_TEXT_INPUT) {
                doc_input_events++;
                doc_input_bytes += (unsigned)strlen(e.text.text);
            }
            SDL_Window *event_window = SDL_GetWindowFromEvent(&e);
            if(timeline_controls_event(a,&e,event_window))continue;
            if(graphic_export_event(a,&e,event_window))continue;
            if(panel_window_event(a,&e,event_window))continue;
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && e.key.key==SDLK_ESCAPE && a->panel_pull){panel_pull_cancel(a);continue;}
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && e.key.key==SDLK_RETURN && (e.key.mod&PS_UI_COMMAND_MOD) && (e.key.mod&SDL_KMOD_SHIFT)) {
                for(unsigned i=0;i<PS_PANEL_COUNT;i++)if(a->panels[i].action.w>0 && nk_sdl_accessibility_keyboard_target(a->ui,a->panels[i].action))a->panel_open_request|=1u<<i;
                continue;
            }
            if(event_window==a->window && e.type==SDL_EVENT_TEXT_INPUT)a->completion_typed=true;
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && e.key.key==SDLK_TAB)a->outline_keyboard=false;
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && (analysis_plot_resize_key(a,&e.key) || laboratory_resize_key(a,&e.key) || dock_resize_key(a,&e.key)))continue;
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && workbench_context_key(a,a->ui,&e.key,false))continue;
            if(event_window==a->window && e.type==SDL_EVENT_KEY_DOWN && editor_search_key(a,&e.key))continue;
            if(event_window==a->window && (e.type==SDL_EVENT_WINDOW_FOCUS_LOST || e.type==SDL_EVENT_WINDOW_RESIZED)) {
                if(a->panel_pull)panel_pull_cancel(a);
                if(a->laboratory_resize)laboratory_resize_abort(a);
                if(a->analysis_plot_resizing)analysis_plot_resize_abort(a);
                if(a->dock_resize || a->dock_float_resize)dock_resize_abort(a);
            }
            if(event_window==a->window && nk_sdl_accessibility_event(a->ui,&e))continue;
            if(event_window==a->doc_window && a->doc_ui && documentation_actions_event(a,&e))continue;
            if(event_window==a->doc_window && a->doc_ui && nk_sdl_accessibility_event(a->doc_ui,&e))continue;
            if (event_window == a->window && e.type == SDL_EVENT_WINDOW_FOCUS_LOST)
                { completion_close(a);toolbar_keyboard_close(a);a->settings_keyboard=false; }
            if(event_window==a->window && e.type==SDL_EVENT_MOUSE_BUTTON_DOWN)completion_pointer_event(a,&e.button);
            if (a->doc_window && event_window == a->doc_window) {
                if (e.type == SDL_EVENT_WINDOW_CLOSE_REQUESTED)
                    documentation_window_hide(a);
                else if (a->doc_visible) {
                    if(e.type==SDL_EVENT_MOUSE_BUTTON_DOWN) {
                        float x=e.button.x,y=e.button.y;
                        struct nk_rect f=a->doc_filter_bounds,s=a->doc_search_bounds;
                        bool filter_hit=x>=f.x && x<f.x+f.w && y>=f.y && y<f.y+f.h;
                        bool search_hit=x>=s.x && x<s.x+s.w && y>=s.y && y<s.y+s.h;
                        if((a->doc_filter_active && !filter_hit) || (a->doc_search_active && !search_hit))
                            documentation_finish_edits(a);
                        a->doc_keyboard=a->doc_focus_reveal=a->doc_filter_focus=a->doc_search_focus=false;
                    }
                    if (e.type == SDL_EVENT_KEY_DOWN && documentation_keyboard_key(a,&e.key))continue;
                    if (e.type == SDL_EVENT_KEY_DOWN && !e.key.repeat) {
                        if (e.key.key == SDLK_F && (e.key.mod & PS_UI_COMMAND_MOD)) {
                            a->doc_search_focus = true;
                            a->doc_filter_active = false;
                        }
                        if (e.key.key == SDLK_ESCAPE) {
                            documentation_window_hide(a);
                            continue;
                        }
                    }
                    nk_sdl_handle_event(a->doc_ui, &e);
                }
                continue;
            }
            if (e.type == SDL_EVENT_QUIT ||
                (e.type == SDL_EVENT_WINDOW_CLOSE_REQUESTED && event_window == a->window)) {
                if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
                    save_project(a);
                if (!a->dirty && !a->analysis_dirty && !a->project_settings_dirty && !a->project_definitions_dirty && documents_save_all(a))
                    a->quitting = true;
            }
            if(e.type==SDL_EVENT_KEY_DOWN && event_window==a->window)a->workbench_sidebar_focus=0;
            if (e.type == SDL_EVENT_KEY_DOWN && event_window == a->window && (a->layout_manager || a->workspace_manager || a->channel_unit_manager || a->run_details_manager) && e.key.key == SDLK_ESCAPE) {
                a->layout_manager = false;
                a->workspace_manager = false;
                a->channel_unit_manager = false;
                a->run_details_manager = false;
                continue;
            }
            if (e.type == SDL_EVENT_KEY_DOWN && event_window == a->window && !a->recovery && !a->layout_manager && !a->workspace_manager && !a->channel_unit_manager && !a->run_details_manager) {
                if(e.key.key==SDLK_F1 && (e.key.mod&SDL_KMOD_SHIFT) && !e.key.repeat) {
                    struct nk_text_edit *edit=completion_target(a);
                    if(edit && edit->active){api_reference_from_editor(a,edit);continue;}
                }
                if(completion_keyboard_key(a,&e.key))continue;
                if(file_tabs_keyboard(a,&e.key))continue;
                if (toolbar_keyboard_key(a, &e.key)) continue;
                if (settings_keyboard_key(a, &e.key)) continue;
                if (project_manager_keyboard_key(a, &e.key)) continue;
                if (runner_keyboard_key(a, &e.key)) continue;
                if (a->dock_drag && e.key.key==SDLK_ESCAPE) { a->dock_drag=0;a->dock_dragging=false;continue; }
                if (a->file_tab_drag && e.key.key==SDLK_ESCAPE) {
                    memcpy(a->file_tab_order,a->file_tab_drag_order,sizeof a->file_tab_order);
                    a->file_tab_drag=0;a->file_tab_dragging=false;continue;
                }
                if (scene_shortcut(a, &e.key)) continue;
                if (a->tab == 1 && e.key.key == SDLK_SPACE && !e.key.repeat &&
                    !(e.key.mod & (SDL_KMOD_CTRL | SDL_KMOD_GUI | SDL_KMOD_ALT)) &&
                    (!a->ui->active || (!a->ui->active->edit.active &&
                     !a->ui->active->property.active && !a->ui->active->popup.active))) {
                    timeline_toggle_play(a);
                    continue;
                }
                if (!e.key.repeat && (e.key.mod & PS_UI_COMMAND_MOD)) {
                    if (e.key.key >= SDLK_1 && e.key.key <= SDLK_3)
                        select_workspace_tab(a, (int)(e.key.key - SDLK_1));
                    if (e.key.key == SDLK_4)
                        open_library(a);
                    if (e.key.key == SDLK_F) {
                        if (a->tab == 4)
                            a->library_search_focus = true;
                        else
                            editor_search_open(a);
                    }
                    if (e.key.key == SDLK_L) {
                        a->show_log = !a->show_log;
                        if(a->show_log) dock_show(a,PS_DOCK_LOG);
                    }
                    if (e.key.key == SDLK_COMMA)
                        open_settings(a);
                }
                if (e.key.key == SDLK_S && (e.key.mod & PS_UI_COMMAND_MOD))
                    save_active_document(a);
                if (e.key.key == SDLK_W && (e.key.mod & PS_UI_COMMAND_MOD)) {
                    unsigned key=file_tab_active(a);if(key<FILE_TABS)file_tab_close(a,key);
                }
                if (e.key.key == SDLK_F5)
                    build_project(a);
                if (e.key.key == SDLK_F1 && !e.key.repeat)
                    open_documentation(a, a->documentation ? a->doc_topic : 1);
                if (e.key.key == SDLK_F7 && !e.key.repeat)
                    reset_run(a);
                if (e.key.key == SDLK_F6 && !e.key.repeat && !a->reset_pending && !a->reset_starting) {
                    if (!a->runner.running)
                        start_run(a);
                    else if (a->hello && !a->stop_at)
                        command(a, a->paused ? PS_MSG_RUN : PS_MSG_PAUSE);
                }
            }
            if ((a->toolbar_keyboard || (a->tab==6 && a->settings_keyboard)) && e.type == SDL_EVENT_TEXT_INPUT) continue;
            nk_sdl_handle_event(a->ui, &e);
        }
        nk_input_end(a->ui);
        if (a->doc_ui)
            nk_input_end(a->doc_ui);
        for(unsigned i=0;i<PS_PANEL_COUNT;i++)if(a->panels[i].ui)nk_input_end(a->panels[i].ui);
        if(nk_sdl_accessibility_has_focus(a->ui)){a->settings_keyboard=false;toolbar_keyboard_close(a);}
        if(a->doc_ui && nk_sdl_accessibility_has_focus(a->doc_ui) && !nk_sdl_accessibility_keyboard_owned(a->doc_ui))a->doc_keyboard=false;
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.event_seconds = (double)(now - profile_phase) / 1e9;
            profile_phase = now;
        }
        pump(a);
        analysis_comparison_sync(a);
        model_edit_tick(a);
        autosave_tick(a, ps_clock());
        documents_autosave_tick(a, ps_clock());
        const char *capture = NULL;
        int checked_stage = test_stage, previous_exit_code = exit_code;
        if (syntax_preview_test) {
            if (ps_clock() - test_started > 15) {
                exit_code = 1;
                a->quitting = true;
            } else if (test_stage == 120 && frames > 1) {
                capture = "unicode-editor.bmp";
                test_stage = 121;
            } else if (test_stage == 121) {
                printf("UNICODE EDITOR PREVIEW: %s\n", exit_code ? "FAILED" : "PASSED");
                a->quitting = true;
            }
        } else if (workspace_state_test) {
            /* The deliberate 80 ms frame delay also runs on hosted software GL.
             * Keep its bounded keyboard assertions; allow their extra wall time. */
            if (ps_clock() - test_started >
                ((!strcmp(argv[3],"transport-design") || !strcmp(argv[3],"timeline-design") || !strcmp(argv[3],"camera-design") || !strcmp(argv[3],"scene-frame-design") || !strcmp(argv[3],"measurement-design") || !strcmp(argv[3],"curve-design") || !strncmp(argv[3],"analysis-editor-",16) || !strcmp(argv[3],"inspector-channel") || !strcmp(argv[3],"run-fields-design") || !strncmp(argv[3],"inspector-tail-",15))?180:!strncmp(argv[3],"file-tabs-design",16)?60:!strncmp(argv[3],"component-",10)?60:!strncmp(argv[3],"comparison-",11)?120:!strncmp(argv[3],"api-card-",9)?120:!strncmp(argv[3],"model-values-",13)?300:!strncmp(argv[3],"fixed-panels-",13)?180:!strncmp(argv[3],"laboratory-",11)?150:!strncmp(argv[3],"workbench-",10)?60:!strncmp(argv[3],"shell-theme-",12)?60:(!strncmp(argv[3],"analysis-layout-",16) || !strncmp(argv[3],"analysis-units-",15))?60:!strncmp(argv[3],"report-details-",15)?60:!strncmp(argv[3],"library-selection-",18)?120:!strncmp(argv[3],"api-reference-",14)?60:!strncmp(argv[3],"completion-",11)?60:!strncmp(argv[3],"docs-keyboard",13)?(!strcmp(argv[3],"docs-keyboard-delayed")?120:!strcmp(argv[3],"docs-keyboard-typeset")?90:60):!strncmp(argv[3],"manager-keyboard",16)?900:(!strcmp(argv[3], "documents-build") || !strncmp(argv[3], "project-settings-", 17) || !strncmp(argv[3],"parameter-form-",15) ||
                  !strncmp(argv[3], "isolation-", 10) || !strncmp(argv[3], "breakpoints-", 12) || !strncmp(argv[3], "reset-", 6) || !strncmp(argv[3], "speed-", 6) || !strncmp(argv[3], "timeline-", 9) || !strncmp(argv[3],"adaptive-",9) || !strncmp(argv[3],"series-",7) || !strncmp(argv[3],"inspector-",10) || !strncmp(argv[3],"object-design",13) || !strcmp(argv[3],"tree-design") || !strncmp(argv[3],"layouts-",8) || !strncmp(argv[3],"named-",6) || !strncmp(argv[3],"pchip-",6) || !strncmp(argv[3],"units-",6) || !strncmp(argv[3],"analysis-project-",17) || !strncmp(argv[3],"resume-",7) || !strncmp(argv[3],"missing-",8) || !strncmp(argv[3],"mask-",5) || !strncmp(argv[3],"frames-",7) || !strncmp(argv[3],"saved-run-tutorial-",19) || !strncmp(argv[3],"monte-carlo-tutorial-",21) || !strncmp(argv[3],"collision-tutorial-",19) || (!strncmp(argv[3],"pendulum-tutorial-",18) || !strncmp(argv[3],"pendulum-medium-",16)) || !strncmp(argv[3],"spring-tutorial-",16) || !strncmp(argv[3],"material-",9) || !strncmp(argv[3],"contact-world",13) || !strncmp(argv[3],"diagnostic-",11) || !strncmp(argv[3],"logging-",8) || (!strncmp(argv[3], "dock-", 5) || !strncmp(argv[3], "hierarchy-", 10))
                     ? 120 : !strncmp(argv[3], "native-dialog", 13) ? 180 : 15))) {
                fprintf(stderr, "Workspace self-test timeout: %s after %.3f wall seconds\n",
                        argv[3], ps_clock() - test_started);
                exit_code = 1;
                a->quitting = true;
            } else
                workspace_test_frame(a, argv[3], &test_stage, &exit_code, &capture);
        } else if (workspace_test) {
            if (ps_clock() - test_started > 15) {
                exit_code = 1;
                a->quitting = true;
            } else if (test_stage == 100) {
                open_workspace_path(a, argv[2]);
                if (!a->workspace_open || a->loaded || strcmp(a->workspace, argv[2]))
                    exit_code = 1;
                test_stage = 101;
            } else if (test_stage == 101) {
                char path[4096];
                join(path, sizeof path, argv[2], "notes.txt");
                FILE *file = fopen(path, "w");
                if (!file) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    fputs("Workspace text preview\n", file);
                    fclose(file);
                    refresh_workspace_entries(a);
                    add_workspace_path(a, path);
                    preview_workspace_path(a, path);
                    if (a->tab != 8 || !(active_document(a) && strstr(active_document(a)->file.saved, "Workspace text")))
                        exit_code = 1;
                    test_stage = 102;
                }
            } else if (test_stage == 102) {
                a->project_manager = true;
                snprintf(a->manager_parent, sizeof a->manager_parent, "%s", argv[2]);
                snprintf(a->manager_name, sizeof a->manager_name, "created-%u",
                         (unsigned)(ps_clock() * 1000000));
                a->manager_experiment_language = 1;
                a->manager_template = 6;
                a->template_analysis_language = 1;
                test_stage = 103;
            } else if (test_stage == 103) {
                create_managed_project(a);
                char manifest[4096];
                join(manifest, sizeof manifest, a->project, "physim.project");
                if (!a->loaded || a->project_manager || a->tab != 0 || !a->workspace_open ||
                    !exists(manifest) ||
                    !test_source_has(a, "main.phys", "Contacts.boxes") ||
                    !test_source_has(a, "analysis.phys", "Boxpositionen") ||
                    !test_source_has(a, "physim.project", "experiment=main.phys"))
                    exit_code = 1;
                test_stage = 104;
            } else if (test_stage == 104 && idle(a) && !a->library_thread) {
                open_workspace_path(a, argv[2]);
                if (a->loaded || !a->workspace_open || a->project[0] ||
                    strcmp(a->workspace, argv[2]))
                    exit_code = 1;
                test_stage = 105;
            } else if (test_stage == 105) {
                printf("WORKSPACE UI SELF-TEST: %s\n", exit_code ? "FAILED" : "PASSED");
                a->quitting = true;
            }
        } else if(migration_test) {
            if(ps_clock()-test_started>20){exit_code=1;a->quitting=true;}
            else project_migration_test_frame(a,argv[3],identity_test,&test_stage,&exit_code);
        } else if (settings_test) {
            if (ps_clock() - test_started > 20) {
                exit_code = 1;
                a->quitting = true;
            } else
                test_settings_frame(a, argv[3], &test_stage, &exit_code, &capture);
        } else if (plot_test) {
            /* The complete export task renders regular, dense and four scaled
             * PNGs up to 4800x3400, then exercises scene controls. Debug/ASan
             * measured 17 s in the stage-37 exports alone on Windows. */
            double plot_deadline=scene_visibility_test || camera_plane_test?30:
                SDL_getenv("PHYSIM_TEST_GRAPHIC_DIALOG")?120:60;
            if (ps_clock() - test_started > plot_deadline) {
                fprintf(stderr,"Plot self-test timeout at stage %d after %.3f wall seconds (limit %.0f)\n",
                        test_stage,ps_clock()-test_started,plot_deadline);
                exit_code = 1;
                a->quitting = true;
            } else if(scene_visibility_test)
                scene_visibility_test_frame(a,&test_stage,&exit_code,&capture);
            else if(camera_plane_test)
                camera_plane_test_frame(a,&test_stage,&exit_code,&capture);
            else
                test_plot_frame(a, &test_stage, &exit_code, &capture);
            if (plot_noise) test_pointer_noise(a);
        } else if (batch_test) {
            if (ps_clock() - test_started > 150) {
                fprintf(stderr, "Batch UI timeout, stage %d\n", test_stage);
                exit_code = 1;
                a->quitting = true;
            } else
                test_batch_frame(a, &test_stage, &exit_code, &capture, test_batch_workers);
        } else if (recovery_test) {
            /* Queued SDL events affect widgets in the next draw. Leave a
             * complete frame between actions and observations, including
             * asynchronous native window geometry changes during startup. */
            static bool settle;
            if(settle)settle=false;
            else {
                settle=true;
                if (ps_clock() - test_started > 30) {
                    exit_code = 1;
                    a->quitting = true;
                } else if (test_stage == 80 && frames > 1) {
                    if (!strcmp(recovery_mode, "corrupt")) {
                        char path[4096];
                        autosave_path(a, path, sizeof path);
                        nk_str_append_text_char(&a->experiment.string, "\n/* new draft */\n", 17);
                        a->dirty = true;
                        autosave_tick(a, a->autosave_due + 30);
                        save_project(a);
                        ps_autosave *snapshot = NULL;
                        if (!a->autosave_blocked || a->recovery ||
                            ps_autosave_read(path, &snapshot) != PS_CORRUPT)
                            exit_code = 1;
                        ps_autosave_destroy(snapshot);
                        test_stage = 84;
                    } else {
                        test_key(a, SDLK_S);
                        SDL_Event key = {0};
                        key.type = SDL_EVENT_KEY_DOWN;
                        key.key.windowID = SDL_GetWindowID(window);
                        key.key.key = SDLK_F5;
                        SDL_PushEvent(&key);
                        test_stage = 81;
                    }
                } else if (test_stage == 81) {
                    if (!a->recovery || a->job.running || a->dirty || a->analysis_dirty ||
                        test_source_has(a, "main.c", "autosave main"))
                        exit_code = 1;
                    capture = "recovery.bmp";
                    if (!strcmp(recovery_mode, "cancel")) {
                        SDL_Event quit = {0};
                        quit.type = SDL_EVENT_QUIT;
                        SDL_PushEvent(&quit);
                        test_stage = 84;
                    } else {
                        test_mouse(a, a->recovery_bounds[!strcmp(recovery_mode, "discard")], true);
                        test_stage = 82;
                    }
                } else if (test_stage == 82) {
                    test_mouse(a, a->recovery_bounds[!strcmp(recovery_mode, "discard")], false);
                    test_stage = 83;
                } else if (test_stage == 83) {
                    if (!test_recovery_result(a, strcmp(recovery_mode, "discard") != 0))
                        exit_code = 1;
                    test_stage = 84;
                } else if (test_stage == 84) {
                    printf("RECOVERY SELF-TEST: %s\n", exit_code ? "FAILED" : "PASSED");
                    a->quitting = true;
                }
            }
        } else if (self_test) {
            if (ps_clock() - test_started > 180) {
                status(a, "SELF-TEST: Zeitlimit ueberschritten.");
                exit_code = 1;
                a->quitting = true;
            } else if (test_stage == -1 && !a->job.running) {
                if (a->built || !a->diagnostic_count) {
                    status(a, "SELF-TEST: Compilerfehler wurde nicht erkannt.");
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    jump_to_diagnostic(a, &a->diagnostics[0]);
                    capture = "diagnostics.bmp";
                    test_stage = -2;
                }
            } else if (test_stage == -2) {
                char backup[4096];
                snprintf(backup, sizeof backup, "%s/%s.bak", a->project,
                         test_language_analysis ? analysis_source(a) : experiment_source(a));
                if (!load_editor(test_language_analysis ? &a->analysis : &a->experiment, backup)) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    if (test_language_analysis) a->analysis_dirty = true;
                    else a->dirty = true;
                    build_project(a);
                    test_stage = 1;
                }
            } else if (test_stage == 1 && !a->job.running) {
                if (!a->built) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    if (test_example == 1 || test_example == 9) {
                        if (a->parameters.count != 1 ||
                            strcmp(a->parameters.entries[0].name, "dragCoefficient") ||
                            !a->parameters.units[0].declared || a->parameters.units[0].scale!=1 ||
                            strcmp(a->parameters.units[0].symbol,"1")) {
                            status(a, "SELF-TEST: Experimentparameter fehlen nach dem Build.");
                            exit_code = 1;
                            a->quitting = true;
                        } else {
                            snprintf(a->parameters.selected[0],
                                     sizeof a->parameters.selected[0], "0.6");
                            a->project_settings_dirty = true;
                        }
                    }
                    if (test_example == 2 || test_example == 18) {
                        bool found_friction = false, found_spin = false;
                        for (uint32_t i = 0; i < a->parameters.count; i++) {
                            if (!strcmp(a->parameters.entries[i].name, "friction")) {
                                snprintf(a->parameters.selected[i],
                                         sizeof a->parameters.selected[i], "0.3");
                                found_friction = true;
                            } else if (!strcmp(a->parameters.entries[i].name, "spin")) {
                                snprintf(a->parameters.selected[i],
                                         sizeof a->parameters.selected[i], "1");
                                found_spin = true;
                            }
                        }
                        if (a->parameters.count != 8 || !found_friction || !found_spin) {
                            status(a, "SELF-TEST: Kugelstossparameter fehlen nach dem Build.");
                            exit_code = 1;
                            a->quitting = true;
                        } else {
                            a->project_settings_dirty = true;
                        }
                    }
                    if (test_example == 6 || test_example == 19) {
                        bool found_restitution = false;
                        for (uint32_t i = 0; i < a->parameters.count; i++) {
                            if (!strcmp(a->parameters.entries[i].name, "restitution")) {
                                snprintf(a->parameters.selected[i],
                                         sizeof a->parameters.selected[i], "0.5");
                                found_restitution = true;
                            }
                        }
                        if (a->parameters.count != 4 || !found_restitution) {
                            status(a, "SELF-TEST: Boxstossparameter fehlen nach dem Build.");
                            exit_code = 1;
                            a->quitting = true;
                        } else {
                            a->project_settings_dirty = true;
                        }
                    }
                    capture = "editor.bmp";
                    test_stage = 2;
                }
            } else if (test_stage == 2) {
                start_run(a);
                test_stage = 3;
            } else if (test_stage == 3 &&
                       a->simulation_time >= (SDL_getenv("PHYSIM_TEST_LONG")             ? 20
                                              : (test_example == 1 || test_example == 5 || test_example == 10) ? .8
                                              : test_example == 4 || test_example == 7 || test_example == 13 || test_example == 14 || test_example == 16 ? 3.2
                                              : test_example == 3 || test_example == 12  ? 2.5
                                              : test_example == 2 || test_example == 6 || test_example == 18 || test_example == 19 ? 1.5
                                                                                         : .2)) {
                command(a, PS_MSG_PAUSE);
                test_stage = 4;
            } else if (test_stage == 3 && !a->runner.running) {
                exit_code = 1;
                a->quitting = true;
            } else if (test_stage == 4 && a->paused) {
                bool label = false, path = false;
                unsigned velocity_arrows = 0, orientation_lines = 0, contact_points = 0;
                unsigned boxes = 0, planes = 0;
                for (uint32_t i = 0; i < a->scene.count; i++) {
                    label = label || a->scene.objects[i].shape == PS_LABEL;
                    path = path || a->scene.objects[i].shape == PS_POLYLINE;
                    velocity_arrows += a->scene.objects[i].shape == PS_ARROW;
                    orientation_lines += a->scene.objects[i].shape == PS_LINE;
                    contact_points += a->scene.objects[i].shape == PS_POINT;
                    boxes += a->scene.objects[i].shape == PS_BOX;
                    planes += a->scene.objects[i].shape == PS_PLANE;
                }
                if ((!a->language_experiment && !label) ||
                    (test_example == 8 && (a->scene.count != 9 || velocity_arrows != 2 || !label || a->scene.objects[2].parent_id!=101 ||
                                           a->scene.objects[3].shape!=PS_GROUP || a->scene.objects[4].parent_id!=100)) ||
                    (test_example == 9 && (a->scene.count != 5 || !path || !label)) ||
                    (test_example == 10 && (a->scene.count != 9 || contact_points != 2 ||
                                            orientation_lines != 2 || velocity_arrows != 1 ||
                                            !path || !label)) ||
                    (test_example == 11 && (a->scene.count != 3 || boxes != 1 || velocity_arrows != 2)) ||
                    (test_example == 12 && (boxes != 1 || planes != 1 || velocity_arrows != 2 || !contact_points || !label)) ||
                    (test_example == 13 && (boxes != 1 || orientation_lines != 1 || velocity_arrows != 1 || contact_points != 2 || !label)) ||
                    (test_example == 14 && (a->scene.count != 5 || orientation_lines != 1 || planes != 1 || !label)) ||
                    (test_example == 15 && (a->scene.count != 6 || orientation_lines != 1 || planes != 2 || velocity_arrows != 1 || !label)) ||
                    (test_example == 16 && (a->scene.count != 13 || a->scene.point_count != 65 ||
                                            boxes != 3 || orientation_lines != 3 ||
                                            velocity_arrows != 3 || contact_points != 1 || !label)) ||
                    (test_example == 18 && (a->scene.count != 11 || orientation_lines != 2 ||
                                            velocity_arrows != 2 || contact_points != 1 || !label)) ||
                    (test_example == 19 && (boxes != 2 || contact_points != 4 ||
                                            velocity_arrows < 6 || !label)) ||
                    (test_example == 1 && (!path || a->scene.point_count < 3)) ||
                    ((test_example == 7 || test_example == 17) &&
                     (orientation_lines != 18 || contact_points != 1 || velocity_arrows != 3 || !label)) ||
                    (test_example == 2 &&
                     (velocity_arrows < 2 || orientation_lines < 2 || !contact_points)) ||
                    (test_example == 3 && (!boxes || !planes || !contact_points)) ||
                    (test_example == 6 && (boxes != 2 || contact_points != 4 || velocity_arrows < 6)) ||
                    (test_example == 4 &&
                     (!path || a->scene.point_count != 65 || velocity_arrows < 3 || boxes < 3))) {
                    status(a, "SELF-TEST: Erweiterte Szene fehlt im Snapshot.");
                    exit_code = 1;
                    a->quitting = true;
                }
                capture = "simulation.bmp";
                paused_time = a->simulation_time;
                command(a, PS_MSG_STEP);
                test_stage = 5;
            } else if (test_stage == 5 && a->simulation_time > paused_time) {
                if (fabs(a->simulation_time - paused_time - a->dt) > 1e-10) {
                    exit_code = 1;
                    a->quitting = true;
                }
                command(a, PS_MSG_STOP);
                a->stop_at = ps_clock();
                test_stage = 6;
            } else if (test_stage == 6 && idle(a)) {
                if (test_example == 1 || test_example == 9) {
                    ps_run_reader reader;
                    if (ps_run_open(&reader, a->last_run) != PS_OK)
                        exit_code = 1;
                    else {
                        char selected[96], standard[96];
                        snprintf(selected, sizeof selected, "\nparameter.dragCoefficient=%.17g\n", 0.6);
                        snprintf(standard, sizeof standard,
                                 "\nparameter_default.dragCoefficient=%.17g\n", 0.47);
                        char coefficient[96];snprintf(coefficient,sizeof coefficient,"\nCd=%.17g\n",.6);
                        if (!strstr(reader.metadata, selected) ||
                            !strstr(reader.metadata, standard) || !strstr(reader.metadata,coefficient) ||
                            !strstr(reader.metadata,"\nparameter_unit.dragCoefficient=1\n"))
                            exit_code = 1;
                        ps_run_reader_close(&reader);
                    }
                }
                if (test_example == 2 || test_example == 18) {
                    ps_run_reader reader;
                    if (ps_run_open(&reader, a->last_run) != PS_OK)
                        exit_code = 1;
                    else {
                        char friction[96], spin[96];
                        snprintf(friction, sizeof friction, "\nparameter.friction=%.17g\n", 0.3);
                        snprintf(spin, sizeof spin, "\nparameter.spin=%.17g\n", 1.0);
                        if (!strstr(reader.metadata, friction) || !strstr(reader.metadata, spin) ||
                            !strstr(reader.metadata,"\nparameter_unit.speed=m/s\n") ||
                            !strstr(reader.metadata,"\nparameter_unit.spin=rad/s\n") ||
                            !strstr(reader.metadata,"\nparameter_unit.customDensity=kg/m^3\n") ||
                            !strstr(reader.metadata,"\nparameter_unit.customViscosity=Pa s\n"))
                            exit_code = 1;
                        ps_run_reader_close(&reader);
                    }
                }
                if (test_example == 6 || test_example == 19) {
                    ps_run_reader reader;
                    if (ps_run_open(&reader, a->last_run) != PS_OK)
                        exit_code = 1;
                    else {
                        if (!strstr(reader.metadata, "\nparameter.restitution=0.5\n") ||
                            !strstr(reader.metadata, "\nparameter_default.restitution=1\n") ||
                            !strstr(reader.metadata, "\nrestitution=0.5\n") ||
                            !strstr(reader.metadata, "\nparameter_unit.angle=rad\n") ||
                            !strstr(reader.metadata, "\nparameter_unit.offset=m\n") ||
                            !strstr(reader.metadata, "\nparameter_unit.restitution=1\n") ||
                            !strstr(reader.metadata, "\nparameter_unit.friction=1\n"))
                            exit_code = 1;
                        ps_run_reader_close(&reader);
                    }
                }
                if (a->language_experiment) {
                    char snapshot[4200];
                    snprintf(snapshot, sizeof snapshot, "%s.experiment.phys", a->last_run);
                    size_t length = 0;
                    char *source = load_utf8_text(snapshot, &length);
                    if (!source || strcmp(source, a->saved_source[0]))
                        exit_code = 1;
                    free(source);
                }
                a->tab = 2;
                analyze(a, false);
                test_stage = 7;
            } else if (test_stage == 7 && idle(a) && test_language_analysis) {
                if(!test_project_run_identity(a))exit_code=1;
                char path[4200];
                uint32_t plots = 0, tables = 0;
                bool pendulum_analysis = test_example == 0 || test_example == 8;
                if (test_example == 10 && (a->data.channel_count != 15 ||
                    a->data.stats[7].count == 0 || a->data.stats[7].count >= a->data.total ||
                    a->data.stats[0].count != a->data.total))
                    exit_code = 1;
                if (!a->analysis_report || a->data.total < 10 ||
                    ps_report_describe(a->analysis_report, NULL, NULL, &plots, &tables) != PS_OK ||
                    plots != (pendulum_analysis || test_example == 17 ? 3u : 2u) ||
                    tables != (pendulum_analysis ? 4u : test_example == 10 ? 2u : 0u))
                    exit_code = 1;
                snprintf(path, sizeof path, pendulum_analysis ? "%s.psreport" : "%s-position.svg", a->report);
                if (!exists(path)) exit_code = 1;
                snprintf(path, sizeof path, "%s-%s.csv", a->report,
                         pendulum_analysis ? "pendulum_1" : test_example == 10 ? "sensor"
                         : test_example == 17 ? "position" : "velocity");
                if (!exists(path)) exit_code = 1;
                if (pendulum_analysis) {
                    if(!test_pendulum_balance_report(a))exit_code=1;
                    snprintf(path,sizeof path,"%s-balance_1.csv",a->report);
                    if(!exists(path))exit_code=1;
                    ps_table_info summary, periods;
                    ps_table_row row;
                    const ps_curve_data *energy;
                    if (ps_report_table_read(a->analysis_report, 0, &summary) != PS_OK ||
                        strcmp(summary.title, "Run comparison") || summary.rows != 1 ||
                        ps_report_row_read(a->analysis_report, 0, 0, &row) != PS_OK ||
                        row.values[0] != (double)a->data.total || row.values[1] < 0 ||
                        ps_report_table_read(a->analysis_report, 1, &periods) != PS_OK ||
                        strcmp(periods.title, "Measured periods") ||
                        periods.rows != (row.values[3] > 0 ? 1u : 0u) ||
                        ps_report_curve_view(a->analysis_report, 1, 0, &energy) != PS_OK ||
                        energy->source_count != a->data.total || fabs(energy->y[0]) > 1e-14)
                        exit_code = 1;
                }
                if (test_example == 10) {
                    snprintf(path, sizeof path, "%s-availability.csv", a->report);
                    if (!exists(path)) exit_code = 1;
                    snprintf(path, sizeof path, "%s-statistics.csv", a->report);
                    if (!exists(path)) exit_code = 1;
                    ps_table_info info;
                    ps_table_row row;
                    if (!a->analysis_report ||
                        ps_report_table_read(a->analysis_report, 0, &info) != PS_OK ||
                        info.rows != 1 ||
                        ps_report_row_read(a->analysis_report, 0, 0, &row) != PS_OK ||
                        row.values[0] != (double)a->data.stats[7].count ||
                        row.values[1] != (double)a->data.total)
                        exit_code = 1;
                }
                snprintf(path, sizeof path, "%s.source.phys", a->report);
                size_t size = 0;
                char *source = load_utf8_text(path, &size);
                if (!source || strcmp(source, a->saved_source[1])) exit_code = 1;
                free(source);
                a->analysis_tab = 0;
                capture = "language-analysis.bmp";
                test_stage = test_example == 10 ? 91 : test_example == 9 ? 80 : 90;
            } else if (test_stage == 80) {
                a->tab = 5;
                test_stage = 81;
            } else if (test_stage == 81) {
                test_mouse(a, a->batch_sweep_bounds, true);
                test_stage = 82;
            } else if (test_stage == 82) {
                test_mouse(a, a->batch_sweep_bounds, false);
                test_stage = 83;
            } else if (test_stage == 83) {
                if (!a->batch_sweep || a->parameters.count != 1 || !a->batch_sweep_ready) {
                    status(a, "SELF-TEST: Parameterstudie wurde nicht aktiviert.");
                    exit_code = 1;
                }
                a->batch_runs = 3;
                a->batch_steps = 1;
                snprintf(a->batch_sweep_start, sizeof a->batch_sweep_start, "0.2");
                snprintf(a->batch_sweep_end, sizeof a->batch_sweep_end, "0.8");
                test_mouse(a, a->batch_start_bounds, true);
                test_stage = 84;
            } else if (test_stage == 84) {
                test_mouse(a, a->batch_start_bounds, false);
                test_stage = 85;
            } else if (test_stage == 85) {
                if (!a->batch_thread && !a->batch_options.runs) {
                    exit_code = 1;
                    a->quitting = true;
                } else if (idle(a) && !a->library_thread) {
                    uint32_t plots = 0, tables = 0;
                    const ps_curve_data *curve = NULL;
                    if (a->batch_code != PS_OK || a->batch_result.completed != 3 ||
                        !a->batch_options.sweep || a->batch_options.sweep_start != 0.2 ||
                        a->batch_options.sweep_end != 0.8 ||
                        !a->analysis_report ||
                        ps_report_describe(a->analysis_report, NULL, NULL, &plots, &tables) != PS_OK ||
                        plots != 1 || tables != 0 ||
                        ps_report_curve_view(a->analysis_report, 0, 0, &curve) != PS_OK ||
                        curve->count != 3 || curve->x[0] != 0.2 || curve->x[2] != 0.8)
                        exit_code = 1;
                    test_stage = 90;
                }
            } else if (test_stage == 91) {
                a->result_view = 3;
                capture = "language-statistics.bmp";
                test_stage = 90;
            } else if (test_stage == 90) {
                open_project(a);
                if (!a->language_analysis || a->language_experiment != (test_example >= 8) ||
                    !test_source_has(a, "analysis.phys", "func analyze():"))
                    exit_code = 1;
                if (test_example == 9) {
                    double saved;
                    if (a->parameters.count != 1 ||
                        ps_parameter_catalog_value(&a->parameters, 0, &saved) != PS_OK ||
                        saved != 0.6 ||
                        !test_source_has(a, "physim.project", "parameter.dragCoefficient="))
                        exit_code = 1;
                }
                if (test_example == 18) {
                    bool found_friction = false, found_spin = false;
                    for (uint32_t i = 0; i < a->parameters.count; i++) {
                        double saved = 0;
                        if (ps_parameter_catalog_value(&a->parameters, i, &saved) != PS_OK)
                            exit_code = 1;
                        if (!strcmp(a->parameters.entries[i].name, "friction"))
                            found_friction = saved == 0.3;
                        if (!strcmp(a->parameters.entries[i].name, "spin"))
                            found_spin = saved == 1;
                    }
                    if (!found_friction || !found_spin ||
                        !test_source_has(a, "physim.project", "parameter.friction=") ||
                        !test_source_has(a, "physim.project", "parameter.spin="))
                        exit_code = 1;
                }
                if (test_example == 19) {
                    bool found_restitution = false;
                    for (uint32_t i = 0; i < a->parameters.count; i++) {
                        double saved = 0;
                        if (ps_parameter_catalog_value(&a->parameters, i, &saved) != PS_OK)
                            exit_code = 1;
                        if (!strcmp(a->parameters.entries[i].name, "restitution"))
                            found_restitution = saved == 0.5;
                    }
                    if (!found_restitution ||
                        !test_source_has(a, "physim.project", "parameter.restitution="))
                        exit_code = 1;
                }
                a->tab = 2;
                a->analysis_tab = 1;
                capture = "language-analysis-editor.bmp";
                test_stage = 19;
            } else if (test_stage == 7 && idle(a)) {
                if(!test_project_run_identity(a))exit_code=1;
                char report[4096];
                snprintf(report, sizeof report, "%s-plot.svg", a->report);
                if (a->data.total < 10 || a->data.result != PS_EOF || !exists(report))
                    exit_code = 1;
                snprintf(report, sizeof report, "%s-derived.csv", a->report);
                if (!exists(report))
                    exit_code = 1;
                uint32_t plots = 0, tables = 0;
                if (!a->analysis_report ||
                    ps_report_describe(a->analysis_report, NULL, NULL, &plots, &tables) != PS_OK ||
                    plots != (test_example == 0 || test_example == 8 || test_example == 4 || test_example == 7 ? 5u : test_example == 5 ? 4u : 3u) || !tables)
                    exit_code = 1;
                if(test_example==0 || test_example==8 || test_example==4 || test_example==7) {
                    if(!test_general_balance_report(a))exit_code=1;
                    snprintf(report,sizeof report,"%s-balance.csv",a->report);
                    if(!exists(report))exit_code=1;
                }
                capture = "analysis.bmp";
                test_stage = 30;
            } else if (test_stage == 30) {
                a->result_view = 1;
                capture = "analysis-scatter.bmp";
                test_stage = 31;
            } else if (test_stage == 31) {
                a->result_view = 2;
                capture = "analysis-histogram.bmp";
                test_stage = 32;
            } else if (test_stage == 32) {
                test_mouse(a, a->result_export_bounds[1], true);
                test_stage = 33;
            } else if (test_stage == 33) {
                test_mouse(a, a->result_export_bounds[1], false);
                test_stage = 34;
            } else if (test_stage == 34) {
                if (!exists(a->result_export) || !strstr(a->result_export, ".svg"))
                    exit_code = 1;
                a->result_view = test_example == 0 || test_example == 8 ? 5 : test_example == 4 || test_example == 5 || test_example == 7 ? 4 : 3;
                capture = "analysis-table.bmp";
                test_stage = 35;
            } else if (test_stage == 35) {
                test_mouse(a, a->result_export_bounds[0], true);
                test_stage = 36;
            } else if (test_stage == 36) {
                test_mouse(a, a->result_export_bounds[0], false);
                test_stage = 37;
            } else if (test_stage == 37) {
                if (!exists(a->result_export) || !strstr(a->result_export, ".csv"))
                    exit_code = 1;
                a->result_view = test_example == 0 || test_example == 8 ? 6 : test_example == 4 || test_example == 5 || test_example == 7 ? 5 : 4;
                capture = "analysis-metrics.bmp";
                if (SDL_getenv("PHYSIM_TEST_LONG") && test_example == 0) {
                    ps_table_row metrics;
                    if (ps_report_row_read(a->analysis_report, 1, 0, &metrics) != PS_OK ||
                        metrics.values[0] > 1e-8 || fabs(metrics.values[1] - 2.488805869) > 2e-6)
                        exit_code = 1;
                }
                test_stage = test_example == 0 || test_example == 8 || test_example == 4 || test_example == 7 ? 39 : test_example == 5 ? 41 : 40;
            } else if (test_stage == 41) {
                a->result_view = 3;
                capture = "analysis-sensor.bmp";
                ps_table_row row;
                if (ps_report_row_read(a->analysis_report, 2, 0, &row) != PS_OK ||
                    row.values[0] != (double)a->data.stats[7].count || row.values[1] <= 0 ||
                    row.values[2] <= 0)
                    exit_code = 1;
                test_stage = 42;
            } else if (test_stage == 42) {
                a->show_report = false;
                a->plot_channel = 7;
                capture = "sensor-data.bmp";
                test_stage = 43;
            } else if (test_stage == 43) {
                a->show_report = true;
                a->result_view = 6;
                capture = "sensor-status.bmp";
                test_stage = 44;
            } else if (test_stage == 44) {
                a->result_view = 7;
                capture = "sensor-errors.bmp";
                test_stage = 40;
            } else if (test_stage == 39) {
                a->result_view = test_example == 0 || test_example == 8 ? 4 : 3;
                capture = "analysis-energy.bmp";
                ps_table_row row;
                if (ps_report_row_read(a->analysis_report, 1, 0, &row) != PS_OK ||
                    row.values[0] > (test_example == 8 ? .02 : 1e-7))
                    exit_code = 1;
                if (test_example == 0 || test_example == 8) {
                    const ps_curve_data *energy;
                    ps_plot_info plot;
                    char path[4200];snprintf(path, sizeof path, "%s-energy.csv", a->report);
                    if (!exists(path) ||
                        ps_report_plot_read(a->analysis_report, 4, &plot) != PS_OK ||
                        strcmp(plot.title, "Numerischer Energiebilanzfehler") ||
                        plot.y_unit.dimension[0] != 2 || plot.y_unit.dimension[1] != 1 ||
                        plot.y_unit.dimension[2] != -2 ||
                        ps_report_curve_view(a->analysis_report, 4, 0, &energy) != PS_OK ||
                        energy->source_count != a->data.total || fabs(energy->y[0]) > 1e-14)
                        exit_code = 1;
                }
                test_stage = test_example == 0 || test_example == 8 ? 170 : 40;
            } else if (test_stage == 170) {
                test_mouse(a, a->result_export_bounds[1], true);
                test_stage = 171;
            } else if (test_stage == 171) {
                test_mouse(a, a->result_export_bounds[1], false);
                test_stage = 172;
            } else if (test_stage == 172) {
                if (!exists(a->result_export) || !strstr(a->result_export, ".svg"))
                    exit_code = 1;
                test_mouse(a, a->result_export_bounds[2], true);
                test_stage = 173;
            } else if (test_stage == 173) {
                test_mouse(a, a->result_export_bounds[2], false);
                test_stage = 174;
            } else if (test_stage == 174) {
                unsigned char header[24];
                FILE *png = fopen(a->result_export, "rb");
                if (!png || !strstr(a->result_export, ".png") ||
                    fread(header, 1, sizeof header, png) != sizeof header ||
                    memcmp(header, "\x89PNG\r\n\x1a\n", 8) || memcmp(header + 12, "IHDR", 4))
                    exit_code = 1;
                if (png) fclose(png);
                test_stage = 40;
            } else if (test_stage == 40) {
                test_previous_report = a->analysis_report;
                join(a->result_path, sizeof a->result_path, a->project,
                     "invalid-report-test.psreport");
                FILE *invalid = fopen(a->result_path, "wbx");
                if (invalid) {
                    fputs("incomplete report", invalid);
                    fclose(invalid);
                    SDL_SetAtomicInt(&a->report_done, 0);
                    a->report_thread = SDL_CreateThread(load_report, "physim-report-test", a);
                }
                if (!invalid || !a->report_thread)
                    exit_code = 1;
                test_stage = 38;
            } else if (test_stage == 38 && !a->report_thread) {
                if (a->analysis_report != test_previous_report || a->report_result != PS_CORRUPT ||
                    !a->result_error[0])
                    exit_code = 1;
                capture = "analysis-rejected.bmp";
                remove(a->result_path);
                test_stage = 8;
            } else if (test_stage == 8) {
                /* Compiler warnings may keep the log open after a successful build. */
                a->show_log = false;
                a->show_search = false;
                test_key(a, SDLK_1);
                test_key(a, SDLK_F);
                test_key(a, SDLK_L);
                test_stage = 9;
            } else if (test_stage == 9) {
                if (a->tab != 0 || !a->show_search || !a->show_log)
                    exit_code = 1;
                capture = "search.bmp";
                test_key(a, SDLK_L);
                test_mouse(a, a->navigation_bounds[1], true);
                test_stage = 10;
            } else if (test_stage == 10) {
                test_mouse(a, a->navigation_bounds[1], false);
                test_stage = 11;
            } else if (test_stage == 11) {
                if (a->tab != 1 || a->show_log)
                    exit_code = 1;
                a->view_disclosure = NK_MAXIMIZED;
                capture = "inspector.bmp";
                test_stage = 12;
            } else if (test_stage == 12) {
                a->show_log = true;
                capture = "simulation-log.bmp";
                test_stage = 13;
            } else if (test_stage == 13) {
                a->show_log = false;
                test_key(a, SDLK_F1);
                test_stage = 14;
            } else if (test_stage == 14) {
                if (a->tab != 1 || !a->doc_visible || !a->doc_window ||
                    a->doc_window == a->window || !a->documentation || a->doc_topic != 1 ||
                    a->doc_error[0])
                    exit_code = 1;
                capture = "docs-api.bmp";
                test_stage = 15;
            } else if (test_stage == 15) {
                for (int topic = 0; topic < DOCUMENTATION_TOPIC_COUNT; topic++) {
                    open_documentation(a, topic);
                    if (!a->documentation || a->doc_topic != topic || a->doc_error[0])
                        exit_code = 1;
                }
                open_documentation(a, 1);
                documentation_link(a, "language-tutorial.md");
                if (strcmp(documentation_topics[a->doc_topic].path,
                           "docs/language-tutorial.md") || a->doc_error[0])
                    exit_code = 1;
                open_documentation(a, 1);
                documentation_link(a, "measurement.md");
                if (a->doc_topic != DOCUMENTATION_MEASUREMENT_TOPIC || a->doc_error[0])
                    exit_code = 1;
                capture = "docs-measurement.bmp";
                test_stage = 23;
            } else if (test_stage == 23) {
                documentation_link(a, "../include/physim/measurement.h");
                if (a->doc_topic != DOCUMENTATION_MEASUREMENT_HEADER || a->doc_error[0])
                    exit_code = 1;
                capture = "docs-measurement-header.bmp";
                test_stage = 230;
            } else if (test_stage == 230) {
                open_documentation(a, 1);
                documentation_link(a, "reference/math.md");
                if (strcmp(documentation_topics[a->doc_topic].path, "docs/reference/math.md"))
                    exit_code = 1;
                documentation_link(a, "../math.md");
                if (a->doc_topic != 30) exit_code = 1;
                documentation_language(a,1);
                snprintf(a->doc_filter, sizeof a->doc_filter, "ps_sweep_spheres");
                documentation_filter(a);
                int mechanics_topic = -1, collision_reference = -1;
                for (int i = 0; i < DOCUMENTATION_TOPIC_COUNT; ++i) {
                    if (!strcmp(documentation_topics[i].path, "docs/mechanics.md")) mechanics_topic = i;
                    if (!strcmp(documentation_topics[i].path, "docs/reference/collision.md")) collision_reference = i;
                }
                if (mechanics_topic < 0 || collision_reference < 0 ||
                    !documentation_hits[mechanics_topic] || !documentation_hits[collision_reference] ||
                    documentation_hits[1])
                    exit_code = 1;
                open_documentation(a, collision_reference);
                snprintf(a->doc_query, sizeof a->doc_query, "%s", a->doc_filter);
                capture = "docs-global.bmp";
                test_stage = 231;
            } else if (test_stage == 231) {
                if (!a->doc_scroll_y) exit_code = 1;
                a->doc_filter[0] = a->doc_query[0] = 0;
                documentation_filter(a);
                open_documentation(a, 45);
                bool table = false;
                for (size_t i = 0; i < a->documentation->count; i++)
                    if (a->documentation->blocks[i].kind == PS_DOC_TABLE_ROW) {
                        a->doc_jump_block = (int)i;
                        table = true;
                        break;
                    }
                if (!table) exit_code = 1;
                capture = "docs-table.bmp";
                test_stage = 24;
            } else if (test_stage == 24) {
                open_documentation(a, 3);
                test_window_key(a->doc_window, SDLK_F);
                test_stage = 16;
            } else if (test_stage == 16) {
                SDL_Event text_event = {0};
                text_event.type = SDL_EVENT_TEXT_INPUT;
                text_event.text.windowID = SDL_GetWindowID(a->doc_window);
                text_event.text.text = "ps_series_derivative";
                if (!SDL_PushEvent(&text_event)) {
                    fprintf(stderr, "Document text event rejected: %s\n", SDL_GetError());
                    exit_code = 1;
                }
                test_stage = 17;
            } else if (test_stage == 17) {
                test_stage = 18;
            } else if (test_stage == 18) {
                capture = "docs-search.bmp";
                if (!a->documentation || !a->doc_scroll_y ||
                    strcmp(a->doc_query, "ps_series_derivative")) {
                    fprintf(stderr,
                            "Document search failed: events=%u, input bytes=%u, query bytes=%zu, "
                            "scroll=%u\n",
                            doc_input_events, doc_input_bytes, strlen(a->doc_query),
                            a->doc_scroll_y);
                    exit_code = 1;
                }
                test_doc_scroll = a->doc_scroll_y;
                test_doc_window_id = SDL_GetWindowID(a->doc_window);
                /* Documentation shortcuts must not change the main workspace. */
                test_window_key(a->doc_window, SDLK_3);
                test_stage = 25;
            } else if (test_stage == 25) {
                if (a->tab != 1 || !a->doc_visible || a->doc_scroll_y != test_doc_scroll)
                    exit_code = 1;
                test_key(a, SDLK_1);
                SDL_Event close_event = {0};
                close_event.type = SDL_EVENT_WINDOW_CLOSE_REQUESTED;
                close_event.window.windowID = test_doc_window_id;
                SDL_PushEvent(&close_event);
                test_stage = 26;
            } else if (test_stage == 26) {
                if (a->quitting || a->doc_visible || a->tab != 0)
                    exit_code = 1;
                test_key(a, SDLK_F1);
                test_stage = 27;
            } else if (test_stage == 27) {
                if (!a->doc_visible || SDL_GetWindowID(a->doc_window) != test_doc_window_id ||
                    a->tab != 0 || a->doc_topic != 3 || a->doc_scroll_y != test_doc_scroll ||
                    strcmp(a->doc_query, "ps_series_derivative"))
                    exit_code = 1;
                SDL_SetWindowSize(a->doc_window, 760, 540);
                test_stage = 28;
            } else if (test_stage == 28) {
                capture = "docs-small.bmp";
                test_window_key(a->doc_window, SDLK_ESCAPE);
                test_stage = 29;
            } else if (test_stage == 29) {
                if (a->doc_visible || a->quitting)
                    exit_code = 1;
                if (docs_test) {
                    open_documentation(a, 1);
                }
                test_stage = docs_test ? 280 : 50;
            } else if(test_stage==280) {
                test_window_mouse(a->doc_window,a->doc_track_bounds[0],true);test_stage=281;
            } else if(test_stage==281) {
                test_window_mouse(a->doc_window,a->doc_track_bounds[0],false);test_stage=282;
            } else if(test_stage==282) {
                if(a->doc_track!=1 || a->doc_topic!=DOCUMENTATION_C_GUIDE_TOPIC)exit_code=1;
                documentation_link(a,"c-workflow.md");
                if(strcmp(documentation_topics[a->doc_topic].path,"docs/c-workflow.md") || a->doc_track!=1)exit_code=1;
                test_window_key_mod(a->doc_window,SDLK_F10,SDL_KMOD_SHIFT);test_stage=2821;
            } else if(test_stage==2821) {
                if(!a->doc_actions_open){exit_code=1;a->quitting=true;}
                else if(a->doc_home_bounds.w>0 && nk_sdl_accessibility_request_focus(a->doc_ui,NULL,"Start")) {
                    test_window_mouse(a->doc_window,a->doc_home_bounds,true);test_stage=283;
                }
            } else if(test_stage==283) {
                test_window_mouse(a->doc_window,a->doc_home_bounds,false);test_stage=284;
            } else if(test_stage==284 && !a->doc_actions_open && !a->doc_action_pending) {
                if(a->doc_topic!=DOCUMENTATION_C_GUIDE_TOPIC || a->doc_track!=1)exit_code=1;
                capture="docs-c-track.bmp";
                test_window_mouse(a->doc_window,a->doc_track_bounds[1],true);test_stage=285;
            } else if(test_stage==285) {
                test_window_mouse(a->doc_window,a->doc_track_bounds[1],false);test_stage=286;
            } else if(test_stage==286) {
                if(a->doc_track!=2 || a->doc_topic!=DOCUMENTATION_PHYSIM_GUIDE_TOPIC)exit_code=1;
                documentation_link(a,"physim-workflow.md");
                if(strcmp(documentation_topics[a->doc_topic].path,"docs/physim-workflow.md") || a->doc_track!=2)exit_code=1;
                documentation_link(a,"reference/language-library.md");
                if(strcmp(documentation_topics[a->doc_topic].path,"docs/reference/language-library.md") || a->doc_track!=2)exit_code=1;
                test_window_key_mod(a->doc_window,SDLK_F10,SDL_KMOD_SHIFT);test_stage=2861;
            } else if(test_stage==2861) {
                if(!a->doc_actions_open){exit_code=1;a->quitting=true;}
                else if(a->doc_home_bounds.w>0 && nk_sdl_accessibility_request_focus(a->doc_ui,NULL,"Start")) {
                    test_window_mouse(a->doc_window,a->doc_home_bounds,true);test_stage=287;
                }
            } else if(test_stage==287) {
                test_window_mouse(a->doc_window,a->doc_home_bounds,false);test_stage=288;
            } else if(test_stage==288 && !a->doc_actions_open && !a->doc_action_pending) {
                if(a->doc_topic!=DOCUMENTATION_PHYSIM_GUIDE_TOPIC || a->doc_track!=2)exit_code=1;
                capture="docs-physim-track.bmp";
                /* Closing the main window exits with either learning route open. */
                SDL_Event close_event={0};close_event.type=SDL_EVENT_WINDOW_CLOSE_REQUESTED;
                close_event.window.windowID=SDL_GetWindowID(a->window);SDL_PushEvent(&close_event);
                test_stage=19;
            } else if (test_stage == 50 && idle(a) && !a->library_thread) {
                snprintf(test_original_run, sizeof test_original_run, "%s", a->last_run);
                snprintf(test_original_report, sizeof test_original_report, "%s",
                         a->loaded_report_path);
                test_original_samples = a->data.total;
                a->dt = .01;
                start_run(a);
                test_stage = 51;
            } else if (test_stage == 51 && a->simulation_time >= 1.5) {
                command(a, PS_MSG_STOP);
                a->stop_at = ps_clock();
                test_stage = 52;
            } else if (test_stage == 52 && idle(a) && !a->library_thread) {
                if (!strcmp(a->last_run, test_original_run) || a->data.total < 100)
                    exit_code = 1;
                a->library_kind = 0;
                test_key(a, SDLK_4);
                test_stage = 53;
            } else if (test_stage == 53 && !a->library_thread && a->library_visible_count >= 2) {
                capture = "library-runs.bmp";
                test_library_row = -1;
                for (unsigned i = 0; i < a->library_visible_count; i++) {
                    char path[4096];
                    if (ps_library_path(a->library, a->library_visible_indices[i], path,
                                        sizeof path) == PS_OK &&
                        !strcmp(path, test_original_run))
                        test_library_row = (int)i;
                }
                if (test_library_row < 0) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    test_mouse(a, a->library_select_bounds[test_library_row], true);
                    test_stage = 54;
                }
            } else if (test_stage == 54) {
                test_mouse(a, a->library_select_bounds[test_library_row], false);
                test_stage = 55;
            } else if (test_stage == 55) {
                if (a->selected_count != 2)
                    exit_code = 1;
                capture = "library-selected.bmp";
                test_mouse(a, a->library_analyze_bounds, true);
                test_stage = 56;
            } else if (test_stage == 56) {
                test_mouse(a, a->library_analyze_bounds, false);
                test_stage = 57;
            } else if (test_stage == 57 && idle(a) && !a->library_thread) {
                uint32_t plots = 0, tables = 0;
                ps_plot_info plot_info = {0};
                if (ps_report_describe(a->analysis_report, NULL, NULL, &plots, &tables) != PS_OK ||
                    plots != 3 || tables != 2 ||
                    ps_report_plot_read(a->analysis_report, 0, &plot_info) != PS_OK ||
                    plot_info.curves != 2)
                    exit_code = 1;
                capture = "library-comparison.bmp";
                a->result_view = 2;
                test_stage = 72;
            } else if (test_stage == 72) {
                ps_curve_data curve;
                if (ps_report_curve_read(a->analysis_report, 2, 0, &curve) != PS_OK || !curve.count)
                    exit_code = 1;
                capture = "library-difference.bmp";
                test_stage = 58;
            } else if (test_stage == 58) {
                open_project(a);
                test_stage = 59;
            } else if (test_stage == 59 && !a->library_thread) {
                if (a->last_run[0] || a->analysis_report || a->built)
                    exit_code = 1;
                a->library_kind = 1;
                open_library(a);
                test_stage = 60;
            } else if (test_stage == 60 && !a->library_thread && a->library_visible_count >= 2) {
                capture = "library-reports.bmp";
                test_library_row = -1;
                for (unsigned i = 0; i < a->library_visible_count; i++) {
                    char path[4096];
                    if (ps_library_path(a->library, a->library_visible_indices[i], path,
                                        sizeof path) == PS_OK &&
                        !strcmp(path, test_original_report))
                        test_library_row = (int)i;
                }
                if (test_library_row < 0) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    test_mouse(a, a->library_open_bounds[test_library_row], true);
                    test_stage = 61;
                }
            } else if (test_stage == 61) {
                test_mouse(a, a->library_open_bounds[test_library_row], false);
                test_stage = 62;
            } else if (test_stage == 62 && idle(a)) {
                uint32_t plots = 0;
                if (strcmp(a->loaded_report_path, test_original_report) ||
                    ps_report_describe(a->analysis_report, NULL, NULL, &plots, NULL) != PS_OK ||
                    plots != (test_example == 0 || test_example == 8 || test_example == 4 || test_example == 7 ? 5u : test_example == 5 ? 4u : 3u) || a->built)
                    exit_code = 1;
                capture = "library-reopened-report.bmp";
                test_stage = 63;
            } else if (test_stage == 63) {
                a->library_kind = 0;
                open_library(a);
                test_stage = 64;
            } else if (test_stage == 64 && !a->library_thread && a->library_visible_count >= 2) {
                test_library_row = -1;
                for (unsigned i = 0; i < a->library_visible_count; i++) {
                    char path[4096];
                    if (ps_library_path(a->library, a->library_visible_indices[i], path,
                                        sizeof path) == PS_OK &&
                        !strcmp(path, test_original_run))
                        test_library_row = (int)i;
                }
                if (test_library_row < 0) {
                    exit_code = 1;
                    a->quitting = true;
                } else {
                    test_mouse(a, a->library_open_bounds[test_library_row], true);
                    test_stage = 65;
                }
            } else if (test_stage == 65) {
                test_mouse(a, a->library_open_bounds[test_library_row], false);
                test_stage = 66;
            } else if (test_stage == 66 && idle(a)) {
                if (strcmp(a->last_run, test_original_run) ||
                    a->data.total != test_original_samples || a->data.result != PS_EOF ||
                    a->show_report)
                    exit_code = 1;
                capture = "library-reopened-run.bmp";
                test_stage = 67;
            } else if (test_stage == 67) {
                open_library(a);
                test_stage = 68;
            } else if (test_stage == 68 && !a->library_thread) {
                test_key(a, SDLK_F);
                test_stage = 69;
            } else if (test_stage == 69) {
                SDL_Event input = {0};
                input.type = SDL_EVENT_TEXT_INPUT;
                input.text.windowID = SDL_GetWindowID(a->window);
                input.text.text = "nicht-vorhanden";
                SDL_PushEvent(&input);
                test_stage = 70;
            } else if (test_stage == 70) {
                test_stage = 71;
            } else if (test_stage == 71) {
                if (strcmp(a->library_query, "nicht-vorhanden") || a->library_visible_count)
                    exit_code = 1;
                capture = "library-filter.bmp";
                test_stage = 19;
            } else if (test_stage == 20 && frames > 1) {
                test_mouse(a, a->navigation_bounds[1], true);
                test_stage = 21;
            } else if (test_stage == 21) {
                test_mouse(a, a->navigation_bounds[1], false);
                test_stage = 22;
            } else if (test_stage == 22) {
                test_stage = 13;
            } else if (test_stage == 19) {
                if (docs_test && !a->quitting)
                    exit_code = 1;
                printf("APP SELF-TEST: %s\n", exit_code ? "FAILED" : "PASSED");
                a->quitting = true;
            }
        }
        if(docs_noise)test_pointer_noise(a);
        if (workflow_test && SDL_getenv("PHYSIM_TEST_WORKFLOW_NOISE") &&
            (checked_stage == 60 || checked_stage == 64) && test_stage != checked_stage) {
            test_pointer_noise(a);
            fprintf(stderr, "WORKFLOW INPUT NOISE: reopen %s\n", checked_stage == 60 ? "report" : "run");
        }
        if (trace_test && test_stage != checked_stage)
            fprintf(stderr, "APP TEST TRACE: stage %d -> %d, status %s\n",
                    checked_stage, test_stage, a->status);
        if (exit_code && !previous_exit_code)
            fprintf(stderr, "First workflow failure at stage %d (next %d): %s "
                            "(tab=%d, selected=%u, samples=%llu, report=%d, query=%s)\n",
                    checked_stage, test_stage, a->status, a->tab, a->selected_count,
                    (unsigned long long)a->data.total, a->show_report, a->library_query);
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.work_seconds = (double)(now - profile_phase) / 1e9;
            profile_phase = now;
        }
        int w, h;
        SDL_GetWindowSize(window, &w, &h);
        draw_ui(a, w, h);
        if(workspace_state_test && !strncmp(argv[3],"analysis-layout-",16))analysis_workspace_test_draw(a,test_stage);
        if(workspace_state_test && !strncmp(argv[3],"file-tabs-design",16))tab_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"transport-design"))transport_design_draw(a);
        if(a->timeline_design_active && !panel_is_detached(a,PS_PANEL_TIMELINE))timeline_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"inspector-design"))inspector_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"object-design"))object_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"tree-design"))tree_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"camera-design"))camera_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"scene-frame-design"))scene_frame_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"measurement-design"))measurement_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"curve-design"))curve_design_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"run-fields-design"))run_fields_draw(a);
        if(workspace_state_test && !strncmp(argv[3],"inspector-tail-",15))inspector_tail_draw(a);
        if(workspace_state_test && !strcmp(argv[3],"inspector-channel"))inspector_channel_draw(a);
        if(workspace_state_test && !strncmp(argv[3],"analysis-editor-",16))analysis_editor_draw(a);
        if(workspace_state_test && !strncmp(argv[3],"component-",10)) {
            component_details_draw(a,argv[3]);if(component_details.failed){exit_code=1;a->quitting=true;}
        }
        preferences_capture(a);
        nk_sdl_update_TextInput(a->ui);
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.ui_seconds = (double)(now - profile_phase) / 1e9;
            profile_phase = now;
        }
        bool profile_rendered = nk_sdl_render(a->ui);
        if (!profile_rendered) {
            fprintf(stderr, "Rendering: %s\n", SDL_GetError());
            exit_code = 1;
            a->quitting = true;
        }
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.render_seconds = (double)(now - profile_phase) / 1e9;
            a->profile_frame.rendered = profile_rendered;
            if (profile_rendered) ps_graphics_ui_stats(graphics, &a->profile_frame.ui);
            profile_phase = now;
        }
        bool doc_capture = capture && (strncmp(capture, "docs-", 5) == 0 ||
                                       strcmp(capture, "batch-documentation.bmp") == 0);
        if (capture && !doc_capture) {
            char path[4096];
            join(path, sizeof path, workspace_state_test ? argv[2] : a->project, capture);
            if(plot_test && SDL_getenv("PHYSIM_TEST_GRAPHIC_DIALOG")) {
                /* One paired BMP/PNG proves identical readback; the remaining
                 * dialog captures are lossless PNG from creation, not deleted
                 * or transformed old evidence. Ordinary fixture paths stay BMP. */
                if(!strcmp(capture,"plot-export-dialog.bmp") && !ps_graphics_capture(graphics,path))exit_code=1;
                char *suffix=strrchr(path,'.');if(suffix && !strcmp(suffix,".bmp"))memcpy(suffix,".png",5);
            }
            if (!ps_graphics_capture(graphics, path))
                exit_code = 1;
        }
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.capture_seconds = (double)(now - profile_phase) / 1e9;
            a->profile_frame.captured = capture != NULL;
            profile_phase = now;
        }
        if (!ps_graphics_present(graphics)) {
            exit_code = 1;
            a->quitting = true;
        }
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.present_seconds = (double)(now - profile_phase) / 1e9;
            profile_phase = now;
        }
        char doc_capture_path[4096];
        if(!panel_windows_render(a)){fprintf(stderr,"Panel rendering: %s\n",SDL_GetError());exit_code=1;a->quitting=true;}
        panel_requests(a);
        if (doc_capture)
            join(doc_capture_path, sizeof doc_capture_path, a->project, capture);
        if (!documentation_window_render(a, doc_capture ? doc_capture_path : NULL)) {
            fprintf(stderr, "Documentation rendering: %s\n", SDL_GetError());
            exit_code = 1;
            a->quitting = true;
        }
        if (a->profiler) {
            Uint64 now = SDL_GetTicksNS();
            a->profile_frame.documentation_seconds = (double)(now - profile_phase) / 1e9;
            a->profile_frame.frame_seconds = (double)(now - profile_frame_started) / 1e9;
            a->profile_frame.interval_seconds = (double)(now - profile_previous) / 1e9;
            a->profile_frame.time_seconds = ps_clock() - profile_app_started;
            if (!profile_ready) profile_ready = a->profile_frame.time_seconds;
            a->profile_frame.startup_ready_seconds = profile_ready;
            if (ps_process_usage_self(&a->profile_frame.usage))
                ps_app_profile_record(a->profiler, &a->profile_frame);
            else ps_app_profile_record(a->profiler, NULL);
            profile_previous = now;
        }
        frames++;
        if (smoke && frames >= 8)
            a->quitting = true;
        /* Deterministic slow rendering for the keyboard regression only. */
        SDL_Delay(workspace_state_test && !strcmp(argv[3],"docs-keyboard-delayed")?80:5);
    }
    project_display_finish(a,true);
    if (a->dirty || a->analysis_dirty || a->project_settings_dirty || a->project_definitions_dirty)
        save_project(a);
    if (workspace_state_save(a) != PS_OK) {
        fprintf(stderr, "%s\n", a->workspace_state_error);
        exit_code = 1;
    }
    if (a->preferences_writable && a->preferences_path[0]) {
        preferences_capture(a);
        ps_preferences persisted=a->preferences;
        if(a->laboratory_active || a->analysis_layout_active){const ps_layout_state *regular=a->analysis_layout_active?&a->analysis_previous:&a->laboratory_previous;persisted.dock=regular->dock;persisted.sidebar_width=regular->sidebar_width;persisted.inspector_width=regular->inspector_width;persisted.log_height=regular->log_height;persisted.view_flags=(persisted.view_flags&~PS_VIEW_LOG)|(regular->show_log?PS_VIEW_LOG:0);}
        ps_result saved = ps_preferences_write(a->preferences_path, &persisted);
        if (saved != PS_OK) {
            fprintf(stderr, "Einstellungen nicht gespeichert: %s\n", ps_result_string(saved));
            exit_code = 1;
        }
    }
    if (a->runner.running) {
        command(a, PS_MSG_STOP);
        double until = ps_clock() + 0.3;
        while (ps_process_poll(&a->runner) && ps_clock() < until)
            ps_sleep(5);
    }
    ps_process_close(&a->runner);
    ps_process_close(&a->job);
    profile_process_finished(a, &a->runner, 0, &a->profile_runner_recorded);
    profile_process_finished(a, &a->job, a->job_kind, &a->profile_job_recorded);
    if (a->batch_thread) {
        SDL_SetAtomicInt(&a->batch_cancel, 1);
        SDL_WaitThread(a->batch_thread, NULL);
    }
    if (batch_test) {
        if (test_stage != 108 || a->batch_code != PS_OK || !a->batch_result.cancelled ||
            a->batch_result.active || !a->batch_result.completed ||
            a->batch_result.completed >= a->batch_options.runs)
            exit_code = 1;
        if (exit_code)
            fprintf(stderr,
                    "Batch UI failed at stage %d, tab=%d, workers=%d, started=%u, completed=%u, "
                    "cancelled=%d, button=(%.1f,%.1f,%.1f,%.1f), status=%s\n",
                    test_stage, a->tab, a->batch_workers, a->batch_result.started,
                    a->batch_result.completed, a->batch_result.cancelled, a->batch_start_bounds.x,
                    a->batch_start_bounds.y, a->batch_start_bounds.w, a->batch_start_bounds.h,
                    a->status);
        printf("BATCH UI SELF-TEST: %s\n", exit_code ? "FAILED" : "PASSED");
    }
    free(a->batch_source);
    ps_comparison_destroy(a->comparison);a->comparison=NULL;
    if (a->data.thread)
        SDL_WaitThread(a->data.thread, NULL);
    if (a->report_thread)
        SDL_WaitThread(a->report_thread, NULL);
    if (a->import_thread)SDL_WaitThread(a->import_thread,NULL);
    if (a->library_thread)
        SDL_WaitThread(a->library_thread, NULL);
    completion_close(a);
    ps_library_destroy(a->pending_library);
    ps_library_destroy(a->library);
    ps_report_destroy(a->pending_report);
    ps_timeline_destroy(&a->timeline);
    ps_timeline_destroy(&a->data.timeline);
    ps_report_destroy(a->analysis_report);
    report_details_clear(a);
    if (self_test)
        puts(a->log);
    if (self_test && exit_code)
        fprintf(stderr, "Workflow failed at stage %d: %s (tab=%d, sweep=%d, ready=%d, "
                        "built=%d, idle=%d, runs=%u, button=%.1f/%.1f/%.1f/%.1f)\n",
                test_stage, a->status, a->tab, a->batch_sweep, a->batch_sweep_ready,
                a->built, idle(a), a->batch_options.runs, a->batch_start_bounds.x,
                a->batch_start_bounds.y, a->batch_start_bounds.w, a->batch_start_bounds.h);
    /* Publish completed diagnostics before native UI/driver teardown. In
     * particular, independent clients must receive the final workflow marker. */
    fflush(stdout);fflush(stderr);
    ps_text_document_destroy(&a->project_manifest_snapshot);
    nk_textedit_free(&a->experiment);
    nk_textedit_free(&a->analysis);
    free(a->documentation);
    free(a->api_reference);
    model_edit_clear(a);
    free(a->saved_source[0]);
    free(a->saved_source[1]);
    free(a->workspaces);
    ps_autosave_destroy(a->recovery);
    ps_workspace_tree_destroy(&a->workspace_tree);
    documents_clear(a);
    graphic_export_close(a);
    panel_windows_destroy(a);
    documentation_window_destroy(a);
    bool profile_started = a->profiler != NULL;
    ps_app_profile_result profile_result = ps_app_profile_finish(a->profiler);
    if (profile_requested && !profile_started) profile_result.failed = true;
    a->profiler = NULL;
    if (profile_requested)
        fprintf(stderr, "App profiling: %llu frames written, %llu dropped, failed=%u; %llu child records, %llu child records dropped\n",
                (unsigned long long)profile_result.written, (unsigned long long)profile_result.dropped,
                profile_result.failed ? 1u : 0u,
                (unsigned long long)profile_result.process_written,
                (unsigned long long)profile_result.process_dropped);
    free(a->outline_source);
    SDL_SetCursor(SDL_GetDefaultCursor());
    for(unsigned i=0;i<2;i++)if(a->laboratory_cursors[i])SDL_DestroyCursor(a->laboratory_cursors[i]);
    nk_sdl_shutdown(a->ui);
    SDL_SetWindowHitTest(window, NULL, NULL);
    free(a);
    ps_graphics_destroy(graphics);
    SDL_DestroyWindow(window);
    SDL_Quit();
    if (self_test)
        printf("APP TEST EXIT: %d\n", exit_code);
    return exit_code;
}
