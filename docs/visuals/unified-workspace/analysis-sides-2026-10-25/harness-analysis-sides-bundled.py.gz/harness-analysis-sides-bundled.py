from pathlib import Path
import hashlib,json,os,subprocess,sys,time
r=Path.cwd();linux=sys.platform=='linux';platform='linux' if linux else 'windows'
root=Path('/tmp/physim-analysis-sides-final10-bundled') if linux else Path('F:/Physim/validation/analysis-sides-2026-10-25/final10-bundled-windows')
root.mkdir();program=r/('build/native/Design-analysis-linux/bin/physim' if linux else 'build/native/Release/bin/physim.exe')
digest=hashlib.sha256(program.read_bytes()).hexdigest();expected=json.loads((r/'build/native/analysis-sides-after10-source.json').read_text())['inputs']
env=dict(os.environ)
if not linux:
    sys.path.insert(0,str(r/'tools'));from build import compiler_environment
    env=compiler_environment();env['SDL_FORCE_RAISEWINDOW']='1'
env.update(PYTHONUTF8='1',PHYSIM_TEST_BUNDLED_FONTS='1');rows=[]
for name in ['analysis_layout_dark','analysis_layout_light_large_narrow']:
    work=root/name;work.mkdir();start=time.monotonic();print('BEGIN',name,flush=True)
    command=[sys.executable,'tests/check_display_workflow.py',name,'--app',str(program),'--work',str(work),'--root',str(r)]
    with (work/'checker.log').open('w',encoding='utf-8') as log:done=subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT)
    assert hashlib.sha256(program.read_bytes()).hexdigest()==digest
    assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in expected.items())
    rows.append(dict(name=name,exit_code=done.returncode,seconds=time.monotonic()-start));print(rows[-1],flush=True)
    (root/'results.json').write_text(json.dumps(dict(platform=platform,font_mode='bundled',binary=str(program),sha256=digest,cases=rows),indent=2)+'\n',encoding='utf-8')
    if done.returncode:sys.exit(done.returncode)
