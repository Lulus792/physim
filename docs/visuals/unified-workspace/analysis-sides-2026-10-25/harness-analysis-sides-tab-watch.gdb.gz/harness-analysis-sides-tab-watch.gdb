set pagination off
set confirm off
python
import gdb
class TabWatch(gdb.Breakpoint):
    def stop(self):
        print('ANALYSIS DRAG TAB WRITE')
        for expr in ['((app*)%d)->show_report'%task_addr,'((app*)%d)->ui->input.mouse.pos'%task_addr,'((app*)%d)->analysis_tabs[1]'%task_addr,'((app*)%d)->panel_pull'%task_addr]:
            print(expr, gdb.parse_and_eval(expr))
        return True
class ArmWatch(gdb.Breakpoint):
    def stop(self):
        global task_addr
        if int(gdb.parse_and_eval('*stage'))!=13 or int(gdb.parse_and_eval('external'))!=1:return False
        task_addr=int(gdb.parse_and_eval('a'))
        print('ARMED: report=',gdb.parse_and_eval('a->show_report'),'handle=',gdb.parse_and_eval('a->panels[1].action'))
        TabWatch('((app*)%d)->show_report'%task_addr,type=gdb.BP_WATCHPOINT,wp_class=gdb.WP_WRITE)
        self.enabled=False
        return False
ArmWatch('analysis_workspace_test_frame')
end
run
bt 5
