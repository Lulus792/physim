#!/bin/sh
set -eu
cd /mnt/d/Physim
export ASAN_OPTIONS=detect_leaks=0
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
export LIBGL_ALWAYS_SOFTWARE=1
export XDG_RUNTIME_DIR="$(mktemp -d /tmp/physim-analysis-tab-watch-XXXXXX)"
openbox --sm-disable > build/native/analysis-sides-watch-wm.log 2>&1 &
task_wm_pid=$!
trap 'kill "$task_wm_pid" 2>/dev/null || true; rmdir "$XDG_RUNTIME_DIR" 2>/dev/null || true' EXIT
python3 tools/wait-window-manager.py
gdb -batch -x build/native/analysis-sides-tab-watch.gdb --args build/native/Design-analysis-linux/bin/physim --workspace-state-test /tmp/physim-analysis-sides-watch8 analysis-layout-dark-large-narrow
