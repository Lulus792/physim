from pathlib import Path
from PIL import Image
import ast,gzip,hashlib,json,re,subprocess
r=Path('D:/Physim');p=r/'docs/visuals/unified-workspace/analysis-sides-2026-10-25'
digest=lambda data:hashlib.sha256(data).hexdigest()
snapshot=json.loads((p/'source10-inputs.json').read_text(encoding='utf-8'))
assert all(digest((r/name).read_bytes())==h for name,h in snapshot['inputs'].items())
files=set();pictures=0;groups=0
for platform in ['windows','linux']:
    manifest=json.loads((p/(platform+'-manifest.json')).read_text(encoding='utf-8'))
    for item in manifest['files']:
        path=p/item['path'];raw=path.read_bytes();assert len(raw)==item['bytes'] and digest(raw)==item['sha256'],path
        files.add(item['path'])
        if path.suffix=='.gz':
            decoded=gzip.decompress(raw)
            if '.json.gz' in path.name:json.loads(decoded.decode('utf-8'))
    for item in manifest['images']:
        rgb=Image.open(p/item['path']).convert('RGB');assert rgb.size==(item['width'],item['height'])
        assert digest(rgb.tobytes())==item['rgb_sha256']
        source=next(x['source'] for x in manifest['files'] if x['path']==item['path'])
        original=Path('//wsl.localhost/Alpine-Dev')/source.lstrip('/') if platform=='linux' and source.startswith('/tmp/') else Path(source)
        assert digest(original.read_bytes())==item['source_sha256']
        assert digest(Image.open(original).convert('RGB').tobytes())==item['rgb_sha256']
        pictures+=1
    for suffix,expected in [('results',9),('bundled-results',2)]:
        data=json.loads((p/(platform+'-'+suffix+'.json')).read_text(encoding='utf-8'));assert len(data['cases'])==expected and all(c['exit_code']==0 for c in data['cases'])
        binary=Path(data['binary'].replace('/mnt/d/Physim',str(r)))
        assert digest(binary.read_bytes())==data['sha256'];groups+=expected
for path in p.glob('source-app-*.gz'):
    name=path.name[len('source-'):-3].replace('app-','app/',1)
    assert gzip.decompress(path.read_bytes())==(r/name).read_bytes()
for path in p.glob('*.json'):json.loads(path.read_text(encoding='utf-8'))
for path in [r/'docs/visuals/unified-workspace/ANALYSIS-SIDES-NATIVE.md',p/'README.md']:
    for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
        if not target.startswith(('http','#')):assert (path.parent/target.split('#')[0]).exists(),target
assert pictures==30 and groups==22
payload=gzip.compress(Path(__file__).read_bytes(),mtime=0);(p/'audit.py.gz').write_bytes(payload)
summary=dict(inputs_unchanged=len(snapshot['inputs']),groups=groups,hashed_files=len(files),pngs_with_independent_original_rgb_check=pictures,audit_script_gz_sha256=digest(payload))
(p/'audit.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(summary,indent=2))
