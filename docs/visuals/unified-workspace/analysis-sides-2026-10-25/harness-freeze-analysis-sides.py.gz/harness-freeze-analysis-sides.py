from pathlib import Path
import gzip,hashlib,json,struct,sys,zlib
r=Path.cwd();linux=sys.platform=='linux';platform='linux' if linux else 'windows';flow='workflow '+chr(228)
root=Path('/tmp/physim-analysis-sides-final10') if linux else Path('F:/Physim/validation/analysis-sides-2026-10-25/final10-windows')
out=r/'docs/visuals/unified-workspace/analysis-sides-2026-10-25';out.mkdir(exist_ok=True)
snapshot=json.loads((r/'build/native/analysis-sides-after10-source.json').read_text(encoding='utf-8'))
assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in snapshot['inputs'].items())
result=json.loads((root/'results.json').read_text(encoding='utf-8'));assert len(result['cases'])==9 and all(c['exit_code']==0 for c in result['cases'])
assert hashlib.sha256(Path(result['binary']).read_bytes()).hexdigest()==result['sha256']
files=[];images=[]
def save(name,data,source=None):
    dest=out/name
    if dest.exists():assert dest.read_bytes()==data,name
    else:dest.write_bytes(data)
    files.append(dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data),source=str(source) if source else None))
def zipped(name,path):save(name,gzip.compress(path.read_bytes(),mtime=0),path)
def jsonsave(name,value):save(name,(json.dumps(value,indent=2)+'\n').encode())
def bmp(path):
    raw=path.read_bytes();assert raw[:2]==b'BM'
    offset=struct.unpack_from('<I',raw,10)[0];w,h=struct.unpack_from('<ii',raw,18);depth=struct.unpack_from('<H',raw,28)[0]
    assert w>0 and h and depth in (24,32)
    stride=((w*depth+31)//32)*4;pixels=bytearray(w*abs(h)*3);bpp=depth//8
    for y in range(abs(h)):
        sy=abs(h)-1-y if h>0 else y;row=raw[offset+sy*stride:offset+sy*stride+w*bpp]
        rgb=bytearray(w*3);rgb[0::3]=row[2::bpp];rgb[1::3]=row[1::bpp];rgb[2::3]=row[0::bpp];pixels[y*w*3:(y+1)*w*3]=rgb
    return w,abs(h),bytes(pixels)
def picture(name,path):
    w,h,pixels=bmp(path)
    def chunk(tag,data):return struct.pack('>I',len(data))+tag+data+struct.pack('>I',zlib.crc32(tag+data)&0xffffffff)
    rows=b''.join(b'\0'+pixels[y*w*3:(y+1)*w*3] for y in range(h))
    data=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(rows,9))+chunk(b'IEND',b'')
    save(name,data,path);images.append(dict(path=name,width=w,height=h,rgb_sha256=hashlib.sha256(pixels).hexdigest(),source_sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
for row in result['cases']:
    case=row['name'];work=root/case
    zipped(platform+'-'+case+'-checker.log.gz',work/'checker.log');zipped(platform+'-'+case+'-steps.json.gz',work/'app-steps.json')
    if case.startswith('analysis_layout_'):
        for image in ['analysis-both','analysis-minimum-sides']:picture(platform+'-'+case+'-'+image+'.png',work/flow/(image+'.bmp'))
bundle=Path('/tmp/physim-analysis-sides-final10-bundled') if linux else root.with_name('final10-bundled-windows')
bundled=json.loads((bundle/'results.json').read_text(encoding='utf-8'));assert len(bundled['cases'])==2 and all(c['exit_code']==0 for c in bundled['cases']) and bundled['sha256']==result['sha256']
jsonsave(platform+'-bundled-results.json',bundled)
for row in bundled['cases']:
    case=row['name'];work=bundle/case
    zipped(platform+'-bundled-'+case+'-checker.log.gz',work/'checker.log');zipped(platform+'-bundled-'+case+'-steps.json.gz',work/'app-steps.json')
    picture(platform+'-bundled-'+case+'-minimum.png',work/flow/'analysis-minimum-sides.bmp')
if linux:
    baseline=Path('/tmp/physim-analysis-sides-before3/analysis_layout_dark')
    zipped('counterexample-before3-checker.log.gz',r/'build/native/analysis-sides-before3.log');zipped('counterexample-before3-steps.json.gz',baseline/'app-steps.json')
    picture('counterexample-left-208.png',baseline/flow/'analysis-failed.bmp')
    old=bmp(baseline/flow/'analysis-both.bmp');new=bmp(root/'analysis_layout_dark'/flow/'analysis-both.bmp');assert old[:2]==new[:2]
    changed=sum(old[2][i:i+3]!=new[2][i:i+3] for i in range(0,len(old[2]),3))
    result['default_view_strict_comparison']=dict(different_pixels=changed,max_rgb_delta=max(abs(a-b) for a,b in zip(old[2],new[2])))
    picture('linux-before-default.png',baseline/flow/'analysis-both.bmp');zipped('linux-build-final10.log.gz',r/'build/native/analysis-sides-linux-final10.log')
    negative=Path('/tmp/physim-analysis-sides-final8')
    jsonsave('counterexample-linux-source8-results.json',json.loads((negative/'results.json').read_text(encoding='utf-8')))
    zipped('counterexample-linux-source8-steps.json.gz',negative/'analysis_layout_dark_large_narrow/app-steps.json')
    picture('counterexample-drag-changed-view.png',negative/'analysis_layout_dark_large_narrow'/flow/'analysis-failed.bmp')
else:
    for stage in [1,3,4,5,6]:zipped('windows-attempt-'+str(stage)+'.log.gz',r/f'build/native/analysis-sides-windows-final{stage}.log')
    for stage in [4,5]:
        folder=r/f'build/native/analysis-sides-final{stage}-windows/analysis_layout_dark_large_narrow'
        zipped(f'counterexample-stage{stage}-steps.json.gz',folder/'app-steps.json');picture(f'counterexample-large-stage{stage}.png',folder/flow/'analysis-failed.bmp')
    picture('counterexample-wide-height.png',r/'build/native/analysis-sides-final1-windows/analysis_layout_dark'/flow/'analysis-both.bmp')
    zipped('windows-build-final10.log.gz',r/'build/native/analysis-sides-windows-build10.log')
    zipped('counterexample-drag-watch.log.gz',r/'build/native/analysis-sides-tab-watch.log');zipped('counterexample-click-observe.log.gz',r/'build/native/analysis-sides-tab-click.log')
    for stage in range(1,11):jsonsave('source'+str(stage)+'-inputs.json',json.loads((r/f'build/native/analysis-sides-after{stage}-source.json').read_text(encoding='utf-8')))
    owned=['app/analysis_layout.inc','app/analysis_resize.inc','app/analysis_ui.inc','app/analysis_workspace_tests.inc','app/docking_ui.inc','app/main.c','app/ui.h','app/ui_backend.c']
    for path in owned:zipped('source-'+path.replace('/','-')+'.gz',r/path)
    for name in ['analysis-side-probe.sh','analysis-sides-matrix.py','analysis-sides-bundled.py','analysis-sides-bundled.sh','freeze-analysis-sides.py','analysis-sides-tab-watch.gdb','analysis-sides-tab-watch.sh','analysis-sides-tab-click.gdb','analysis-sides-tab-click.sh']:zipped('harness-'+name+'.gz',r/'build/native'/name)
    jsonsave('cleanup.json',json.loads((r/'build/native/analysis-sides-cleanup.json').read_text(encoding='utf-8-sig')))
jsonsave(platform+'-results.json',result)
(out/(platform+'-manifest.json')).write_text(json.dumps(dict(result=result,files=files,images=images),indent=2)+'\n',encoding='utf-8',newline='\n')
print(platform,len(files),'files',len(images),'images',result.get('default_view_strict_comparison',''))
