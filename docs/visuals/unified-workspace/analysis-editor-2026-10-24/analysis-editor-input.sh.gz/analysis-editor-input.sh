#!/bin/sh
set -eu
cd /mnt/d/Physim
task_runtime=$(mktemp -d /tmp/physim-analysis-debug-XXXXXXXX)
export XDG_RUNTIME_DIR="$task_runtime"
export ASAN_OPTIONS=detect_leaks=0
export UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1
export LIBGL_ALWAYS_SOFTWARE=1
export PHYSIM_TEST_TRACE=1
openbox --sm-disable > build/native/analysis-editor-input-wm.log 2>&1 &
task_wm_pid=$!
trap 'kill "$task_wm_pid" 2>/dev/null || true' EXIT
python3 tools/wait-window-manager.py
mkdir build/native/analysis-editor-input-case
gdb --batch -x build/native/analysis-editor-input.gdb --args build/native/Design-analysis-linux/bin/physim --workspace-state-test /mnt/d/Physim/build/native/analysis-editor-input-case analysis-editor-c
