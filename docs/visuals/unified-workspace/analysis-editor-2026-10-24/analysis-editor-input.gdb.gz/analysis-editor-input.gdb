set pagination off
set confirm off
set print thread-events off
set disable-randomization off
break /mnt/d/Physim/app/main.c:4211 if e.type==SDL_EVENT_TEXT_INPUT
commands
silent
printf "INPUT EVENT toolbar=%d search=%d/%d active=%d ", a->toolbar_keyboard,a->show_search,a->search_keyboard,a->analysis.active
if a->ui->active
printf "window=%s ", a->ui->active->name_string
end
set $s=(struct nk_sdl *)a->ui->userdata.ptr
printf "custom=%d native-focus=%llu\n",$s->accessibility_custom_keyboard,$s->accessibility->focused_id
x/s e.text.text
continue
end
break /mnt/d/Physim/app/main.c:4341 if e.type==SDL_EVENT_TEXT_INPUT
commands
silent
printf "INPUT REACHES BACKEND\n"
continue
end
break /mnt/d/Physim/app/main.c:3135 if ui->input.keyboard.text_len>0 && edit==&a->analysis
commands
silent
printf "INPUT EDIT bytes=%d active=%d window=%s ROM=%d/%d mode=%d\n",ui->input.keyboard.text_len,edit->active,ui->active->name_string,(ui->current->flags&NK_WINDOW_ROM)!=0,(ui->current->layout->flags&NK_WINDOW_ROM)!=0,edit->mode
x/s ui->input.keyboard.text
continue
end
run
