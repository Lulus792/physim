set pagination off
set confirm off
set print thread-events off
set disable-randomization off
set environment ASAN_OPTIONS detect_leaks=0
set environment PHYSIM_TEST_TRACE 1
break camera_design_frame if *stage == 20 && camera_design.settle >= 2
run --workspace-state-test /mnt/d/Physim/build/native/camera-source2-range-edge camera-design
printf "CONTROLLED RANGE IMAGE: source2, stage=%d, actual old zoom=%g, setting fixture zoom=12 only for endpoint geometry\n",*stage,a->zoom
set variable a->zoom=12.0
disable 1
continue
quit
