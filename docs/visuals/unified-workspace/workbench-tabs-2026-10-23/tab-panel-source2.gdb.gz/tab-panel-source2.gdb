set pagination off
set confirm off
set print elements 20
set environment ASAN_OPTIONS detect_leaks=0
set environment PHYSIM_TEST_TRACE 1
break panel_windows.inc:29 if pressed && a->panels[3].detached && !a->panels[4].detached
commands
silent
printf "PULL GEOMETRY tab=%d show_log=%d mouse=%g,%g viewport=%g,%g pull=%u resize=%d\n",a->tab,a->show_log,in->mouse.pos.x,in->mouse.pos.y,width,height,a->panel_pull,a->laboratory_resize
p a->panels[4].action
p a->dock_panels[1]
p a->dock_splitters
p a->laboratory_splitters
quit
end
run --workspace-state-test /mnt/d/Physim/build/native/tab-panel-gdb-source2 fixed-panels-c-contrast-large-narrow
