import pathlib,struct,zlib,json,subprocess,os,hashlib,time
root=pathlib.Path('/mnt/d/Physim');work=root/'build/native/settings-maximize-after-small';work.mkdir(exist_ok=True)
original=(root/'build/native/Design-analysis-linux/test-results/run-uh2kwj63/settings_workflow/files ä/workflow ä/preferences.bin').read_bytes()
records=[];env=dict(os.environ);env['PHYSIM_TEST_TRACE']='1';env['PHYSIM_TEST_SMALL']='1'
for label,app,mode in [('current-max','Design-analysis-linux','maxwrite'),('current-defaults','Design-analysis-linux','defaults')]:
    folder=work/label;folder.mkdir();data=bytearray(original);struct.pack_into('<III',data,12,1200,800,0);struct.pack_into('<I',data,len(data)-4,zlib.crc32(data[:-4]));(folder/'preferences.bin').write_bytes(data)
    binary=root/'build/native'/app/'bin/physim';command=[str(binary),'--settings-test',str(folder),mode];start=time.monotonic()
    result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env,timeout=25);after=(folder/'preferences.bin').read_bytes()
    record=dict(label=label,command=command,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),exit_code=result.returncode,seconds=time.monotonic()-start,input=list(struct.unpack_from('<III',data,12)),output=list(struct.unpack_from('<III',after,12)),stdout=result.stdout,stderr=result.stderr);records.append(record);print(label,record['exit_code'],record['input'],record['output'],flush=True)
    (work/'results.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
