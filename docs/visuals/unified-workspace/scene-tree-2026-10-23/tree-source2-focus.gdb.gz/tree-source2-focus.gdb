set pagination off
set confirm off
set print elements 0
set disable-randomization off
set environment ASAN_OPTIONS detect_leaks=0
set environment PHYSIM_TEST_TRACE 1
break tree_design_frame if *stage == 28 && tree_design.settle >= 8
run --workspace-state-test /mnt/d/Physim/build/native/tree-source2-focus tree-design
printf "TREE FOCUS DIAGNOSTIC stage=%d settle=%u\n", *stage, tree_design.settle
print a->preferences.dock
print a->dock_splitters
set $sdl=(struct nk_sdl*)a->ui->userdata.ptr
set $m=$sdl->accessibility
printf "model nodes=%u focused=%llu pending=%llu keyboard=%d suspended=%d\n",$m->count,$m->focused_id,$m->pending_focus,$m->keyboard_focus,$m->suspended
set $i=0
while $i<$m->count
 set $n=&$m->nodes[$i]
 if $n->role==PS_A11Y_SEPARATOR
  printf "SEPARATOR %s enabled=%d focusable=%d focused=%d bounds=%g,%g,%g,%g window=%s\n",$n->label,$n->enabled,$n->focusable,$n->focused,$n->bounds[0],$n->bounds[1],$n->bounds[2],$n->bounds[3],$n->window
 end
 set $i=$i+1
end
set $w=a->ui->begin
while $w
 printf "WINDOW %s seq=%u flags=%u bounds=%g,%g,%g,%g\n",$w->name_string,$w->seq,$w->flags,$w->bounds.x,$w->bounds.y,$w->bounds.w,$w->bounds.h
 set $w=$w->next
end
set variable a->quitting=true
continue
quit
